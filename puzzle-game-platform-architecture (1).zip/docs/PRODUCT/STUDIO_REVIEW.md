---
id: PROD-002
title: Studio Review & Gap Analysis
status: APPROVED
supersedes: none — living document, re-run before every release gate
---

# Studio Review & Gap Analysis

Written as a pre-investment review, not a progress report. Nothing here is defended; everything is questioned. Scores are absolute, not relative to effort.

---

## 1. Pros — what is genuinely right

| Area | What works | Why it scales / lasts |
|---|---|---|
| Contract | `GameModule` + `GameCapabilities` + `handleAction` is a real, typed, versioned boundary. | Game #51 compiles against the same interface; platform and games cannot import each other. |
| Engine v2 | Single source of truth: subscribe/dispatch, tick opt-in, standardized events. | Eliminates the v1 dual-control-plane bug class; renderers become interchangeable views. |
| Fairness | Sudoku uniqueness proof + conflict-based errors; `validate()` in the contract. | Trust is the category's currency; this is review-proof and player-proof. |
| Determinism | `SeededRandom` + `DailyPuzzleService` + `ReplaySystem`. | Daily challenges, replays, and tests all fall out of one primitive. |
| Retention spine | Streak (with freeze), XP/level, daily seed — wired to `GAME_END`. | The #1 proven lever in the category, implemented as platform services, not per-game hacks. |
| Quality gates | TS strict, 111 passing tests, security headers, rate limiting, sanitization. | Cheap to keep; expensive to add later. Correct ordering. |
| Publishing path | Capacitor config + standalone build script + AAB target + Play-required headers. | The web→store bridge exists; only credentials and content are missing. |

**Why these matter for future development:** each one converts a per-game decision into a platform default. That is the entire business model — 50 games on one engine only works if these hold.

---

## 2. Cons — every weakness, unhidden

**Strategic**
- **The launch lineup is 2/6 built.** 2048 and Sudoku exist. Crossword, Word Search, Jigsaw, Sliding Puzzle do not. Worse: we built Minesweeper, which is *not on the launch list* — effort spent off-roadmap while 4 of 6 slots are empty.
- **No content pipeline.** Crossword/Word Search need thousands of words/clues and a grid generator. None exists. This, not code, is the real blocker.

**Engineering**
- Sudoku uniqueness checking made generation *slower on the main thread* — we traded a correctness bug for a jank risk. Needs a pre-generated puzzle pool.
- Minesweeper renderer still owns its own loop (timer patched, not engine-driven) — contract violation in shipped code.
- Firebase/AdMob/RevenueCat are lazy stubs that silently no-op. Fine as interfaces; misleading if anyone assumes telemetry is flowing.
- Zero component or E2E tests. Logic is covered; the UI — where players actually live — is untested.
- No CI/CD pipeline. Quality gates exist locally only; nothing enforces them on merge.

**Design / UX**
- Visual identity is generic Tailwind indigo — the exact AI-default palette. Hero is a centered headline/subtitle/CTA trio. Both read as prototype, not product.
- Icons are emoji. Inconsistent across platforms, no weight/size system, fails the "premium" test instantly.
- No distinctive typography — system font stack throughout.
- No onboarding, no first-session guidance, no "Daily" entry point despite the daily service existing.
- Audio is oscillator synth — placeholder beeps, not sound design.

**Product**
- No leaderboards, no social/share, no notifications, no i18n, no admin view, no save-conflict UI.
- Monetization is interfaces only: no products, no SDKs, no consent flow.
- Analytics collects but never answers a question — no dashboard, no funnel, no retention curve.

**Documentation**
- 24 docs for 2.5 shipped games. Governance layer (Constitution, AI Governance, Glossary, Style Guide) outweighs the product it governs. Legacy root docs (`ARCHITECTURE.md`, `GAMES.md`, `API.md`) duplicate the `ARCHITECTURE/` folder — drift already present. *(Consolidation executed alongside this review: legacy docs removed, README rewritten.)*

---

## 3. Dos — keep doing

- Contract-first: no game ships without implementing `GameModule` + `validate()`.
- Tests before features; every bug fix gets a regression test.
- Offline-first saves; local writes always succeed.
- Rewarded-first monetization; retention before revenue.
- Standardized event names from ARC-002; no ad-hoc `game2048:win`-style events in new code.
- One XP, one streak, one wallet — platform-level, never per-game.
- Document the *why* (ADRs), not the *what* (code already says what).

## 4. Don'ts — never

- Never let a renderer own game state or timers (the v1 disease).
- Never ship a puzzle without a solver proof.
- Never use emoji as production icons.
- Never show an interstitial mid-puzzle; never build energy/lives/loot boxes.
- Never duplicate a platform service per game; never duplicate a doc.
- Never block the main thread on generation — pre-compute pools.
- Never let docs exceed the product: if a doc has no reader, delete it.
- Never add a dependency without checking bundle weight (Firebase added ~72 packages; keep it lazy).

---

## 5. Completed Work — actual status

| Area | Status | Evidence |
|---|---|---|
| Documentation | FUNCTIONAL | Present but over-structured; consolidation in progress |
| Architecture | PRODUCTION READY | Contract + layered boundaries hold |
| Engine | PRODUCTION READY | v2 single-driver, tested |
| Platform | FUNCTIONAL | Services solid; some are no-op stubs |
| Shared Services | FUNCTIONAL | Save/Theme/Settings/Achievements real; Ads/IAP/Firebase interface-only |
| UI | IN PROGRESS | Works; identity is generic |
| Individual Games | IN PROGRESS | 2048 + Sudoku + Minesweeper; 4 of 6 launch games absent |
| Admin Dashboard | NOT STARTED | Correctly deferred |
| Build System | FUNCTIONAL | Next + Capacitor config + standalone script; unproven on device |
| Testing | FUNCTIONAL | 111 logic tests; no UI/E2E |
| CI/CD | NOT STARTED | Doc draft only |

## 6. Remaining Work

**Critical (blocks launch)**
1. Build the 4 missing launch games, starting with the content pipeline (word/clue DB + generators + validators).
2. Decide launch scope honestly: ship 6 medium or 3 excellent — not 2 excellent + 4 empty.
3. Real art direction: icon set (Lucide), display+body type pairing, palette that isn't AI-default indigo.
4. Real audio asset pack + haptic map wired to every game event.
5. Pre-generated Sudoku pool off the main thread.

**High**
6. Daily-puzzle entry point in UI + share-result grid.
7. Firebase/AdMob/RevenueCat wired with real keys (needs founder credentials).
8. E2E smoke tests (Playwright) for the 3 shipped games.
9. CI pipeline enforcing the existing local gates.
10. Onboarding/first-session flow.

**Medium** — leaderboards (local-first), notifications, i18n scaffold, Minesweeper onto Engine v2, stats screens, save-conflict UI.

**Low** — tournaments, replay sharing, season pass, UGC editor, Metabase.

---

## 7. Production Readiness (absolute scores)

| Area | /10 | | Area | /10 |
|---|---|---|---|---|
| Architecture | 8.5 | | Performance | 6.0 |
| Documentation | 6.5 | | Testing | 7.0 |
| Engine | 8.0 | | Security | 7.5 |
| Platform | 7.0 | | Monetization | 3.0 |
| Shared Services | 7.0 | | LiveOps | 2.0 |
| UI | 5.5 | | Analytics | 5.0 |
| UX | 6.0 | | Publishing | 3.0 |
| Graphics | 4.5 | | Maintainability | 8.0 |
| Animations | 6.0 | | Developer Experience | 7.5 |
| Audio | 2.0 | | Accessibility | 6.0 |

**Overall: 6.1 / 10.** A strong engineering foundation carrying an incomplete, under-dressed product. Not shippable; worth finishing.

---

## 8. Competitive Comparison — and why the winners win

**Extracted success reasons (the added requirement).** Every category leader shares six causes; our gap is noted against each:

| Why winners win | Mechanism | Our state |
|---|---|---|
| Content treadmill | A fresh daily puzzle makes the app a habit, not a toy | Service exists, UI absent |
| Loss-aversion loop | Streaks + freezes make skipping costlier than playing | Implemented, invisible |
| Ergonomic craft | T9 pads, one-thumb reach, peer highlighting | Sudoku done; others pending |
| Sensory feedback | Every input returns motion + sound + haptic within 100ms | 2048 partial; audio absent |
| Social comparison | Share grids, ladders, named leaderboards | Absent |
| Fair monetization | Ads between sessions; rewards opt-in; no energy gates | Policy right, plumbing absent |

**Per-category comparison (vs. current top-rated Play competitors):**

| Dimension | Leader does better | We do better | Roadmap item |
|---|---|---|---|
| 2048 vs Threes!/Ketchapp | Personality, music, distribution | Undo/redo, save, deterministic seed | Audio, milestones, share grid |
| Sudoku vs Sudoku.com/Good Sudoku | Content volume, technique tutor, stats | Uniqueness proof, conflict model, T9+inventory | Daily UI, stats, tutor hints |
| Crossword vs NYT/Crossword Master | Content, streaks, competitive PvP | (nothing yet — not built) | Entire game + pipeline |
| Word Search vs Wordscapes | Swipe feel, themed packs, bonus words | — | Entire game |
| Jigsaw vs Magic Jigsaw | Licensed library, rotation, assists | Procedural-art plan (no legal risk) | Entire game + asset pipeline |
| Sliding vs Slidey | Par stars, art reveal | — | Entire game |

Honest summary: **we out-engineer competitors and under-product them.** Their moats are content, feel, and habit loops — not architecture.

---

## 9. Launch Games Review

| Game | Prof. Quality | Gameplay | Visual | UX | Replay | Retention | Monet. | Readiness | **Studio Score** |
|---|---|---|---|---|---|---|---|---|---|
| 2048 | 6.5 | 7.5 | 5.0 | 6.5 | 7.0 | 5.0 | 4.0 | 7.0 | **6.0** |
| Sudoku | 7.0 | 8.0 | 5.5 | 7.0 | 7.5 | 5.5 | 4.5 | 7.0 | **6.5** |
| Crossword | 0.5 | — | — | — | — | — | — | 0.5 | **0.5** |
| Word Search | 0.5 | — | — | — | — | — | — | 0.5 | **0.5** |
| Jigsaw | 0.5 | — | — | — | — | — | — | 0.5 | **0.5** |
| Sliding | 0.5 | — | — | — | — | — | — | 0.5 | **0.5** |

**What blocks a perfect score on the two that exist:** no daily content surface, no audio identity, generic visual language, no share/social, no stats/mastery screen, unproven 60fps on low-end hardware.

---

## 10. Future Games — roadmap critique

The original 9-phase / 50-game order is **mechanics-first**; it should be **pipeline-first**. Games that share infrastructure should ship in clusters:

1. **Word cluster first** (Crossword → Word Search → Word Connect → Anagram): one dictionary + clue DB + validator unlocks 8+ titles.
2. **Logic-grid cluster** (Nonogram, Slitherlink, Nurikabe, Akari): one constraint-solver framework unlocks 6.
3. **Number cluster** (already partly done): Kakuro, Number Merge.

**Add:** a Wordle-style daily word game (highest retention-per-effort in the category); **Merge/2048-variants** (cheap on existing engine).
**Demote or cut:** Chess Puzzles (engine + licensing complexity, niche audience), Hidden Object (asset-heavy, low replay), Gomoku/Reversi (weak retention), Escape Rooms (content cost >> return).
**Keep the promise honest:** 12 excellent games beat 50 shallow ones; the "50+" claim should follow pipelines, not precede them.

---

## 11. Sandbox Problems — why previews expire

**Cause: preview tooling, not the project.** The preview runs in an ephemeral sandboxed container with a fixed idle/TTL limit owned by the platform; it is torn down on timeout regardless of app health. Verified not caused by: project size (build ~10s), bundling, runtime errors (healthcheck passes), or memory (no leaks; loops cancel on unmount).

**Permanent workflow redesign:**
1. Treat every preview as disposable verification, never as state. The repo + `build_and_start` is the source of truth.
2. Validate each turn with `typegen → tsc → vitest → build → build_and_start`; never rely on a preview surviving between sessions.
3. Keep install footprint lean: heavy SDKs (Firebase) stay lazy-imported and tree-shaken so cold builds stay fast.
4. For long-running manual QA, run `npm run dev` locally or deploy the static export (`STANDALONE_GAME` path) to persistent hosting — not the ephemeral preview.

---

## 12. Final Studio Verdict

**Verdict: conditional GO for continued production investment. NO-GO for store submission today.**

I would fund the team and the architecture. I would not fund a launch yet, for exactly these reasons:

1. **The lineup is 2/6.** A "puzzle platform" with two games is a demo.
2. **No content pipeline** means the four word/logic titles have no path to exist at quality.
3. **The product layer is undressed** — placeholder audio, emoji icons, generic palette — and in this category feel *is* the product.
4. **Monetization, analytics insight, and publishing** are all interface-only; none can generate or measure a dollar yet.

**Gates before this deserves to ship:**
- G1: 4 missing games built *or* launch scope formally cut to 3 titles.
- G2: Art + audio identity pass (icons, type, palette, sound pack).
- G3: Daily content surfaced + share grid live.
- G4: Real Firebase/AdMob/RevenueCat integration with consent flow.
- G5: E2E smoke suite + CI enforcing gates.
- G6: 60fps verified on a Snapdragon 665-class device; <100MB AAB.
- G7: Play Console, privacy policy, ToS, content rating complete.

Clear G1–G7 and this competes. Until then it is a very promising foundation wearing an unfinished product.
