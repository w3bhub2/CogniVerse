---
id: PROD-001
title: Studio-Level Competitive Audit & Product Upgrade Plan
status: APPROVED
scope: Launch games, platform services, engine, docs, monetization, retention
---

# Competitive Audit — Puzzle Platform Launch Lineup

**Method.** Each launch game is compared against the current category leaders on
mechanics, UX, juice, psychology, progression, monetization, performance and
accessibility. Findings are converted into a prioritized roadmap.

**Market reality check (Sensor Tower, Q1 2025, US iOS):**
- NYT Games holds **2.2M+ active users** and ~$840K/week. Content + streaks + subscription.
- **Crossword Master (the reference screenshot) is declining**: downloads 115K→28K,
  active users 177K→127K in one quarter. Its *mechanics* are worth learning; its
  trajectory says mechanics alone are not enough.
- **Good Sudoku (Zach Gage)** wins on UX, not content volume. The lesson: in a
  flooded category, interaction design is the differentiator.

---

## 1. Per-Game Competitive Analysis

### 1.1 — 2048 (SHIPPED)

| Dimension | Category leader | Why it wins | Our gap |
|---|---|---|---|
| Feel | Threes! | Tile personality, Ridiculon soundtrack, tactile slides | No slide/merge animation — tiles teleport |
| Distribution | 2048 (Ketchapp) | One-tap loop, instant share | Share result missing |
| Retention | Sudoku.com-style dailies | Seeded daily board, global compare | No daily challenge |
| Frustration control | Modern clones | Undo, "continue after 2048" clarity | We have undo ✓; endless-mode framing weak |

**Psychology.** 2048 is pure flow state. Satisfaction = big merges (variable reward).
Frustration = dead boards. Our undo already solves the top frustration; the missing
half is **juice** (merge pop, score bump, milestone celebration) and the **daily seed**.

**Prescription.** Add FLIP slide animation, merge pop + particle, score-bump micro
animation, milestone toasts (128/256/512…), seeded daily board with share grid.

### 1.2 — Sudoku (SHIPPED)

| Dimension | Category leader | Why it wins | Our gap |
|---|---|---|---|
| UX | Good Sudoku | T9 numpad, peer highlighting, digit inventory, technique tutor | 9-in-a-row numpad; no peer highlight; no digit counts |
| Feedback | Good Sudoku | Rule-violation highlighting (educational) | We compare against the solution — punishes exploration |
| Retention | Sudoku.com | Daily puzzle ramping Mon→Sun, ranks, stats | No daily, no rank, no stats |
| Notes | Good Sudoku | Auto-candidates, smart erase | Basic pencil marks only |

**Critical design finding.** Comparing input to the stored solution is the *weaker*
pattern. Industry best practice highlights **rule conflicts** (duplicate in
row/column/box) because it teaches the rules and allows hypothesis testing.
Switch error detection to conflict-based; keep solution only for win-check and hints.

**Prescription.** T9 numpad (3×3), peer-cell + same-digit highlighting, remaining
counts per digit, conflict-based errors, daily puzzle, solve-time stats + rank.

### 1.3 — Crossword (NOT BUILT — flagship reference)

The reference app's winning mechanics:
1. **Scandinavian grid** — clues live inside cells. Mobile-native; no separate clue list.
2. **Async PvP** — "You 35 vs Opponent 19". A solo puzzle becomes a live match.
3. **Tournament ladder** — medals + named leaderboard create aspiration.
4. **Letter tray + big Submit** — no keyboard needed; one-thumb play.
5. **Value framing** — "Enhance Your Vocabulary" sells the benefit.

**Prescription.** Build Scandinavian style first. Ship solo + daily at launch;
competitive mode and tournaments are P3 (they need matchmaking volume to feel alive).
Content pipeline: curated clue/answer database + generator + validator (see §7).

### 1.4 — Word Search (NOT BUILT)

Leaders: Wordscapes Search, Word Search Pro. Winning traits: swipe-to-select with
elastic feel, themed packs, **hidden bonus words** that reward exploration, art reveal
on completion. **Prescription.** Swipe select, themed packs, bonus words, stars per pack.

### 1.5 — Jigsaw (NOT BUILT)

Leaders: Magic Jigsaw (ZiMAD), Easybrain Jigsaw. Winning traits: huge licensed image
library, piece-count difficulty, edge-first assist, snap feedback, daily puzzle.
**Risk.** Licensed photos = legal + cost. **Prescription.** Procedural/generated art
+ bundled original art packs; piece-count ladder; gallery unlock progression.

### 1.6 — Sliding Puzzle (NOT BUILT)

Leaders: niche; usually a mini-game inside collections. Winning traits: move count vs
optimal, par stars, image reveal on solve. **Prescription.** Par-based 1–3 stars,
level packs with art reveal, daily seed. Lowest priority of the six.

---

## 2. Cross-Cutting Systems

### Psychology & retention (the real battleground)

The category is won on **daily return**, not session quality. Evidence-backed levers,
in priority order:

1. **Daily puzzle + streak** (NYT, Sudoku.com, Duolingo). 7-day streak establishment
   is the strongest long-term retention predictor Duolingo has published.
2. **Streak freeze** (loss aversion). Apps with freezes show ~48% longer streaks.
3. **Variable daily reward calendar** with escalating value + suspense reveal.
4. **Personal records & stats curve** — mastery feedback.
5. **Shareable result grid** (Wordle effect) — free acquisition.
6. **Missions** (3 daily tasks) — gives a "reason" beyond the puzzle.

**None of these exist in our platform yet.** This is the single largest gap.

### Progression — where each system belongs

| System | Platform (shared) | Per-game |
|---|---|---|
| XP / player level | ✓ | — |
| Streak + daily calendar | ✓ | Daily seed per game |
| Achievements | ✓ | Game-specific triggers |
| Personal records / stats | ✓ | Per-game metrics |
| Stars | — | ✓ (Sudoku difficulty, packs, sliding par) |
| Rank / ladder | — | ✓ (Sudoku rank, Crossword PvP later) |
| Coins / wallet | ✓ if ever built | Never per-game |
| Avatars / themes | ✓ cosmetic | Game accent themes |

**Rule:** one wallet, one XP, one streak. Per-game only gets stars/rank/daily-seed.

### Monetization experience

- **Rewarded-first.** Hints, undo packs, streak freeze — always opt-in.
- **Interstitial** only post-loss, between sessions, capped (1 per 3 sessions, 90s cooldown).
- **IAP:** remove-ads lifetime + hint bundles. No subscriptions at launch.
- **Never build:** energy/lives, pay-to-skip difficulty, loot boxes, forced mid-puzzle ads.
  In the premium puzzle segment these measurably damage D7+ retention.

### Performance (engineering findings in our code)

1. **Sudoku generation runs backtracking on the main thread** — can jank on low-end.
   Fix: pre-generate a puzzle pool off-main (chunked or worker) and draw from it.
2. **Minesweeper hard (16×30 = 480 cells) re-renders whole board per reveal.**
   Fix: memoize cells; render only changed cells.
3. **2048 has zero motion** — board re-renders, tiles teleport. Highest-impact fix
   for perceived quality: FLIP slide + merge animations.
4. **Engine runs a rAF loop that no renderer uses** — dead weight + dual source of
   truth (see §5).

### Accessibility

Missing: color-blind-safe palettes (Minesweeper numbers, Sudoku conflicts need
shape/icon redundancy), `aria-live` announcements for game events, audio cues for
correct/incorrect, Sudoku cell-size scaling, verified high-contrast theme.
Present and good: touch targets, reduce-motion, keyboard shortcuts, focus rings.

---

## 3. Platform Services Review

| Service | Verdict | Reason |
|---|---|---|
| SaveService | **Keep** | Offline-first dual persistence is correct |
| SettingsService | **Keep** | — |
| ThemeEngine | **Keep** | — |
| ThemeService (old) | **Remove** | Duplicated by ThemeEngine; dead code |
| AudioService | **Keep, upgrade** | Replace oscillator synth with real asset pack |
| HapticsService | **Keep** | Wire patterns into every game event |
| AchievementService | **Keep** | Fold triggers into ProgressionService |
| AnalyticsService + FirebaseService | **Consolidate** | One emitter; Firebase when configured, first-party API as fallback. Stop double-emitting `game:end` |
| AdService / IAPService | **Keep** | Interfaces ready; wire to real SDKs post-credentials |
| PerformanceMonitor | **Keep** | Surface FPS in dev overlay only |
| ReplaySystem | **Delay (P4)** | No launch value; revisit for esports/share replays |
| EventMiddleware | **Keep, slim** | Rate limiter + validator only; drop dev logger default |

**Missing services to add:**

| New service | Priority | Purpose |
|---|---|---|
| ProgressionService | P1 | XP, player level, one wallet |
| StreakService | P1 | Daily completion tracking, freeze, calendar |
| DailyPuzzleService | P1 | Date-seeded puzzle per game (uses SeededRandom) |
| MissionsService | P2 | 3 daily missions, rewards |
| StatsService | P2 | Per-game records, solve-time percentiles |
| ShareService | P2 | Result-grid image generation + share sheet |
| NotificationService | P3 | Streak reminder, daily-ready push |
| LeaderboardService | P3 | Local-first, cloud later |
| ContentService | P2 | Word/clue/image database + versioning |

---

## 4. Admin Dashboard

**Verdict: do not build a custom dashboard pre-launch.** It is developer vanity until
real users exist. Post-launch, the only metrics that matter:

D1/D7/D30 retention · sessions/day · level completion funnel · fail-point heatmap ·
crash-free sessions · ad fill rate + eCPM · rewarded completion rate · IAP conversion ·
streak distribution.

Implementation: server-side event store already exists (`analytics_events`). P3 =
one read-only `/admin` route with SQL-backed queries. P4 = Metabase if volume demands.

---

## 5. Engine Review

**Core finding — dual control plane.** The `Engine` class owns a rAF loop and calls
`game.update()`, but every renderer constructs its own game instance, owns its own
React state and timers, and never touches `Engine`. Two parallel sources of truth;
the Engine is effectively dead architecture in the shipped UI.

**Decision.** For launch, keep renderers as owners (pragmatic, works, tested).
Refactor in P2 to make Engine the single driver: renderers subscribe to engine state
and forward input only. Until then, remove the unused loop from the critical path and
document the intended end-state so game #51 is built against the right contract.

**Contract strengthening (P1):**
- Add `validate()` / solvability hook to `GameMeta` pipeline (see §7).
- Standardize input events (`INPUT_SWIPE` normalization) instead of per-renderer handlers.
- Emit the required standard events (`level_start/complete`, `score:update`) — currently
  games emit ad-hoc names (`game2048:win`) that violate our own PLATFORM_CONTRACT.

---

## 6. Documentation Review

24 docs for 3 shipped games is over-governed and will drift. **Consolidate to 10:**

Keep: README (5-min onboarding) · ARCHITECTURE · PLATFORM_CONTRACT · ENGINE ·
TESTING_STANDARDS · per-game specs (3) · CONTRIBUTING.
Merge: GLOSSARY → README appendix · STYLE_GUIDE → CONTRIBUTING ·
SECURITY_MODEL + DATA_ARCHITECTURE → ARCHITECTURE · SAVE_SYSTEM + GAME_FRAMEWORK +
GAME_LIFECYCLE → one GAME_SYSTEMS doc.
Remove ceremony: drop YAML front-matter requirement for everything except ADRs;
drop AI_GOVERNANCE (its rules belong in CONTRIBUTING); MASTER_INDEX becomes the
single doc map. This audit (PROD-001) and the roadmap become living docs.

---

## 7. The Missing Content Pipeline (most underestimated risk)

Crossword and Word Search cannot scale on hand-authored content. Launch requires:
1. Curated, licensed/public-domain word + clue database (start ~5k entries).
2. Grid generator with **guaranteed solvability validator** (Constitution §6 already
   mandates this — it is not implemented).
3. **Sudoku uniqueness check** — current generator removes cells without verifying a
   unique solution. Multi-solution puzzles ship today. Fix before launch; it is a
   review-killer and a player-trust killer.

---

## 8. The 15 Lists

**Add:** daily puzzle + streak, ProgressionService, FLIP/merge animations, T9 numpad,
digit inventory, conflict highlighting, share grid, real audio pack, solvability
validator, Sudoku uniqueness check, content pipeline, missions (P2).

**Remove:** old ThemeService, dead Engine loop from critical path, double analytics
emission, dev logger middleware default.

**Improve:** Minesweeper cell memoization, Sudoku generation off-main, haptic wiring
everywhere, error screens copy, save-on-unload reliability.

**Redesign:** Sudoku error model (conflict-based), GamePlayer renderer/state ownership
(P2), docs tree (24→10).

**Simplify:** event naming to the contract standard, one analytics emitter, one wallet.

**Delay:** ReplaySystem, NotificationService, LeaderboardService, tournaments,
multiplayer, season pass, UGC editor, custom admin UI.

**Never build:** energy/lives, loot boxes, pay-to-skip difficulty, forced mid-puzzle
interstitials, per-game currencies, full multiplayer at launch.

**Missing systems:** §3 table + content pipeline + share service.
**Missing polish:** all motion/juice, win/lose celebration, milestone toasts.
**Missing psychology:** streaks, loss aversion, variable rewards, mastery stats.
**Missing retention:** every item above — this is the #1 workstream.
**Missing a11y:** color-blind redundancy, aria-live, audio cues, font scaling.
**Missing perf:** off-main generation, memoization, animation budget enforcement.
**Missing docs:** consolidation + a one-page "add game #51" runbook (exists partially
in CONTRACT; make it the canonical checklist).
**Missing standards:** animation budget (≤8ms/frame), input-latency budget (<100ms),
APK size budget, solvability CI gate.

---

## 9. Prioritized Roadmap

**P1 — Critical before launch**
1. Sudoku uniqueness validator + conflict-based errors + T9 numpad + digit inventory.
2. DailyPuzzleService + StreakService + ProgressionService (the retention spine).
3. 2048 motion pass (FLIP slides, merge pop, score bump, milestone toasts).
4. Build Crossword (Scandinavian, solo + daily) and Word Search (swipe, packs).
5. Solvability validator + content pipeline scaffolding.
6. Standardize event names to contract; consolidate analytics emitter.
7. Remove old ThemeService; docs consolidation.

**P2 — Launch quality**
8. Jigsaw + Sliding Puzzle.
9. Real audio asset pack + full haptic map.
10. Share-grid ShareService; stats/records screens.
11. Engine-as-single-driver refactor; renderer memoization; off-main Sudoku pool.
12. Accessibility pass (color-blind, aria-live, scaling).

**P3 — Post-launch**
13. Firebase cloud sync + auth (opt-in), NotificationService, LeaderboardService.
14. Missions, daily reward calendar UI, tournaments (Crossword).
15. `/admin` analytics view.

**P4 — Future**
16. Real-time multiplayer, replay sharing, season pass, UGC editor, Metabase.

---

## 10. Adversarial Review — "I am a competing AAA studio"

1. *"They promise 50 games and ship 3. Their 'platform' is three hard-coded switch
   statements."* — Fair. Mitigation: ship 6 strong titles; the GameRegistry factory
   pattern is real but unproven at scale. Game #4 must be added by a different
   engineer to prove the contract holds.
2. *"Web-in-WebView can't feel native; input latency will read as cheap."* — Partially
   fair for twitch games; false for turn-based puzzles. Mitigation: measure tap→render
   latency on a Snapdragon 665; budget <100ms; Capacitor + rAF is adequate here.
3. *"No content moat. Generators without validators ship broken puzzles."* — **True and
   the sharpest risk.** The Sudoku uniqueness gap proves it. Mitigation: solvability CI
   gate before any puzzle game ships.
4. *"Retention systems bolted on after launch never stick."* — True. Mitigation: streaks
   and dailies are P1, not P3.
5. *"Generic visual identity — placeholder icons, system feel."* — Fair. Mitigation:
   art-direction pass is a founder-side workstream; engineering must not block on it
   but must expose theme/accent hooks (already present).

**Conclusion after challenge:** the architecture is sound; the risks are content
validation, retention timing, and motion polish — all addressable in P1/P2. No
structural weakness survives scrutiny.
