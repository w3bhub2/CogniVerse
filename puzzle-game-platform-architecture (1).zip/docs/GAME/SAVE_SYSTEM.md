---
id: GAME-003
title: Save System
status: APPROVED
---

# Save System — Persistence & Conflict Resolution

## Architecture

```
Game State (in-memory)
     ↓
SaveService.save(state)
     ↓
┌─────────────────────────────────────┐
│  localStorage (immediate, <5ms)     │ ← Primary read
│  /api/saves → PostgreSQL (async)    │ ← Server backup
└─────────────────────────────────────┘
```

## Save Data Format

```typescript
interface SaveData {
  gameId: string;           // "2048", "sudoku"
  state: Record<string, unknown>;  // Game-specific state
  score: number;            // Current score
  moves: number;            // Moves made
  timeElapsed: number;      // Milliseconds
  timestamp: number;        // Date.now()
  version: string;          // "1.0.0" (save format version)
}
```

## Save Triggers

| Trigger | Source | Priority |
|---------|--------|----------|
| Game pause | User action | High |
| Tab hidden | Visibility API | High |
| Before unload | Browser event | Critical |
| Auto-save (periodic) | Timer (30s) | Low |
| Game over | Engine | High |
| Manual save | User action | Medium |

## Load Priority

```
1. localStorage (fastest, <5ms)
2. PostgreSQL via API (fallback, <200ms)
3. Fresh game (no save exists)
```

## Save Versioning

When save format changes:

```typescript
// Version 1 → Version 2 migration
function migrateV1ToV2(state: SaveV1): SaveV2 {
  return {
    ...state,
    newField: state.oldField ?? defaultValue,  // Backward compatible
  };
}
```

Rules:
- Never remove fields (mark as deprecated)
- Always provide defaults for new fields
- Version number is integer, increments by 1
- Migration is one-directional (no downgrade)

## Conflict Resolution (Future: Cloud Sync)

When local and cloud saves differ:

```
┌─────────────────────────────────────┐
│         CONFLICT DETECTED           │
│                                     │
│  Local:  Score 1024, 32 moves       │
│  Cloud:  Score 512, 16 moves        │
│                                     │
│  [Use Local]  [Use Cloud]  [Merge]  │
│                                     │
└─────────────────────────────────────┘
```

Strategy:
1. Compare timestamps
2. If same game ID and different state → conflict
3. Show user choice dialog
4. Default to most recent (higher timestamp)

## Offline Behavior

| Scenario | Behavior |
|----------|----------|
| Save while offline | localStorage only, queue for sync |
| Load while offline | localStorage only |
| Online恢复 | Flush queued saves to server |
| Server error | Ignore, keep local copy |
| Corrupt local save | Fall back to server, or start fresh |
