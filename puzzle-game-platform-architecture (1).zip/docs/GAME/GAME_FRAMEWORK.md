---
id: GAME-001
title: Game Framework
status: APPROVED
---

# Game Framework — Shared Gameplay Interfaces

## Game Category Taxonomy

| Category | Description | Example Games |
|----------|-------------|---------------|
| number | Number manipulation, arithmetic | 2048, Sudoku, Number Merge |
| logic | Logical deduction, constraint solving | Minesweeper, Nonogram, Kakuro |
| word | Word formation, vocabulary | Crossword, Word Search, Anagram |
| strategy | Strategic thinking, planning | Chess Puzzles, Reversi, Gomoku |
| memory | Recall, pattern recognition | Memory Match, Simon |
| visual | Visual perception, spatial reasoning | Jigsaw, Find Difference |
| puzzle | Mechanical/spatial puzzles | Sliding Puzzle, Tangram, Pipe Connect |

## Difficulty Rating Scale

| Rating | Label | Description | Target Audience |
|--------|-------|-------------|-----------------|
| 1 | Casual | Minimal thought, relaxing | All ages |
| 2 | Easy | Some strategy needed | Casual gamers |
| 3 | Medium | Requires planning | Regular gamers |
| 4 | Hard | Multiple strategies needed | Puzzle enthusiasts |
| 5 | Expert | Deep mastery required | Hardcore solvers |

## Scoring Principles

1. **Score must be deterministic** — same moves = same score
2. **Score must be bounded** — maximum score is calculable
3. **Score rewards skill, not time** — time bonus is optional, never primary
4. **Score must be serializable** — stored as integer, never float

## Standard Game Events

Every game emits these events:

| Event | When | Required Payload |
|-------|------|-----------------|
| `level_start` | Game begins | `{ gameId, seed, difficulty }` |
| `level_complete` | Win | `{ gameId, score, moves, timeMs }` |
| `level_fail` | Lose | `{ gameId, reason, score, moves }` |
| `score_update` | Score changes | `{ gameId, score, delta }` |
| `move_made` | Player action | `{ gameId, direction/type, valid }` |
| `undo_used` | Undo triggered | `{ gameId, movesRemaining }` |
| `hint_used` | Hint triggered | `{ gameId, hintsRemaining }` |
| `iap_trigger` | IAP opportunity | `{ gameId, item, context }` |

## Puzzle Generation Standards

### Uniqueness
- Each puzzle must be uniquely identifiable by its seed
- No two puzzles with the same seed may differ

### Solvability
- Every generated puzzle MUST be solvable
- Solver must complete before puzzle is presented to user
- If solver fails, regenerate (max 3 attempts, then use fallback)

### Difficulty Scaling
| Parameter | Easy | Medium | Hard | Expert |
|-----------|------|--------|------|--------|
| Empty cells (Sudoku) | 35 | 45 | 52 | 56 |
| Mines (Minesweeper 9x9) | 10 | 15 | 20 | 25 |
| Tiles removed (2048 start) | N/A | N/A | N/A | N/A |
| Hint limit | Unlimited | 5 | 3 | 1 |
| Undo limit | Unlimited | 20 | 10 | 3 |

## Adding a New Game — Step by Step

### 1. Create Game Module
```
src/games/mygame/MyGame.ts
```
Implement `GameModule` interface from `@/engine`.

### 2. Create Game Registry Entry
```typescript
// In src/games/GameRegistry.ts
import { MyGame } from "./mygame";
this.register(() => new MyGame());
```

### 3. Create React Renderer
```
src/components/game/MyGameRenderer.tsx
```
Use only UI primitives from `@/components/ui`.

### 4. Wire into GamePlayer
```typescript
// In src/components/GamePlayer.tsx
case "my-game":
  return <MyGameRenderer {...props} />;
```

### 5. Create Spec Document
```
docs/GAMES/PUZZLE/MY_GAME.md
```

### 6. Write Tests
```
tests/games/MyGame.test.ts
```
Minimum: init, start, win, lose, save, load.

### 7. Write Solver (if puzzle game)
Validate solvability for every generated puzzle.
