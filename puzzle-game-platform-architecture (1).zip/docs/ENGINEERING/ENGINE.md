---
id: ENG-001
title: Engine
status: APPROVED
---

# Engine — Runtime Capabilities

## Core Capabilities

| Capability | Module | Description |
|-----------|--------|-------------|
| Game Loop | `Engine.ts` | requestAnimationFrame-based loop with delta time |
| Lifecycle | `Engine.ts` | load → start → pause → resume → end → destroy |
| Event Bus | `EventSystem.ts` | Typed pub/sub with once/on/emit/off |
| Middleware | `EventMiddleware.ts` | Interceptor chain for logging, rate limiting, validation |
| Seeded RNG | `SeededRandom.ts` | Mulberry32 deterministic PRNG with fork/shuffle/weightedPick |
| Replay | `ReplaySystem.ts` | Record inputs with timestamps, replay deterministically |
| Performance | `PerformanceMonitor.ts` | FPS, frame time, memory tracking |

## Game Loop Architecture

```
requestAnimationFrame callback
  → Calculate delta (ms since last frame)
  → Update elapsed time
  → Call game.update(delta)
  → Emit GAME_TICK event
  → Check game-over condition
  → If over: emit GAME_END, stop loop
  → Request next frame
```

### Delta Time Handling
- Raw delta from `performance.now()`
- No smoothing (preserves original timing)
- Games receive milliseconds, not frames
- Fixed timestep available via optional accumulator pattern

### Performance Budget Per Frame
- 16.67ms budget for 60 FPS
- Game logic: <5ms
- React render: <8ms
- Event processing: <1ms
- Browser overhead: ~2.67ms

## Event System

### Event Naming Convention
```
{layer}:{domain}:{action}

Examples:
  engine:game:start
  engine:game:pause
  input:tap
  input:swipe
  save:request
  score:update
  achievement:unlocked
  platform:theme:change
```

### Middleware Pipeline

```typescript
// Add rate limiter for high-frequency events
engine.getMiddleware().use(
  createRateLimiter(10, [Events.INPUT_TAP, Events.INPUT_SWIPE])
);

// Add validator for save events
engine.getMiddleware().use(
  createValidator(["gameId", "state"])
);

// Add logger in development
engine.getMiddleware().use(loggerMiddleware);
```

## Seeded Random

### Usage Pattern
```typescript
// Game generates puzzle with a seed
const rng = new SeededRandom(Date.now());
const board = generatePuzzle(rng);

// Same seed = same puzzle (for replays and daily challenges)
const replay = new SeededRandom(savedSeed);
const boardCopy = generatePuzzle(replay);

// Fork for sub-operations
const tileRng = rng.fork();  // Independent stream
```

### Daily Challenge Seed
```typescript
// All players get the same puzzle on the same day
const today = new Date().toISOString().split("T")[0]; // "2026-07-26"
const dailySeed = new SeededRandom(today).nextInt(0, 999999);
```

## Replay System

### Recording
```typescript
const replay = new ReplaySystem("2048", seed);
replay.startRecording();
// ... game plays ...
replay.recordFrame("input:swipe", { direction: "left" });
const data = replay.stopRecording();
```

### Playback
```typescript
const replay = new ReplaySystem("2048", seed);
replay.loadReplayData(savedData);
replay.setPlaySpeed(2); // 2x speed
replay.startPlayback(
  (frame) => eventBus.emit(frame.event, frame.payload),
  () => console.log("Replay finished")
);
```
