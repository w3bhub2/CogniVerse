---
id: ENG-004
title: CI/CD Pipeline
status: DRAFT
---

# CI/CD — Build & Deployment Automation

## Pipeline Overview

```
Push to main
  → Lint (ESLint)
  → Type Check (tsc --noEmit)
  → Unit Tests (Vitest)
  → Build (next build)
  → Deploy to Preview (Vercel/Netlify)
  → Health Check

Push to release/*
  → All of above
  → Build APK (Capacitor)
  → Upload to Play Store (internal testing)
```

## GitHub Actions Workflow

```yaml
name: CI
on:
  push:
    branches: [main, release/*]
  pull_request:
    branches: [main]

jobs:
  validate:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with:
          node-version: 22
          cache: npm
      - run: npm ci
      - run: npm run lint
      - run: npx tsc --noEmit
      - run: npx vitest run
      - run: npm run build

  deploy-preview:
    needs: validate
    if: github.event_name == 'pull_request'
    # Deploy preview URL

  deploy-production:
    needs: validate
    if: github.ref == 'refs/heads/main'
    # Deploy to production
```

## Build Commands

| Command | Purpose | When |
|---------|---------|------|
| `npm run dev` | Development server | Local development |
| `npm run build` | Production build | CI/CD, preview |
| `npm run lint` | ESLint check | Pre-commit, CI |
| `npx tsc --noEmit` | Type check | Pre-commit, CI |
| `npx vitest run` | Run all tests | Pre-commit, CI |
| `npx drizzle-kit push` | Schema migration | Manual, CI |
| `npx next typegen` | Route types | Build step |

## Quality Gates

| Gate | Pass Condition | Fail Action |
|------|---------------|-------------|
| TypeScript | 0 errors | Block merge |
| ESLint | 0 errors, 0 warnings | Block merge |
| Tests | 100% pass | Block merge |
| Build | Compiles successfully | Block merge |
| Health | /api/health returns ok | Block deploy |
