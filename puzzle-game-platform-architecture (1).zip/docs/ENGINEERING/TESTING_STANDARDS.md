---
id: ENG-003
title: Testing Standards
status: APPROVED
---

# Testing Standards

## Coverage Targets

| Layer | Target | Tool |
|-------|--------|------|
| Game Logic | 95%+ | Vitest |
| Engine Core | 90%+ | Vitest |
| Platform Services | 85%+ | Vitest |
| API Routes | 80%+ | Vitest + supertest |
| UI Components | 70%+ | Vitest + Testing Library |
| Integration | Critical paths | Playwright (future) |

## Test Categories

### Unit Tests (Current — 97 tests)
- Pure function testing
- No DOM dependency
- Fast execution (<5ms per test)
- Deterministic (seeded RNG)

### Game Logic Tests
Every game must test:
- [ ] Board initialization
- [ ] Valid move detection
- [ ] Win condition
- [ ] Lose condition
- [ ] Score calculation
- [ ] Save/load round-trip
- [ ] Undo/redo (if supported)
- [ ] Edge cases (empty board, full board)

### Solvability Tests
Every puzzle game must have a solver that validates:
- [ ] Generated puzzles have at least one solution
- [ ] Sudoku has exactly one solution
- [ ] Minesweeper's first click is always safe
- [ ] 2048 always has at least one valid move after generation

### API Tests
Every endpoint must test:
- [ ] Happy path (200/201)
- [ ] Missing required fields (400)
- [ ] Rate limiting (429)
- [ ] Payload too large (413)
- [ ] Invalid input (sanitization)
- [ ] Database error (500)

## Running Tests

```bash
# All tests
npx vitest run

# Specific game
npx vitest run tests/games/Game2048.test.ts

# With coverage
npx vitest run --coverage

# Watch mode
npx vitest watch

# Verbose output
npx vitest run --reporter=verbose
```

## Test File Naming

```
tests/
  engine/
    EventSystem.test.ts
    Engine.test.ts
    SeededRandom.test.ts
    EventMiddleware.test.ts
  games/
    Game2048.test.ts
    SudokuGame.test.ts
    MinesweeperGame.test.ts
  lib/
    security.test.ts
  api/
    saves.test.ts       (future)
    scores.test.ts      (future)
```

## Anti-Patterns

```typescript
// ❌ Flaky: depends on timing
it("should animate", () => {
  setTimeout(() => expect(el).toHaveStyle("opacity: 1"), 500);
});

// ❌ Brittle: tests implementation, not behavior
it("should call setState", () => {
  const spy = jest.spyOn(component, "setState");
  component.handleClick();
  expect(spy).toHaveBeenCalled();
});

// ✅ Robust: tests outcome
it("should show result when game ends", () => {
  render(<GameOver visible={true} />);
  expect(screen.getByText("Game Over")).toBeInTheDocument();
});
```
