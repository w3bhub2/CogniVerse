---
id: SPEC-003
title: Minesweeper
status: APPROVED
---

# Minesweeper — Game Specification

## Overview
| Property | Value |
|----------|-------|
| ID | `minesweeper` |
| Category | logic |
| Difficulty | 2 (Easy) |
| Average Session | 5-15 minutes |
| Target Audience | All ages |

## Rules
1. Grid contains hidden mines
2. Click to reveal a cell
3. Revealed cell shows number of adjacent mines (0-8)
4. Number 0 = empty (flood-fill reveals neighbors)
5. Right-click/long-press to flag suspected mines
6. **Win**: All non-mine cells revealed
7. **Lose**: Revealing a mine

## Difficulty Levels
| Level | Grid | Mines | Density |
|-------|------|-------|---------|
| Easy | 9×9 | 10 | 12.3% |
| Medium | 16×16 | 40 | 15.6% |
| Hard | 16×30 | 99 | 20.6% |

## Features
- **First click safety**: Mines placed AFTER first click, never on click position or neighbors
- **Chord**: Click revealed number when correct flags surround it → reveals remaining neighbors
- **Flag toggle**: Flag/unflag any unrevealed cell
- **Timer**: Tracks solve time
- **Mine counter**: Total mines - flags placed = remaining

## Save State
```typescript
{
  board: MinesweeperCell[][];  // Full board state
  rows: number;
  cols: number;
  totalMines: number;
  difficulty: string;
  flagsPlaced: number;
  cellsRevealed: number;
  score: number;
  moves: number;
  timer: number;
  firstClick: boolean;        // Whether first click has occurred
}
```

## Solvability
- First click is ALWAYS safe (safe zone: 3×3 around click)
- Mines placed randomly after first click
- Logic-based solving requires no guessing on easy mode
- Hard mode may require guessing in rare cases (by design)
