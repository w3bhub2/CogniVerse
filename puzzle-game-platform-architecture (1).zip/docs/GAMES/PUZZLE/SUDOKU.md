---
id: SPEC-002
title: Sudoku
status: APPROVED
---

# Sudoku — Game Specification

## Overview
| Property | Value |
|----------|-------|
| ID | `sudoku` |
| Category | logic |
| Difficulty | 3 (Medium) |
| Average Session | 10-25 minutes |
| Target Audience | Logic puzzle enthusiasts |

## Rules
1. 9×9 grid divided into nine 3×3 boxes
2. Each row, column, and box must contain digits 1-9 exactly once
3. Some cells are pre-filled (given)
4. Player fills empty cells with correct digits
5. **Win**: All cells correctly filled
6. **Lose**: 3 mistakes (configurable)

## Difficulty Levels
| Level | Empty Cells | Given Cells |
|-------|-------------|-------------|
| Easy | 35 | 46 |
| Medium | 45 | 36 |
| Hard | 52 | 29 |
| Expert | 56 | 25 |

## Features
- **Pencil marks**: Candidate notation (toggle digits as possibilities)
- **Error highlighting**: Wrong placements shown in red
- **Hint**: Reveals one correct cell (max 3 per game on hard/expert)
- **Timer**: Tracks solve time
- **Mistake counter**: 3 strikes system

## Puzzle Generation
1. Generate complete valid solution using backtracking solver
2. Remove cells based on difficulty level
3. Ensure unique solution (solver verifies)
4. Use seeded random for reproducibility

## Save State
```typescript
{
  board: (number | 0)[][];     // 9x9 values (0 = empty)
  solution: number[][];         // Complete solution
  given: boolean[][];           // Which cells are pre-filled
  difficulty: string;           // "easy" | "medium" | "hard" | "expert"
  mistakes: number;
  hintsUsed: number;
  score: number;
  moves: number;
  timer: number;                // Milliseconds
}
```

## Solvability Proof
- Backtracking solver validates unique solution
- Generation + removal guarantees solvability
- Hint system reveals from the solution, never from guessing
