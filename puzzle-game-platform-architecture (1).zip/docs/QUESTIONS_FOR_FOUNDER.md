---
id: GOV-001
title: Founder Decisions Required
status: OPEN
created: 2026-07-26
---

# Questions for the Founder

Every question below blocks a specific part of the system.
I cannot infer these from the codebase — they require business/strategic decisions.
Once answered, I will implement immediately without further confirmation.

---

## CATEGORY 1: Monetization (Blocks: ECONOMY, ADS, IAP layers)

### Q1: Ad Network
**What ad network(s) should we integrate?**
- Google AdMob (standard, widest fill rate)
- Unity Ads (better for games)
- ironSource / LevelPlay (mediation built-in)
- AppLovin MAX (mediation + exchange)
- Multiple via mediation?

**My recommendation:** AdMob + AppLovin MAX mediation for highest eCPM.

### Q2: Ad Formats
**Which ad formats are allowed?**
- Banner (bottom/top of screen)
- Interstitial (between levels/games)
- Rewarded Video (optional, player opts in for rewards)
- Rewarded Interstitial (semi-rewarded)
- Native ads (in-feed)

**My recommendation:** Rewarded Video only for MVP. Least intrusive, highest eCPM, best retention.

### Q3: Ad Frequency Cap
**How often can ads show?**
- Minimum time between ads (e.g., 60 seconds)
- Maximum ads per session
- Cooldown after purchase (no ads for X minutes after IAP)
- Rewarded video daily cap

**My recommendation:** 1 interstitial every 3 games, 10 rewarded videos/day cap.

### Q4: IAP Items
**What can players buy?**
- [ ] Remove Ads (one-time, $2.99-$4.99)
- [ ] Hint Packs (consumable)
- [ ] Theme Packs (cosmetic)
- [ ] Coin/Energy Packs
- [ ] Season Pass
- [ ] Premium subscription ($X/month)

**My recommendation:** Remove Ads ($3.99) + Hint Packs ($0.99/$1.99/$4.99) for MVP.

### Q5: IAP Pricing Strategy
**Which pricing tiers and regions?**
- US base prices
- Regional pricing (India, Brazil, etc.)
- Trial periods for subscriptions
- Introductory offers

---

## CATEGORY 2: Identity & Auth (Blocks: CLOUD, LEADERBOARDS, SYNC)

### Q6: Authentication Provider
**Do we need user accounts? If so, which provider?**
- Firebase Auth (easy, Google/Apple/email)
- Clerk (modern, React-first)
- Supabase Auth (open source, PostgreSQL)
- Custom JWT (full control)
- No auth for MVP (guest-only, local data)

**My recommendation:** No auth for MVP. Add Firebase Auth in Phase 2 for cloud sync.

### Q7: Cloud Sync Provider
**When we add cloud sync, what backend?**
- Firebase (Auth + Firestore + Remote Config + Crashlytics — all-in-one)
- Supabase (PostgreSQL, already using Drizzle)
- Custom API (full control, more work)

**My recommendation:** Firebase for everything cloud. Already using PostgreSQL for saves, but Firebase gives analytics + crash reporting + remote config + auth as a bundle.

---

## CATEGORY 3: Content (Blocks: i18n, STORE LISTING, COMPLIANCE)

### Q8: Languages for Launch
**Which languages at launch?**
- English only
- English + Spanish
- English + Spanish + Portuguese
- English + 10 major languages
- Full i18n from day one

**My recommendation:** English only for MVP. i18n framework is in place; add languages post-launch based on install data.

### Q9: Publisher / Developer Name
**What name appears on the Play Store?**
- Individual name
- Studio name (what is it?)
- LLC/Inc name

### Q10: Store Listing Content
**Do you have these ready?**
- Short description (80 chars)
- Full description (4000 chars)
- Feature graphic (1024x500)
- Screenshots (phone + tablet)
- Video preview (optional but boosts conversion 25%)

### Q11: Content Rating
**Which IARC rating are we targeting?**
- Everyone (no violence, no fear)
- Everyone 10+ ( mild fantasy violence)
- Teen (13+)

**My recommendation:** Everyone. Puzzle games are universally safe.

### Q12: Privacy Policy URL
**Do you have one, or should I generate one?**
- Need a hosted URL for Play Store submission
- Must cover GDPR, CCPA, COPPA

---

## CATEGORY 4: Technical (Blocks: BUILD PIPELINE, DEVICE COMPAT)

### Q13: Minimum Android Version
**What's the minimum Android SDK?**
- API 21 (Android 5.0) — covers 99%+ devices
- API 24 (Android 7.0) — covers 97%+, better APIs
- API 26 (Android 8.0) — covers 95%, modern features

**My recommendation:** API 24 (Android 7.0). Best balance of reach and modern APIs.

### Q14: Target Android Version
**What SDK do we target?**
- Currently must target API 34+ for Play Store compliance
- API 35 recommended

### Q15: App Bundle vs APK
**AAB (recommended by Google) or APK?**
- AAB: Smaller downloads, Play handles splits
- APK: Manual control, needed for some stores

**My recommendation:** AAB for Play Store. APK for Amazon/Huawei if needed.

### Q16: Signing Key
**Do you have an existing upload key, or generate new?**
- Existing keystore from a previous app
- New keystore (I'll generate)
- Google Play App Signing (recommended)

### Q17: Capacitor or Native?
**How do we wrap for Android?**
- Capacitor (web → native bridge, fast iteration)
- Cordova (older, more plugins)
- React Native (full native, huge rewrite)
- Kotlin native (complete rewrite)

**My recommendation:** Capacitor. Keeps the web codebase, adds native bridges for ads/IAP/haptics.

---

## CATEGORY 5: Analytics & Observability (Blocks: DATA layer)

### Q18: Analytics Platform
**What analytics backend?**
- Firebase Analytics (free, integrates with Google)
- Mixpanel (better funnel analysis)
- Amplitude (best for product analytics)
- PostHog (open source, self-hostable)
- Custom (we already have /api/analytics)

**My recommendation:** Firebase Analytics + our custom /api/analytics for game-specific events.

### Q19: Crash Reporting
**What crash reporting tool?**
- Firebase Crashlytics (free, auto-reports)
- Sentry (better stack traces, replays)
- Bugsnag (good React support)

**My recommendation:** Firebase Crashlytics. Free, integrates with everything else.

### Q20: Remote Config
**Do we need dynamic parameters?**
- A/B test ad frequencies
- Toggle features without app update
- Adjust difficulty curves remotely
- Seasonal content switching

**My recommendation:** Firebase Remote Config. Essential for live ops.

---

## CATEGORY 6: Games & Content (Blocks: GAME LIBRARY)

### Q21: Launch Game Count
**How many games ship at launch?**
- 3 (current: 2048, Sudoku, Minesweeper)
- 6 (add Crossword, Word Search, Jigsaw)
- 10+ (aggressive launch)

### Q22: Game Difficulty Balancing
**Who validates that puzzles are solvable?**
- Automated solver (I can build this)
- Manual QA
- Community beta testing

**My recommendation:** Automated solver for every puzzle. I'll build it.

### Q23: Daily Challenges
**Should games have daily challenges?**
- Same puzzle for all players worldwide (seeded by date)
- Leaderboard for daily challenge
- Rewards for completion

### Q24: Multiplayer
**Is real-time multiplayer in scope?**
- PvP (two players, same puzzle, race)
- Async (take turns on shared board)
- Not in scope for v1

---

## CATEGORY 7: Compliance & Legal (Blocks: STORE SUBMISSION)

### Q25: GDPR Consent
**Do we show a consent dialog for EU users?**
- Yes, custom consent screen
- Yes, use Google UMP (User Messaging Platform)
- No (risky but simpler MVP)

### Q26: COPPA Compliance
**Any features targeting children under 13?**
- If yes, need parental consent mechanism
- If no, declare "not directed at children"

### Q27: Data Deletion
**How do users request data deletion?**
- In-app button
- Email request
- Automated via API

### Q28: Terms of Service
**Do you have ToS, or generate?**

---

## Summary

| # | Question | Blocks | My Recommendation |
|---|----------|--------|-------------------|
| Q1 | Ad Network | Ads layer | AdMob + MAX mediation |
| Q2 | Ad Formats | Ads UI | Rewarded Video only |
| Q3 | Ad Frequency | Ads logic | 1 interstitial/3 games |
| Q4 | IAP Items | Shop UI | Remove Ads + Hints |
| Q5 | IAP Pricing | Billing | $3.99 remove ads |
| Q6 | Auth Provider | Cloud sync | None for MVP |
| Q7 | Cloud Sync | Backend | Firebase Phase 2 |
| Q8 | Languages | i18n | English only MVP |
| Q9 | Publisher Name | Store listing | YOUR ANSWER |
| Q10 | Store Assets | Store listing | YOUR ANSWER |
| Q11 | Content Rating | Store listing | Everyone |
| Q12 | Privacy Policy | Compliance | Generate one |
| Q13 | Min Android | Build | API 24 (7.0) |
| Q14 | Target Android | Build | API 35 |
| Q15 | Bundle vs APK | Build | AAB |
| Q16 | Signing Key | Build | New keystore |
| Q17 | Wrapping | Build | Capacitor |
| Q18 | Analytics | Data layer | Firebase + custom |
| Q19 | Crash Reporting | Stability | Firebase Crashlytics |
| Q20 | Remote Config | Live ops | Firebase RC |
| Q21 | Launch Games | Content | 3 minimum |
| Q22 | Puzzle QA | Game quality | Auto-solver |
| Q23 | Daily Challenges | Retention | Yes, seeded daily |
| Q24 | Multiplayer | Scope | Not v1 |
| Q25 | GDPR Consent | Compliance | Google UMP |
| Q26 | COPPA | Compliance | Not for children |
| Q27 | Data Deletion | Compliance | In-app + API |
| Q28 | Terms of Service | Legal | Generate |

**Priority:** Answer Q1-Q5, Q9, Q13-Q17 first. These unblock the most code.
