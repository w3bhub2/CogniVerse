---
id: SPEC-XXX
title: [GAME NAME]
status: DRAFT
---

# [GAME NAME] — Game Specification

## Overview
| Property | Value |
|----------|-------|
| ID | `[game-id]` |
| Category | `[number|logic|word|strategy|memory|visual|puzzle]` |
| Difficulty | [1-5] |
| Average Session | [X-Y minutes] |
| Target Audience | [description] |

## Rules
1. [Rule 1]
2. [Rule 2]
3. [Rule 3]

## Win/Lose Conditions
- **Win**: [condition]
- **Lose**: [condition]

## Scoring
| Action | Points |
|--------|--------|
| [action 1] | [points] |
| [action 2] | [points] |

## Features
- [ ] Undo/Redo
- [ ] Hints
- [ ] Timer
- [ ] Difficulty levels
- [ ] Daily challenge

## Save State
```typescript
{
  // Define saveable state shape
}
```

## Difficulty Scaling
| Level | Parameter 1 | Parameter 2 |
|-------|-------------|-------------|
| Easy | | |
| Medium | | |
| Hard | | |
| Expert | | |

## Solvability
- [ ] Solver validates every generated puzzle
- [ ] First-click safety (if applicable)
- [ ] Maximum generation attempts: 3

## Achievements
| Achievement | Condition |
|-------------|-----------|
| [name] | [condition] |

## Analytics Events
| Event | When | Payload |
|-------|------|---------|
| `level_start` | Game begins | `{ gameId, seed, difficulty }` |
| `level_complete` | Win | `{ gameId, score, moves, timeMs }` |
| `level_fail` | Lose | `{ gameId, reason }` |
