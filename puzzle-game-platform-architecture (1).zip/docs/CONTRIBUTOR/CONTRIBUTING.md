---
id: GOV-007
title: Contributing Guide
status: APPROVED
---

# Contributing Guide

## Quick Start

```bash
# Clone and install
git clone [repo-url]
cd puzzle-platform
npm install

# Start development
npm run dev          # Dev server on port 3000
npx vitest watch     # Test runner in watch mode
npm run typecheck    # TypeScript check

# Before committing
npm run build        # Production build
npx vitest run       # All tests pass
npm run lint         # No lint errors
```

## Adding a New Game

See [Game Framework](../GAME/GAME_FRAMEWORK.md) for the complete guide.

**Summary:**
1. `src/games/mygame/MyGame.ts` — implement `GameModule`
2. `src/games/GameRegistry.ts` — register it
3. `src/components/game/MyGameRenderer.tsx` — create renderer
4. `src/components/GamePlayer.tsx` — wire it up
5. `tests/games/MyGame.test.ts` — write tests
6. `docs/GAMES/PUZZLE/MY_GAME.md` — write spec

## Code Standards

### TypeScript
- Strict mode: always
- No `any` types
- All public APIs have JSDoc
- Interfaces over type aliases for objects

### React
- Functional components only
- Hooks for state and effects
- Memoize expensive computations
- Lazy-load game renderers

### CSS
- Tailwind utility classes
- CSS custom properties for theming
- No inline styles (except dynamic values)
- Responsive: mobile-first

### Git
- Commit messages: `type(scope): description`
  - `feat(game2048): add particle effects`
  - `fix(sudoku): correct uniqueness check`
  - `docs(engine): update API reference`
  - `test(security): add rate limiter tests`
- One feature per commit
- Tests must pass before merge

## Architecture Rules

See [Constitution](../FOUNDATION/CONSTITUTION.md) for non-negotiables.

**Key rules:**
- Games never import Platform classes
- Platform never imports Game classes
- Communication via Event Bus only
- All game state must be serializable
- All public interfaces must be documented
