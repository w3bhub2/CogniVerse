---
id: GOV-006
title: Documentation Style Guide
status: APPROVED
---

# Documentation Style Guide

## YAML Frontmatter (Required)

Every document must start with:

```yaml
---
id: PREFIX-NNN
title: Human Readable Title
status: DRAFT | APPROVED | DEPRECATED
---
```

### ID Prefixes
| Prefix | Domain | Examples |
|--------|--------|----------|
| GOV | Governance | GOV-001 |
| ARC | Architecture | ARC-001 |
| ENG | Engineering | ENG-001 |
| GAME | Gameplay | GAME-001 |
| ECON | Economy | ECON-001 |
| DATA | Analytics | DATA-001 |
| LOP | LiveOps | LOP-001 |
| SPEC | Game Spec | SPEC-001 |

## Writing Rules

1. **One sentence per line** in lists (not paragraphs)
2. **Use tables** for structured data (not bullet lists)
3. **Code blocks** for any syntax (not inline code for multi-word)
4. **Headers are sentence case** (not Title Case)
5. **No passive voice** ("The system does X" not "X is done by the system")
6. **Present tense** ("The engine calls update()" not "The engine will call update()")
7. **No emojis** in formal docs (emojis OK in README and game specs)
8. **Maximum 3 nesting levels** in any document
9. **Every document links to its parent** in the hierarchy
10. **Every acronym is defined on first use**

## Document Structure Template

```markdown
---
id: PREFIX-NNN
title: Document Title
status: DRAFT
---

# Document Title

## Overview
(1-2 sentences explaining what this document covers)

## Section 1
(Tables, code blocks, clear structure)

## Section 2
...

## Related Documents
- [Parent Doc](link)
- [Sibling Doc](link)
```

## Diagram Standards

Use ASCII diagrams for simple architectures.
Use Mermaid for complex flows:

```mermaid
graph TD
    A[Game] -->|Event| B[Engine]
    B -->|Event| C[Platform]
    C -->|Response| B
```
