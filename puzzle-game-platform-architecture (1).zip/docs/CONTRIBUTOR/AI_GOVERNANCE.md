---
id: GOV-008
title: AI Governance
status: APPROVED
---

# AI Governance — Rules for AI Coding Agents

## Purpose

This document defines how AI coding agents (Copilot, Cursor, Claude, etc.) must interact with this codebase.

## Rules

### 1. Read Before Write
Always read the existing file completely before modifying it.
Never assume file content — always verify.

### 2. Respect the Architecture
- Game Layer → GameModule interface only
- Platform Layer → Services only
- Engine Layer → Core only
- Never create cross-layer imports

### 3. Preserve Existing Tests
When modifying code, ensure all existing tests still pass.
Run `npx vitest run` before and after changes.

### 4. Follow Naming Conventions
- Events: `domain:action` (lowercase, colon-separated)
- Files: PascalCase for components, camelCase for utilities
- Tests: `*.test.ts` or `*.test.tsx`
- Docs: UPPER_SNAKE_CASE for docs, kebab-case for routes

### 5. Never Commit Without Validation
Before suggesting code:
1. TypeScript compiles (`npm run typecheck`)
2. Tests pass (`npx vitest run`)
3. Build succeeds (`npm run build`)

### 6. Documentation is Mandatory
Every new public function/class/module needs:
- JSDoc comment
- Parameter description
- Return type description
- Example usage (if non-obvious)

### 7. Security First
- Never hardcode secrets
- Always sanitize user input
- Never trust client data
- Use parameterized queries

### 8. Performance Awareness
- Memoize expensive computations
- Lazy-load large components
- Avoid unnecessary re-renders
- Profile before optimizing

### 9. Ask Before Architecting
If the task involves:
- New database tables
- New API endpoints
- New third-party services
- Changes to the event system
→ Document the proposal in an ADR first

### 10. Test What You Touch
Every file modified must have corresponding test coverage.
If no test exists, create one.
