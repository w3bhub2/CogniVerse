---
id: GOV-003
title: Master Document Index
status: APPROVED
---

# Master Document Index

## Product
| ID | Document | Status | Owner |
|----|----------|--------|-------|
| PROD-001 | [Competitive Audit & Upgrade Plan](PRODUCT/COMPETITIVE_AUDIT.md) | APPROVED | Game Director |
| PROD-002 | [Studio Review & Gap Analysis](PRODUCT/STUDIO_REVIEW.md) | APPROVED | Studio Director |

## Foundation
| ID | Document | Status | Owner |
|----|----------|--------|-------|
| GOV-001 | [Questions for Founder](QUESTIONS_FOR_FOUNDER.md) | OPEN | Founder |
| GOV-002 | [Glossary](GLOSSARY.md) | APPROVED | Architecture Lead |
| GOV-003 | [Master Index](MASTER_INDEX.md) | APPROVED | Documentation Lead |
| GOV-004 | [Constitution](FOUNDATION/CONSTITUTION.md) | APPROVED | Architecture Lead |
| GOV-005 | [Decision Records](FOUNDATION/DECISIONS.md) | APPROVED | Architecture Lead |
| GOV-006 | [Style Guide](CONTRIBUTOR/STYLE_GUIDE.md) | APPROVED | Documentation Lead |

## Architecture
| ID | Document | Status | Owner |
|----|----------|--------|-------|
| ARC-001 | [Platform Architecture](ARCHITECTURE/PLATFORM_ARCHITECTURE.md) | APPROVED | Platform Architect |
| ARC-002 | [Platform Contract](ARCHITECTURE/PLATFORM_CONTRACT.md) | APPROVED | Platform Architect |
| ARC-003 | [Security Model](ARCHITECTURE/SECURITY_MODEL.md) | APPROVED | Security Architect |
| ARC-004 | [Data Architecture](ARCHITECTURE/DATA_ARCHITECTURE.md) | APPROVED | Data Architect |

## Engineering
| ID | Document | Status | Owner |
|----|----------|--------|-------|
| ENG-001 | [Engine](ENGINEERING/ENGINE.md) | APPROVED | Engine Lead |
| ENG-002 | [Plugin System](ENGINEERING/PLUGIN_SYSTEM.md) | APPROVED | Platform Architect |
| ENG-003 | [Testing Standards](ENGINEERING/TESTING_STANDARDS.md) | APPROVED | QA Architect |
| ENG-004 | [CI/CD](ENGINEERING/CI_CD.md) | DRAFT | DevOps Lead |

## Game
| ID | Document | Status | Owner |
|----|----------|--------|-------|
| GAME-001 | [Game Framework](GAME/GAME_FRAMEWORK.md) | APPROVED | Game Engineer |
| GAME-002 | [Game Lifecycle](GAME/GAME_LIFECYCLE.md) | APPROVED | Game Engineer |
| GAME-003 | [Save System](GAME/SAVE_SYSTEM.md) | APPROVED | Systems Engineer |

## Economy
| ID | Document | Status | Owner |
|----|----------|--------|-------|
| ECON-001 | [Economy](ECONOMY/ECONOMY.md) | DRAFT | Economy Designer |
| ECON-002 | [Monetization](ECONOMY/MONETIZATION.md) | DRAFT | Business Lead |

## Analytics
| ID | Document | Status | Owner |
|----|----------|--------|-------|
| DATA-001 | [Analytics](ANALYTICS/ANALYTICS.md) | APPROVED | Data Engineer |
| DATA-002 | [Telemetry](ANALYTICS/TELEMETRY.md) | DRAFT | Data Engineer |

## LiveOps
| ID | Document | Status | Owner |
|----|----------|--------|-------|
| LOP-001 | [LiveOps](LIVEOPS/LIVEOPS.md) | DRAFT | LiveOps Lead |

## Games
| ID | Document | Status | Owner |
|----|----------|--------|-------|
| SPEC-001 | [2048](GAMES/PUZZLE/2048.md) | APPROVED | Game Engineer |
| SPEC-002 | [Sudoku](GAMES/PUZZLE/SUDOKU.md) | APPROVED | Game Engineer |
| SPEC-003 | [Minesweeper](GAMES/PUZZLE/MINESWEEPER.md) | APPROVED | Game Engineer |
