---
id: ARC-003
title: Security Model
status: APPROVED
---

# Security Model

## Threat Model

### Trust Zones

| Zone | Trust | Data |
|------|-------|------|
| Client (Browser) | LOW | User input, game state |
| API Layer | MEDIUM | Validated requests |
| Database | HIGH | Persistent storage |
| External Services | VARIES | Ads, analytics, auth |

### Threat Categories

| Threat | Mitigation | Implementation |
|--------|------------|----------------|
| XSS | Input sanitization, CSP headers | `sanitizeString()`, `X-Content-Type-Options` |
| CSRF | SameSite cookies, origin checks | Referer policy header |
| Rate Limiting | Sliding window per IP | `isRateLimited()` in API routes |
| Injection | Parameterized queries | Drizzle ORM (never raw SQL) |
| Data Tampering | Input validation | `isSafeObject()`, type checks |
| Payload Bomb | Size limits | Body size validation (5MB saves, 1MB analytics) |
| Game Cheating | Server-side validation | Score bounds checking, replay verification |
| Session Hijacking | HttpOnly cookies, HTTPS | HSTS header, secure cookie flags |
| Ad Fraud | Server-side ad callbacks | Verify ad completion server-side |

### API Security Stack

```
Request → Client IP extraction
        → Rate limit check (sliding window)
        → Payload size validation
        → Content-Type validation
        → Input sanitization (strings, game IDs)
        → Business logic validation
        → Parameterized DB query
        → Response with security headers
```

### Security Headers (Applied via next.config.ts)

| Header | Value | Purpose |
|--------|-------|---------|
| X-Frame-Options | DENY | Prevent clickjacking |
| X-Content-Type-Options | nosniff | Prevent MIME sniffing |
| Referrer-Policy | strict-origin-when-cross-origin | Limit referrer leakage |
| X-XSS-Protection | 1; mode=block | Legacy XSS filter |
| Strict-Transport-Security | max-age=63072000; includeSubDomains; preload | Force HTTPS |
| Permissions-Policy | camera=(), microphone=(), geolocation=() | Disable unused APIs |

### Data Classification

| Data | Classification | Storage | Retention |
|------|---------------|---------|-----------|
| Game saves | Internal | localStorage + PostgreSQL | Until user deletes |
| Scores | Internal | PostgreSQL | 1 year |
| Analytics events | Internal | PostgreSQL | 90 days |
| Settings | Internal | localStorage | Until user clears |
| Achievements | Internal | localStorage | Permanent |
| User identity | N/A (no auth) | N/A | N/A |

### Future: When Auth is Added

| Data | Classification | Storage | Retention |
|------|---------------|---------|-----------|
| Email | PII | PostgreSQL (encrypted) | Account lifetime |
| Auth tokens | Secret | HttpOnly cookies | Session |
| Payment receipts | PII | IAP provider | Per policy |
