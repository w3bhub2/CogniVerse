---
id: ARC-004
title: Data Architecture
status: APPROVED
---

# Data Architecture

## Schema Philosophy

1. **Append-only by default** — Never delete historical data
2. **Timestamp everything** — Every row has `created_at` and `updated_at`
3. **JSON for flexibility** — Game state stored as JSONB (schemaless within column)
4. **Indexed for queries** — Game ID and score are always indexed
5. **Versioned saves** — Save format includes version integer for migration

## Current Schema (4 Tables)

### game_saves
Active save state per game. One row per game with active save.

| Column | Type | Index | Notes |
|--------|------|-------|-------|
| id | serial PK | ✓ | Auto-increment |
| game_id | text | ✓ | Game identifier |
| state | jsonb | | Serialized game state |
| score | integer | | Current score |
| moves | integer | | Moves made |
| time_elapsed | integer | | Milliseconds played |
| version | text | | Save format version |
| created_at | timestamp | | Creation time |
| updated_at | timestamp | | Last modification |

### game_scores
Historical score records for leaderboards.

| Column | Type | Index | Notes |
|--------|------|-------|-------|
| id | serial PK | ✓ | Auto-increment |
| game_id | text | ✓ | Game identifier |
| score | integer | ✓ | Final score (indexed for ranking) |
| won | boolean | | Win/loss |
| moves | integer | | Total moves |
| time_elapsed | integer | | Time in ms |
| metrics | jsonb | | Additional game-specific metrics |
| played_at | timestamp | | When the game was played |

### achievements
Unlocked achievements (one row per achievement type).

| Column | Type | Index | Notes |
|--------|------|-------|-------|
| id | serial PK | ✓ | Auto-increment |
| achievement_id | text | UNIQUE | "first_win", "score_1000" |
| name | text | | Display name |
| description | text | | Description |
| icon | text | | Emoji/icon |
| unlocked_at | timestamp | | When unlocked (null = locked) |

### analytics_events
Server-side analytics storage.

| Column | Type | Index | Notes |
|--------|------|-------|-------|
| id | serial PK | ✓ | Auto-increment |
| name | text | ✓ | Event name |
| properties | jsonb | | Event data |
| session_id | text | | Session identifier |
| timestamp | bigint | ✓ | Client timestamp |
| received_at | timestamp | | Server receipt time |

## Migration Strategy

When schema changes:

1. Create new migration file in `drizzle/` directory
2. Test migration on development database
3. Run `npx drizzle-kit push` to apply
4. Never modify existing columns (add new, deprecate old)
5. Backward compatible: old code can read new schema
