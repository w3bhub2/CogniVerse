---
id: ARC-002
title: Platform Contract — The Bridge
status: APPROVED
---

# Platform Contract

The Platform Contract defines the **only** way Games and Platform communicate.
Violations of this contract are build-time errors.

---

## The GameModule Interface

This is the complete API surface that the Engine uses to control a game:

```typescript
interface GameModule {
  // ─── Static ───
  meta: GameMeta;                                    // Required

  // ─── Lifecycle ───
  init(events: EventSystem): void | Promise<void>;   // Required
  start(): void;                                      // Required
  pause(): void;                                      // Required
  resume(): void;                                     // Required
  update(deltaMs: number): void;                      // Required
  save(): GameState;                                  // Required
  load(state: GameState): void;                       // Required
  destroy(): void;                                    // Required

  // ─── Queries ───
  getScore(): number;                                 // Required
  isGameOver(): boolean;                              // Required
  isWon(): boolean;                                   // Required
  getResult(): GameResult;                            // Required

  // ─── Optional Capabilities ───
  undo?(): boolean;                                   // Optional
  redo?(): boolean;                                   // Optional
  canUndo?(): boolean;                                // Optional
  canRedo?(): boolean;                                // Optional
  hint?(): void;                                      // Optional
}
```

## The GameMeta Contract

Every game must provide static metadata:

```typescript
interface GameMeta {
  id: string;              // Unique: "2048", "sudoku", "minesweeper"
  name: string;            // Display: "2048", "Sudoku"
  description: string;     // 1-2 sentences
  icon: string;            // Emoji or icon reference
  category: GameCategory;  // "number" | "logic" | "word" | etc.
  difficulty: number;      // 1-5 scale
  estimatedMinutes: number;// Average session length
  tags: string[];          // For search/filtering
  version: string;         // SemVer
}
```

## Required Events

Every game MUST emit these events at the specified times:

| Event | When | Payload |
|-------|------|---------|
| `engine:game:start` | Game begins | `{ gameId }` |
| `engine:game:pause` | Game pauses | `{ gameId, reason? }` |
| `engine:game:resume` | Game resumes | `{ gameId }` |
| `engine:game:end` | Game over | `{ gameId, result }` |
| `score:update` | Score changes | `{ gameId, score }` |
| `save:request` | Save triggered | `{ gameId, state }` |

## Forbidden Patterns

These are **never** allowed in game code:

```typescript
// ❌ FORBIDDEN: Direct platform import
import { SaveService } from "@/platform";

// ❌ FORBIDDEN: Direct database access
import { db } from "@/db";

// ❌ FORBIDDEN: Direct localStorage (use SaveService via events)
localStorage.setItem("key", "value");

// ❌ FORBIDDEN: DOM manipulation outside renderer
document.getElementById("game");

// ❌ FORBIDDEN: Direct fetch to API
fetch("/api/saves");
```

## Allowed Patterns

```typescript
// ✅ ALLOWED: Event emission
this.events.emit(Events.SCORE_UPDATE, { score: this.score });

// ✅ ALLOWED: Event listening
this.events.on(Events.INPUT_TAP, (payload) => { ... });

// ✅ ALLOWED: Pure game logic
move(direction: "left" | "right") { /* ... */ }

// ✅ ALLOWED: State serialization
save(): GameState { return { board: this.board, score: this.score }; }
```

## Adding a New Game — Checklist

- [ ] Implement `GameModule` interface
- [ ] Define `GameMeta`
- [ ] Emit all required events
- [ ] Implement `save()` returning JSON-serializable state
- [ ] Implement `load()` handling partial/incomplete saves
- [ ] Register in `GameRegistry.ts`
- [ ] Create React renderer component
- [ ] Add renderer case in `GamePlayer.tsx`
- [ ] Write unit tests for game logic
- [ ] Write solver/solvability validator
- [ ] Create spec document in `docs/GAMES/`
- [ ] Verify 60 FPS on mid-range device
