---
id: ARC-001
title: Platform Architecture
status: APPROVED
---

# Platform Architecture

## System Overview

```
┌─────────────────────────────────────────────────────────────────┐
│                         PLATFORM LAYER                           │
│  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐           │
│  │  Home     │ │ Settings │ │  Ads     │ │   IAP    │           │
│  │  Browser  │ │  Panel   │ │ Service  │ │ Service  │           │
│  └──────────┘ └──────────┘ └──────────┘ └──────────┘           │
│  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐           │
│  │  Save     │ │Analytics │ │Achievement│ │  Theme  │           │
│  │  Service  │ │ Service  │ │ Service  │ │ Engine  │           │
│  └──────────┘ └──────────┘ └──────────┘ └──────────┘           │
├─────────────────────────────────────────────────────────────────┤
│                         ENGINE LAYER                             │
│  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐           │
│  │  Engine   │ │  Event   │ │ Seeded   │ │Replay    │           │
│  │  (Loop)   │ │  Bus +   │ │ Random   │ │System    │           │
│  │          │ │Middleware│ │          │ │          │           │
│  └──────────┘ └──────────┘ └──────────┘ └──────────┘           │
│  ┌──────────┐ ┌──────────┐                                    │
│  │Performance│ │GameModule│                                    │
│  │ Monitor  │ │ Contract │                                    │
│  └──────────┘ └──────────┘                                    │
├─────────────────────────────────────────────────────────────────┤
│                         GAME MODULES                             │
│  ┌──────┐ ┌──────┐ ┌──────┐ ┌──────┐ ┌──────┐ ┌──────┐       │
│  │ 2048 │ │Sudoku │ │Mines │ │Cross │ │Word  │ │  +45 │       │
│  │      │ │      │ │sweep │ │word  │ │Search│ │ more │       │
│  └──────┘ └──────┘ └──────┘ └──────┘ └──────┘ └──────┘       │
└─────────────────────────────────────────────────────────────────┘
```

## Layer Responsibilities

### Platform Layer
| Component | Responsibility | Never Does |
|-----------|---------------|------------|
| Home Browser | Game discovery, search, categories | Game logic |
| Settings Panel | User preferences, theme selection | Game state |
| Save Service | Dual persistence (local + remote) | Puzzle generation |
| Analytics Service | Event tracking, batching | Game scoring |
| Achievement Service | Milestone tracking | Game rules |
| Theme Engine | CSS variable injection, theme switching | Game rendering |

### Engine Layer
| Component | Responsibility | Never Does |
|-----------|---------------|------------|
| Engine | Game loop, lifecycle orchestration | Game logic |
| Event Bus | Cross-layer communication | Direct state mutation |
| Middleware | Logging, rate limiting, validation | Business logic |
| Seeded Random | Deterministic number generation | UI rendering |
| Replay System | Record/playback sessions | Real-time gameplay |
| Performance Monitor | FPS/memory tracking | Game decisions |

### Game Layer
| Component | Responsibility | Never Does |
|-----------|---------------|------------|
| Game Module | Rules, logic, state, scoring | Platform services |
| Game Renderer | Visual representation | Game logic |
| Game Assets | Icons, sounds, animations | Platform UI |

## Data Flow

### Input Flow
```
User Touch/Key → React Component → Game Module method → State Update → Re-render
                     ↓
              Event Bus (optional: INPUT_TAP, INPUT_SWIPE)
                     ↓
              Middleware Chain (rate limit, validate, log)
                     ↓
              Listeners (analytics, haptics, audio)
```

### Save Flow
```
Game State → SaveService.save() → localStorage (immediate)
                                → /api/saves (async)
                                → PostgreSQL (server)
```

### Event Flow
```
Emitter → EventSystem.emit(name, payload)
  → Middleware chain (logger, rate limiter, validator)
  → If not cancelled → Regular listeners (on)
                     → Once listeners (once)
```

## Trust Boundaries

| Boundary | Trust Level | Protection |
|----------|-------------|------------|
| Game → Engine | HIGH | GameModule contract |
| Engine → Platform | HIGH | Event bus only |
| Client → API | LOW | Rate limiting, input sanitization |
| API → Database | HIGH | Parameterized queries (Drizzle ORM) |
| User → UI | LOW | XSS sanitization, CSP headers |

## Performance Budget

| Metric | Target | Measurement |
|--------|--------|-------------|
| FPS | ≥60 | PerformanceMonitor |
| Initial Load | <2s | Lighthouse |
| Time to Interactive | <3s | Lighthouse |
| APK Size (initial) | <100MB | Bundle analysis |
| Memory Usage | <150MB | Chrome DevTools |
| API Response | <200ms | p95 latency |
| Save Latency | <50ms (local) | Performance.now() |
