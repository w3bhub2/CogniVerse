---
id: DATA-001
title: Analytics
status: APPROVED
---

# Analytics — Event Naming & Schemas

## Event Naming Convention

```
{domain}:{action}

Examples:
  game:start
  game:end
  game:pause
  game:resume
  score:update
  achievement:unlock
  ad:shown
  ad:clicked
  iap:purchase
  settings:change
  theme:change
```

## Standard Event Schemas

### Game Events (Required for all games)
```typescript
// Game started
{ event: "game:start", properties: { gameId, seed, difficulty } }

// Game ended
{ event: "game:end", properties: { gameId, score, won, moves, timeMs, reason } }

// Game paused
{ event: "game:pause", properties: { gameId, reason } }
```

### Score Events
```typescript
{ event: "score:update", properties: { gameId, score, delta } }
{ event: "score:milestone", properties: { gameId, milestone, score } }
```

### Engagement Events
```typescript
{ event: "session:start", properties: { platform, version } }
{ event: "session:end", properties: { durationMs } }
{ event: "game:resume_return", properties: { gameId, awayMs } }
```

### Monetization Events (Future)
```typescript
{ event: "ad:shown", properties: { gameId, adType, placement } }
{ event: "ad:completed", properties: { gameId, adType, reward } }
{ event: "iap:purchase", properties: { productId, price, currency } }
{ event: "iap:restore", properties: { productId } }
```

## Event Validation Rules
1. Event name: lowercase, colon-separated, max 50 chars
2. Properties: flat object, max 20 keys
3. String values: max 200 chars
4. Numeric values: integers preferred
5. No PII in event properties (no email, name, device ID)

## Retention Analysis
| Metric | Definition |
|--------|-----------|
| D1 Retention | Users who return on day 1 |
| D7 Retention | Users who return on day 7 |
| D30 Retention | Users who return on day 30 |
| Session Length | Time from start to end |
| Sessions per Day | Average sessions per active user |
