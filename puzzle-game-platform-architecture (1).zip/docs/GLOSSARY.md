---
id: GOV-002
title: Glossary
status: APPROVED
---

# Glossary — Canonical Definitions

| Term | Definition |
|------|-----------|
| **Platform** | The shell application that hosts games, manages settings, ads, IAP, and analytics. Never contains game logic. |
| **Engine** | The reusable runtime layer: lifecycle, events, input, save, performance monitoring. Shared by all games. |
| **Game Module** | A self-contained implementation of `GameModule` interface. Owns only rules, logic, and game-specific UI. |
| **Game Renderer** | The React component that visually represents a Game Module's state. |
| **Game Registry** | Central index that maps game IDs to their factory functions and metadata. |
| **Event Bus** | The publish/subscribe system that decouples Engine from Platform from Games. |
| **Middleware** | Interceptor chain on the event bus for logging, rate limiting, validation. |
| **Save Slot** | A serialized snapshot of game state stored locally (localStorage) and/or remotely (PostgreSQL). |
| **Save Conflict** | When local save and cloud save differ; requires resolution strategy. |
| **Seed** | A numeric value that makes `SeededRandom` produce a deterministic sequence. Used for puzzle generation and replays. |
| **Replay** | A recorded sequence of inputs with timestamps that can re-drive a game deterministically. |
| **Difficulty Tier** | A named preset (easy/medium/hard/expert) controlling puzzle parameters. |
| **Achievement** | A milestone condition that, when met, grants a badge and emits `ACHIEVEMENT_UNLOCKED`. |
| **Theme** | A complete color palette + typography + spacing definition applied via CSS custom properties. |
| **Haptic Pattern** | A named vibration sequence (success, failure, tap) mapped to platform vibration API. |
| **Analytics Event** | A structured record (name + properties + timestamp) sent to the analytics pipeline. |
| **Remote Config** | Server-side key-value pairs that modify app behavior without an app update. |
| **Feature Flag** | A boolean toggle that enables/disables code paths at runtime. |
| **LiveOps** | Time-limited events, seasonal content, and scheduled changes to the live game. |
| **A/B Test** | An experiment where users are randomly assigned to control or variant groups. |
| **eCPM** | Effective cost per mille — revenue per 1000 ad impressions. |
| **IAP** | In-App Purchase — digital goods bought with real money. |
| **Capacitor** | A native runtime wrapper that bridges web code to native Android/iOS APIs. |
| **AAB** | Android App Bundle — Google's recommended publishing format. |
| **IARC** | International Age Rating Coalition — content rating system for apps. |
| **GDPR** | General Data Protection Regulation — EU data privacy law. |
| **COPPA** | Children's Online Privacy Protection Act — US law for children under 13. |
