---
id: GOV-004
title: Constitution — Non-Negotiable Principles
status: APPROVED
---

# Constitution

These principles are **non-negotiable**. No feature, deadline, or pressure may override them.

---

## 1. Separation of Concerns

The **Game Layer** must NEVER access Platform internal classes.
The **Platform Layer** must NEVER contain game-specific logic.
Communication happens ONLY through the Event Bus and the `GameModule` contract.

```
Game → (events) → Engine → (events) → Platform
Platform → (events) → Engine → (events) → Game
```

No direct imports across layers.

## 2. Offline-First

Every game must be fully playable without an internet connection.
- Save/load works locally (localStorage)
- Scores are queued and synced when online
- Ads gracefully degrade (no crash if ad fails to load)
- Analytics queues offline and batches on reconnect

## 3. Guest-First

No account required to play. Authentication is optional and additive.
- All data stored locally by default
- Cloud sync is opt-in, not required
- No forced sign-in walls
- Data export/deletion available without account

## 4. 60 FPS Minimum

Every game must maintain 60 FPS on a mid-range Android device (Snapdragon 665 / 4GB RAM).
- Profile before merging
- No layout thrashing
- No unnecessary re-renders
- Use `requestAnimationFrame` for game loops
- Lazy-load non-critical components

## 5. Type Safety

Zero `any` types in production code.
- TypeScript strict mode enabled
- All public interfaces documented with JSDoc
- All game state is serializable and type-checked
- Event payloads are typed

## 6. Solvability Guarantee

No puzzle may ship without a validated solver proving solvability.
- Sudoku: backtracking solver verifies unique solution
- Minesweeper: first-click safety zone guaranteed
- 2048: always has at least one valid move after generation

## 7. Fair Monetization

No pay-to-win. No dark patterns. No manipulative UX.
- Ads are opt-in (rewarded) or clearly dismissable
- IAP enhances convenience, not competitive advantage
- Difficulty is never artificially inflated to sell hints
- All purchases are refundable per Google Play policy

## 8. Documentation First

Every system is documented before or alongside implementation.
- Every public interface has JSDoc
- Every architecture decision has an ADR
- Every game has a spec document
- Documentation evolves with code

## 9. Testable by Default

Every system is designed for testability.
- Game logic is pure functions (no DOM dependency)
- Engine is injectable (events, performance monitor)
- Services have no singletons in test mode
- 90%+ coverage target for game logic

## 10. Accessibility is Not Optional

Every game must be playable by users with disabilities.
- Keyboard navigation for all controls
- Screen reader labels on interactive elements
- High contrast mode support
- Reduce motion respect
- Minimum 44px touch targets
- Color is never the sole information carrier
