#!/bin/bash
#
# Build a standalone game APK/AAB
#
# Usage:
#   ./scripts/build-standalone.sh 2048
#   ./scripts/build-standalone.sh sudoku
#   ./scripts/build-standalone.sh minesweeper
#
# This script:
# 1. Sets the STANDALONE_GAME env var
# 2. Builds a static export with only the selected game
# 3. Copies to Capacitor Android project
# 4. Builds the Android AAB
#
# Prerequisites:
#   - Android SDK installed
#   - Capacitor Android project added (npx cap add android)
#   - Java 17+ for Gradle

set -e

GAME_ID="${1:?Usage: ./scripts/build-standalone.sh <game-id>}"

# Validate game ID
VALID_GAMES="2048 sudoku minesweeper"
if ! echo "$VALID_GAMES" | grep -qw "$GAME_ID"; then
  echo "Error: Invalid game ID '$GAME_ID'"
  echo "Valid games: $VALID_GAMES"
  exit 1
fi

echo "═══════════════════════════════════════"
echo "  Building standalone: $GAME_ID"
echo "═══════════════════════════════════════"

# Step 1: Build static export
echo ""
echo "▶ Step 1: Building static export..."
STANDALONE_GAME="$GAME_ID" npm run build

# Step 2: Copy to Capacitor
echo ""
echo "▶ Step 2: Syncing to Capacitor..."
npx cap sync android

# Step 3: Build Android AAB
echo ""
echo "▶ Step 3: Building Android AAB..."
cd android
./gradlew bundleRelease
cd ..

echo ""
echo "═══════════════════════════════════════"
echo "  ✅ Build complete!"
echo "  AAB: android/app/build/outputs/bundle/release/"
echo "═══════════════════════════════════════"
