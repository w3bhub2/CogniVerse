// Keep the schema entrypoint present so models can define tables and run
// `npx drizzle-kit push` without bootstrapping Drizzle config first.
/**
 * Database Schema — All PostgreSQL tables for the Puzzle Platform.
 *
 * Tables:
 *   - game_saves: Persistent game save data
 *   - game_scores: High scores and leaderboard data
 *   - achievements: Unlocked achievements per user
 *   - analytics_events: Server-side analytics storage
 *
 * Future Extension Points:
 *   - users table (when auth is added)
 *   - multiplayer tables
 *   - IAP receipts
 *   - leaderboards
 */

import {
  pgTable,
  serial,
  text,
  integer,
  bigint,
  boolean,
  jsonb,
  timestamp,
  index,
} from "drizzle-orm/pg-core";

/**
 * Game saves — one row per active save per game.
 */
export const gameSaves = pgTable(
  "game_saves",
  {
    id: serial("id").primaryKey(),
    gameId: text("game_id").notNull(),
    state: jsonb("state").notNull(),
    score: integer("score").default(0).notNull(),
    moves: integer("moves").default(0).notNull(),
    timeElapsed: integer("time_elapsed").default(0).notNull(),
    version: text("version").default("1.0.0").notNull(),
    createdAt: timestamp("created_at").defaultNow().notNull(),
    updatedAt: timestamp("updated_at").defaultNow().notNull(),
  },
  (table) => [
    index("game_saves_game_id_idx").on(table.gameId),
  ]
);

/**
 * Game scores — historical score records for leaderboards.
 */
export const gameScores = pgTable(
  "game_scores",
  {
    id: serial("id").primaryKey(),
    gameId: text("game_id").notNull(),
    score: integer("score").notNull(),
    won: boolean("won").default(false).notNull(),
    moves: integer("moves").default(0).notNull(),
    timeElapsed: integer("time_elapsed").default(0).notNull(),
    metrics: jsonb("metrics"),
    playedAt: timestamp("played_at").defaultNow().notNull(),
  },
  (table) => [
    index("game_scores_game_id_idx").on(table.gameId),
    index("game_scores_score_idx").on(table.score),
  ]
);

/**
 * Achievements — tracks which achievements are unlocked.
 */
export const achievements = pgTable(
  "achievements",
  {
    id: serial("id").primaryKey(),
    achievementId: text("achievement_id").notNull().unique(),
    name: text("name").notNull(),
    description: text("description").notNull(),
    icon: text("icon"),
    unlockedAt: timestamp("unlocked_at"),
  }
);

/**
 * Analytics events — server-side event storage.
 */
export const analyticsEvents = pgTable(
  "analytics_events",
  {
    id: serial("id").primaryKey(),
    name: text("name").notNull(),
    properties: jsonb("properties").default({}).notNull(),
    sessionId: text("session_id"),
    timestamp: bigint("timestamp", { mode: "number" }).notNull(),
    receivedAt: timestamp("received_at").defaultNow().notNull(),
  },
  (table) => [
    index("analytics_events_name_idx").on(table.name),
    index("analytics_events_timestamp_idx").on(table.timestamp),
  ]
);
