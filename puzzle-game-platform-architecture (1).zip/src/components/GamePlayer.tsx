"use client";

import { useCallback, useState, useEffect, lazy, Suspense } from "react";
import Link from "next/link";
import { motion } from "framer-motion";
import { gameRegistry } from "@/games";
import { SaveService } from "@/platform/services/SaveService";
import { Button } from "@/components/ui";
import { ErrorBoundary } from "./ErrorBoundary";
import { LoadingScreen } from "./LoadingScreen";
import { PlayerBadge } from "./PlayerBadge";
import { themeEngine } from "@/platform/services/ThemeEngine";

// Lazy load game renderers for code splitting
const Game2048Renderer = lazy(() =>
  import("./game/Game2048Renderer").then((m) => ({ default: m.Game2048Renderer }))
);
const SudokuRenderer = lazy(() =>
  import("./game/SudokuRenderer").then((m) => ({ default: m.SudokuRenderer }))
);
const MinesweeperRenderer = lazy(() =>
  import("./game/MinesweeperRenderer").then((m) => ({ default: m.MinesweeperRenderer }))
);

interface Props {
  gameId: string;
}

const GAME_COLORS: Record<string, string> = {
  "2048": "#f59e0b",
  sudoku: "#6366f1",
  minesweeper: "#ef4444",
};

function GameRenderer({
  gameId,
  props,
}: {
  gameId: string;
  props: {
    onSave?: (state: Record<string, unknown>) => void;
    savedState?: Record<string, unknown> | null;
  };
}) {
  switch (gameId) {
    case "2048":
      return <Game2048Renderer {...props} />;
    case "sudoku":
      return <SudokuRenderer {...props} />;
    case "minesweeper":
      return <MinesweeperRenderer {...props} />;
    default:
      return (
        <div className="text-center py-20 animate-fade-in">
          <div className="text-6xl mb-4">🚧</div>
          <p className="text-lg font-semibold text-[var(--color-text)]">
            Coming Soon
          </p>
          <p className="text-sm text-[var(--color-text-muted)] mt-2">
            This game is on the roadmap and being developed.
          </p>
          <Link href="/">
            <Button variant="secondary" className="mt-6">
              ← Browse Games
            </Button>
          </Link>
        </div>
      );
  }
}

export function GamePlayer({ gameId }: Props) {
  const [savedState, setSavedState] = useState<Record<string, unknown> | null>(null);
  const [isLoaded, setIsLoaded] = useState(false);

  const meta = gameRegistry.getMeta(gameId);
  const saveService = new SaveService(gameId);

  // Apply game accent color
  useEffect(() => {
    const color = GAME_COLORS[gameId];
    if (color) {
      themeEngine.applyGameAccent(color);
    }
    return () => themeEngine.resetGameAccent();
  }, [gameId]);

  // Load saved state
  useEffect(() => {
    const loadSave = async () => {
      try {
        const save = await saveService.load();
        if (save?.state) {
          setSavedState(save.state as Record<string, unknown>);
        }
      } catch {
        // Silently fail — start fresh
      }
      setIsLoaded(true);
    };
    loadSave();
  }, [gameId]); // eslint-disable-line react-hooks/exhaustive-deps

  const handleSave = useCallback(
    async (state: Record<string, unknown>) => {
      await saveService.save(state);
    },
    [saveService] // eslint-disable-line react-hooks/exhaustive-deps
  );

  return (
    <div className="min-h-screen flex flex-col bg-[var(--color-background)]">
      {/* Header */}
      <header className="sticky top-0 z-30 glass border-b border-[var(--color-border)]">
        <div className="max-w-2xl mx-auto px-4 py-3 flex items-center gap-3">
          <Link href="/" aria-label="Back to games">
            <Button variant="ghost" size="sm">
              ← Back
            </Button>
          </Link>

          <div className="flex-1 min-w-0">
            <h1 className="text-lg font-bold text-[var(--color-text)] truncate">
              <span className="mr-2">{meta?.icon}</span>
              {meta?.name ?? gameId}
            </h1>
          </div>

          <PlayerBadge />
          {meta && (
            <span className="hidden sm:inline-flex items-center px-2 py-1 rounded-lg text-xs font-medium bg-[var(--color-surface-hover)] text-[var(--color-text-muted)]">
              {"⭐".repeat(meta.difficulty)}
            </span>
          )}
        </div>
      </header>

      {/* Game area */}
      <div className="flex-1 flex items-start justify-center p-4 sm:p-6">
        <ErrorBoundary gameId={gameId}>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4 }}
            className="w-full max-w-lg"
          >
            {isLoaded ? (
              <Suspense fallback={<LoadingScreen text="Loading game..." />}>
                <GameRenderer
                  gameId={gameId}
                  props={{
                    onSave: handleSave,
                    savedState,
                  }}
                />
              </Suspense>
            ) : (
              <LoadingScreen text="Loading game..." />
            )}
          </motion.div>
        </ErrorBoundary>
      </div>
    </div>
  );
}
