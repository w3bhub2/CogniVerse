"use client";

import { useState, useEffect } from "react";
import { Modal } from "./ui/Modal";
import { Button } from "./ui/Button";
import { themeEngine, type Theme } from "@/platform/services/ThemeEngine";
import { SettingsService, type UserSettings } from "@/platform/services/SettingsService";

interface Props {
  open: boolean;
  onClose: () => void;
}

export function SettingsPanel({ open, onClose }: Props) {
  const [settings, setSettings] = useState<UserSettings | null>(null);
  const [themes, setThemes] = useState<{ id: string; name: string; dark: boolean }[]>([]);
  const [currentTheme, setCurrentTheme] = useState<string>("");

  useEffect(() => {
    if (open) {
      const svc = new SettingsService();
      setSettings(svc.getAll());
      setThemes(themeEngine.getAvailable());
      setCurrentTheme(themeEngine.getCurrent().id);
    }
  }, [open]);

  const updateSetting = <K extends keyof UserSettings>(
    key: K,
    value: UserSettings[K]
  ) => {
    if (!settings) return;
    const updated = { ...settings, [key]: value };
    setSettings(updated);
    const svc = new SettingsService();
    svc.set(key, value);

    if (key === "theme") {
      const themeMap: Record<string, string> = {
        light: "light",
        dark: "dark",
        system: window.matchMedia("(prefers-color-scheme: dark)").matches
          ? "dark"
          : "light",
      };
      const themeId = themeMap[value as string] ?? "light";
      themeEngine.apply(themeId);
      setCurrentTheme(themeId);
    }
  };

  if (!settings) return null;

  return (
    <Modal open={open} onClose={onClose} title="⚙️ Settings">
      <div className="space-y-6">
        {/* Theme */}
        <div>
          <h3 className="text-sm font-semibold text-slate-900 dark:text-white mb-3">
            Theme
          </h3>
          <div className="grid grid-cols-2 gap-2">
            {themes.map((t) => (
              <button
                key={t.id}
                onClick={() => {
                  themeEngine.apply(t.id);
                  setCurrentTheme(t.id);
                  updateSetting("theme", t.id as UserSettings["theme"]);
                }}
                className={`p-3 rounded-xl text-sm font-medium transition-all border-2 ${
                  currentTheme === t.id
                    ? "border-indigo-500 bg-indigo-50 dark:bg-indigo-900/30"
                    : "border-slate-200 dark:border-slate-700 hover:border-slate-300"
                }`}
              >
                <span className="text-lg mb-1 block">
                  {t.dark ? "🌙" : "☀️"}
                </span>
                {t.name}
              </button>
            ))}
          </div>
        </div>

        {/* Sound */}
        <div>
          <h3 className="text-sm font-semibold text-slate-900 dark:text-white mb-3">
            Audio
          </h3>
          <div className="space-y-2">
            <ToggleRow
              label="Sound Effects"
              icon="🔊"
              checked={settings.soundEnabled}
              onChange={(v) => updateSetting("soundEnabled", v)}
            />
            <ToggleRow
              label="Music"
              icon="🎵"
              checked={settings.musicEnabled}
              onChange={(v) => updateSetting("musicEnabled", v)}
            />
            <ToggleRow
              label="Haptics"
              icon="📳"
              checked={settings.hapticsEnabled}
              onChange={(v) => updateSetting("hapticsEnabled", v)}
            />
          </div>
        </div>

        {/* Gameplay */}
        <div>
          <h3 className="text-sm font-semibold text-slate-900 dark:text-white mb-3">
            Gameplay
          </h3>
          <div className="space-y-2">
            <ToggleRow
              label="Show Timer"
              icon="⏱️"
              checked={settings.showTimer}
              onChange={(v) => updateSetting("showTimer", v)}
            />
            <ToggleRow
              label="Show Score"
              icon="📊"
              checked={settings.showScore}
              onChange={(v) => updateSetting("showScore", v)}
            />
            <ToggleRow
              label="Animations"
              icon="✨"
              checked={settings.animationsEnabled}
              onChange={(v) => updateSetting("animationsEnabled", v)}
            />
          </div>
        </div>

        {/* Accessibility */}
        <div>
          <h3 className="text-sm font-semibold text-slate-900 dark:text-white mb-3">
            Accessibility
          </h3>
          <div className="space-y-2">
            <ToggleRow
              label="High Contrast"
              icon="🔲"
              checked={settings.highContrast}
              onChange={(v) => updateSetting("highContrast", v)}
            />
            <ToggleRow
              label="Reduce Motion"
              icon="🔇"
              checked={settings.reduceMotion}
              onChange={(v) => updateSetting("reduceMotion", v)}
            />
            <div className="flex items-center justify-between py-2 px-3 rounded-xl bg-slate-50 dark:bg-slate-800">
              <span className="text-sm text-slate-700 dark:text-slate-300">
                🔤 Font Size
              </span>
              <div className="flex gap-1">
                {(["small", "medium", "large"] as const).map((size) => (
                  <Button
                    key={size}
                    variant={settings.fontSize === size ? "primary" : "ghost"}
                    size="sm"
                    onClick={() => updateSetting("fontSize", size)}
                  >
                    {size === "small" ? "A" : size === "medium" ? "A" : "A"}
                  </Button>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Reset */}
        <Button variant="danger" fullWidth onClick={() => {
          const svc = new SettingsService();
          svc.reset();
          setSettings(svc.getAll());
          themeEngine.apply("light");
          setCurrentTheme("light");
        }}>
          Reset All Settings
        </Button>
      </div>
    </Modal>
  );
}

function ToggleRow({
  label,
  icon,
  checked,
  onChange,
}: {
  label: string;
  icon: string;
  checked: boolean;
  onChange: (v: boolean) => void;
}) {
  return (
    <div className="flex items-center justify-between py-2 px-3 rounded-xl bg-slate-50 dark:bg-slate-800">
      <span className="text-sm text-slate-700 dark:text-slate-300">
        {icon} {label}
      </span>
      <button
        onClick={() => onChange(!checked)}
        className={`relative w-10 h-6 rounded-full transition-colors duration-200 ${
          checked
            ? "bg-indigo-600"
            : "bg-slate-300 dark:bg-slate-600"
        }`}
        role="switch"
        aria-checked={checked}
        aria-label={label}
      >
        <span
          className={`absolute top-0.5 left-0.5 w-5 h-5 bg-white rounded-full shadow-sm transition-transform duration-200 ${
            checked ? "translate-x-4" : ""
          }`}
        />
      </button>
    </div>
  );
}
