"use client";

import { motion } from "framer-motion";

/**
 * LoadingScreen — Full-screen loading animation for game transitions.
 */
export function LoadingScreen({ text = "Loading..." }: { text?: string }) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/80 backdrop-blur-sm">
      <motion.div
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: 1, scale: 1 }}
        className="text-center"
      >
        {/* Animated puzzle pieces */}
        <div className="relative w-20 h-20 mx-auto mb-6">
          {[0, 1, 2, 3].map((i) => (
            <motion.div
              key={i}
              className="absolute w-8 h-8 bg-indigo-500 rounded-lg"
              style={{
                top: i < 2 ? 0 : "50%",
                left: i % 2 === 0 ? 0 : "50%",
              }}
              animate={{
                rotate: [0, 90, 180, 270, 360],
                scale: [1, 1.1, 1, 1.1, 1],
              }}
              transition={{
                duration: 2,
                delay: i * 0.2,
                repeat: Infinity,
                ease: "easeInOut",
              }}
            />
          ))}
        </div>
        <motion.p
          className="text-white/80 text-sm font-medium"
          animate={{ opacity: [0.5, 1, 0.5] }}
          transition={{ duration: 1.5, repeat: Infinity }}
        >
          {text}
        </motion.p>
      </motion.div>
    </div>
  );
}
