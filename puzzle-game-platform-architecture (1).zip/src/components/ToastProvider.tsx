"use client";

import { Toaster } from "react-hot-toast";
import { useEffect } from "react";
import { eventBus, Events } from "@/engine";
import toast from "react-hot-toast";

/**
 * ToastProvider — Global notification system.
 *
 * Listens for platform events and shows toast notifications.
 * Also provides a hook for manual toasts.
 */
export function ToastProvider() {
  useEffect(() => {
    const unsubAchievement = eventBus.on(
      Events.ACHIEVEMENT_UNLOCKED,
      (payload) => {
        const { icon, name, description } = payload as {
          icon: string;
          name: string;
          description: string;
        };
        toast.success(
          `${icon} ${name} — ${description}`,
          {
            duration: 4000,
            style: {
              background: "var(--color-surface, #1e293b)",
              color: "var(--color-text, #f1f5f9)",
              border: "1px solid var(--color-border, #334155)",
              borderRadius: "var(--border-radius, 12px)",
            },
          }
        );
      }
    );

    const unsubGameEnd = eventBus.on(Events.GAME_END, (payload) => {
      const { result } = payload as {
        result: { score: number; won: boolean };
      };
      if (result.won) {
        toast.success(
          `🏆 Victory! Score: ${result.score.toLocaleString()}`,
          {
            duration: 3000,
          }
        );
      }
    });

    return () => {
      unsubAchievement();
      unsubGameEnd();
    };
  }, []);

  return (
    <Toaster
      position="top-center"
      toastOptions={{
        duration: 3000,
        style: {
          background: "var(--color-surface, #1e293b)",
          color: "var(--color-text, #f1f5f9)",
          border: "1px solid var(--color-border, #334155)",
          borderRadius: "var(--border-radius, 12px)",
          padding: "12px 16px",
          fontSize: "14px",
          boxShadow: "0 8px 32px var(--color-shadow, rgba(0,0,0,0.12))",
        },
        success: {
          iconTheme: {
            primary: "var(--color-success, #10b981)",
            secondary: "white",
          },
        },
        error: {
          iconTheme: {
            primary: "var(--color-error, #ef4444)",
            secondary: "white",
          },
        },
      }}
    />
  );
}
