"use client";

import { Button } from "./Button";

interface GameOverOverlayProps {
  visible: boolean;
  won: boolean;
  score: number;
  onRestart: () => void;
  onHome: () => void;
}

export function GameOverOverlay({
  visible,
  won,
  score,
  onRestart,
  onHome,
}: GameOverOverlayProps) {
  if (!visible) return null;

  return (
    <div className="absolute inset-0 z-40 flex items-center justify-center bg-black/60 backdrop-blur-sm">
      <div className="text-center p-8 bg-white dark:bg-slate-800 rounded-3xl shadow-2xl max-w-sm mx-4">
        <div className="text-6xl mb-4">{won ? "🎉" : "😔"}</div>
        <h2 className="text-2xl font-bold text-slate-900 dark:text-white mb-2">
          {won ? "You Win!" : "Game Over"}
        </h2>
        <p className="text-lg text-slate-600 dark:text-slate-400 mb-6">
          Score:{" "}
          <span className="font-bold text-indigo-600 dark:text-indigo-400">
            {score.toLocaleString()}
          </span>
        </p>
        <div className="flex gap-3">
          <Button variant="secondary" onClick={onHome} fullWidth>
            Home
          </Button>
          <Button onClick={onRestart} fullWidth>
            Play Again
          </Button>
        </div>
      </div>
    </div>
  );
}
