"use client";

import { useEffect, useState } from "react";

interface TimerProps {
  /** Elapsed time in milliseconds */
  elapsed: number;
  /** Whether the timer is running */
  running?: boolean;
  className?: string;
}

function formatTime(ms: number): string {
  const totalSeconds = Math.floor(ms / 1000);
  const hours = Math.floor(totalSeconds / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = totalSeconds % 60;

  if (hours > 0) {
    return `${hours}:${String(minutes).padStart(2, "0")}:${String(seconds).padStart(2, "0")}`;
  }
  return `${String(minutes).padStart(2, "0")}:${String(seconds).padStart(2, "0")}`;
}

export function Timer({ elapsed, running = true, className = "" }: TimerProps) {
  const [display, setDisplay] = useState(formatTime(elapsed));

  useEffect(() => {
    setDisplay(formatTime(elapsed));
  }, [elapsed]);

  return (
    <div className={`text-center ${className}`}>
      <p className="text-xs uppercase tracking-wider text-slate-500 dark:text-slate-400">
        Time
      </p>
      <p className="text-2xl font-bold text-slate-900 dark:text-white tabular-nums">
        {display}
        {running && (
          <span className="inline-block w-2 h-2 ml-1 bg-green-500 rounded-full animate-pulse" />
        )}
      </p>
    </div>
  );
}
