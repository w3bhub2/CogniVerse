"use client";

interface ScoreDisplayProps {
  score: number;
  label?: string;
  best?: number;
  className?: string;
}

export function ScoreDisplay({
  score,
  label = "Score",
  best,
  className = "",
}: ScoreDisplayProps) {
  return (
    <div className={`flex items-center gap-4 ${className}`}>
      <div className="text-center">
        <p className="text-xs uppercase tracking-wider text-slate-500 dark:text-slate-400">
          {label}
        </p>
        <p className="text-2xl font-bold text-slate-900 dark:text-white tabular-nums">
          {score.toLocaleString()}
        </p>
      </div>
      {typeof best === "number" && (
        <div className="text-center">
          <p className="text-xs uppercase tracking-wider text-slate-500 dark:text-slate-400">
            Best
          </p>
          <p className="text-2xl font-bold text-indigo-600 dark:text-indigo-400 tabular-nums">
            {best.toLocaleString()}
          </p>
        </div>
      )}
    </div>
  );
}
