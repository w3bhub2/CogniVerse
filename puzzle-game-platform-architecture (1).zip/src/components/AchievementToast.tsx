"use client";

import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { eventBus, Events } from "@/engine";

interface Achievement {
  id: string;
  name: string;
  icon: string;
  description: string;
}

/**
 * AchievementToast — Animated achievement notification that slides in.
 */
export function AchievementToast() {
  const [queue, setQueue] = useState<Achievement[]>([]);
  const [current, setCurrent] = useState<Achievement | null>(null);

  useEffect(() => {
    const unsub = eventBus.on(
      Events.ACHIEVEMENT_UNLOCKED,
      (payload) => {
        const a = payload as unknown as Achievement;
        setQueue((prev) => [...prev, a]);
      }
    );
    return unsub;
  }, []);

  useEffect(() => {
    if (!current && queue.length > 0) {
      setCurrent(queue[0]);
      setQueue((prev) => prev.slice(1));
    }
  }, [current, queue]);

  useEffect(() => {
    if (current) {
      const timer = setTimeout(() => setCurrent(null), 4000);
      return () => clearTimeout(timer);
    }
  }, [current]);

  return (
    <div className="fixed top-4 right-4 z-[100] pointer-events-none">
      <AnimatePresence>
        {current && (
          <motion.div
            key={current.id}
            initial={{ x: 100, opacity: 0, scale: 0.9 }}
            animate={{ x: 0, opacity: 1, scale: 1 }}
            exit={{ x: 100, opacity: 0, scale: 0.9 }}
            transition={{ type: "spring", stiffness: 400, damping: 25 }}
            className="pointer-events-auto"
          >
            <div className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white p-4 rounded-2xl shadow-2xl max-w-xs backdrop-blur-lg border border-white/20">
              <div className="flex items-center gap-3">
                <div className="text-3xl animate-bounce">{current.icon}</div>
                <div>
                  <p className="text-xs uppercase tracking-wider text-indigo-200">
                    Achievement Unlocked!
                  </p>
                  <p className="font-bold text-sm">{current.name}</p>
                  <p className="text-xs text-indigo-200 mt-0.5">
                    {current.description}
                  </p>
                </div>
              </div>
              {/* Animated progress bar */}
              <div className="mt-3 h-1 bg-white/20 rounded-full overflow-hidden">
                <motion.div
                  className="h-full bg-white/80 rounded-full"
                  initial={{ width: "100%" }}
                  animate={{ width: "0%" }}
                  transition={{ duration: 4, ease: "linear" }}
                />
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
