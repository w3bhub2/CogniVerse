"use client";

import { useState } from "react";
import Link from "next/link";
import Image from "next/image";
import { motion } from "framer-motion";
import type { GameMeta, GameCategory } from "@/engine";
import { Card, Button } from "@/components/ui";
import { SettingsPanel } from "./SettingsPanel";
import { PlayerBadge } from "./PlayerBadge";

const CATEGORIES: { id: GameCategory | "all"; label: string; icon: string }[] = [
  { id: "all", label: "All Games", icon: "🎮" },
  { id: "number", label: "Number", icon: "🔢" },
  { id: "logic", label: "Logic", icon: "🧠" },
  { id: "word", label: "Word", icon: "📝" },
  { id: "strategy", label: "Strategy", icon: "♟️" },
  { id: "memory", label: "Memory", icon: "🧠" },
  { id: "visual", label: "Visual", icon: "👁️" },
  { id: "puzzle", label: "Puzzle", icon: "🧩" },
];

const DIFFICULTY_LABELS: Record<number, { label: string; color: string }> = {
  1: { label: "Easy", color: "text-green-500" },
  2: { label: "Medium", color: "text-yellow-500" },
  3: { label: "Hard", color: "text-orange-500" },
  4: { label: "Expert", color: "text-red-500" },
  5: { label: "Master", color: "text-purple-500" },
};

interface Props {
  games: GameMeta[];
}

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.06 },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.3 } },
};

export function GameBrowser({ games }: Props) {
  const [selectedCategory, setSelectedCategory] = useState<
    GameCategory | "all"
  >("all");
  const [search, setSearch] = useState("");
  const [settingsOpen, setSettingsOpen] = useState(false);

  const filteredGames = games.filter((game) => {
    const matchesCategory =
      selectedCategory === "all" || game.category === selectedCategory;
    const matchesSearch =
      search === "" ||
      game.name.toLowerCase().includes(search.toLowerCase()) ||
      game.tags.some((t) =>
        t.toLowerCase().includes(search.toLowerCase())
      );
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="min-h-screen">
      {/* ─── Hero Section ─── */}
      <div className="relative overflow-hidden hero-gradient">
        {/* Background image */}
        <div className="absolute inset-0 opacity-30">
          <Image
            src="/images/hero-bg.jpg"
            alt=""
            fill
            className="object-cover"
            priority
          />
        </div>

        {/* Floating decorative elements */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="absolute top-10 left-[10%] text-6xl opacity-20 animate-float">🧩</div>
          <div className="absolute top-20 right-[15%] text-5xl opacity-15 animate-float" style={{ animationDelay: "1s" }}>🎮</div>
          <div className="absolute bottom-10 left-[20%] text-4xl opacity-10 animate-float" style={{ animationDelay: "2s" }}>🔢</div>
          <div className="absolute bottom-20 right-[10%] text-5xl opacity-15 animate-float" style={{ animationDelay: "0.5s" }}>🧠</div>
        </div>

        {/* Content */}
        <div className="relative max-w-6xl mx-auto px-4 py-16 sm:py-24 text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/10 backdrop-blur-sm text-white/90 text-sm font-medium mb-6 border border-white/20">
              <span className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
              {games.length} Games Available
            </div>

            <h1 className="text-4xl sm:text-6xl lg:text-7xl font-bold text-white mb-4 tracking-tight">
              Puzzle Platform
            </h1>
            <p className="text-lg sm:text-xl text-white/80 max-w-2xl mx-auto mb-8">
              {games.length} premium casual puzzle games. One engine. Infinite fun.
              Challenge your mind with number puzzles, logic games, and more.
            </p>

            <div className="flex items-center justify-center gap-4">
              <Link href={`#${games[0]?.id ?? "2048"}`}>
                <Button
                  size="lg"
                  className="bg-white text-indigo-600 hover:bg-white/90 shadow-xl shadow-black/20 font-semibold"
                >
                  🎮 Start Playing
                </Button>
              </Link>
              <Button
                variant="ghost"
                size="lg"
                className="text-white border border-white/30 hover:bg-white/10"
                onClick={() => setSettingsOpen(true)}
              >
                ⚙️ Settings
              </Button>
            </div>
          </motion.div>
        </div>

        {/* Wave divider */}
        <div className="absolute bottom-0 left-0 right-0">
          <svg viewBox="0 0 1440 120" fill="none" className="w-full">
            <path
              d="M0 120L48 110C96 100 192 80 288 70C384 60 480 60 576 65C672 70 768 80 864 85C960 90 1056 90 1152 85C1248 80 1344 70 1392 65L1440 60V120H0Z"
              className="fill-[var(--color-background,#f8fafc)]"
            />
          </svg>
        </div>
      </div>

      {/* ─── Search & Categories ─── */}
      <div className="sticky top-0 z-30 bg-[var(--color-background)]/90 backdrop-blur-xl border-b border-[var(--color-border)]">
        <div className="max-w-6xl mx-auto px-4 py-4">
          {/* Player retention HUD */}
          <div className="flex justify-end mb-2">
            <PlayerBadge />
          </div>

          {/* Search bar */}
          <div className="relative mb-3">
            <span className="absolute left-3 top-1/2 -translate-y-1/2 text-[var(--color-text-muted)]">
              🔍
            </span>
            <input
              type="text"
              placeholder="Search games by name or tag..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-10 pr-4 py-3 rounded-2xl bg-[var(--color-surface)] border border-[var(--color-border)] text-[var(--color-text)] text-sm focus:ring-2 focus:ring-[var(--color-primary)] focus:border-transparent outline-none transition-all"
              aria-label="Search games"
            />
            {search && (
              <button
                onClick={() => setSearch("")}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-[var(--color-text-muted)] hover:text-[var(--color-text)]"
                aria-label="Clear search"
              >
                ✕
              </button>
            )}
          </div>

          {/* Category pills */}
          <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-hide">
            {CATEGORIES.map((cat) => (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`
                  flex items-center gap-1.5 px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap
                  transition-all duration-200 touch-target
                  ${
                    selectedCategory === cat.id
                      ? "bg-[var(--color-primary)] text-white shadow-md shadow-[var(--color-primary)]/25"
                      : "bg-[var(--color-surface)] text-[var(--color-text-secondary)] hover:bg-[var(--color-surface-hover)] border border-[var(--color-border)]"
                  }
                `}
                aria-pressed={selectedCategory === cat.id}
              >
                <span>{cat.icon}</span>
                <span>{cat.label}</span>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* ─── Game Grid ─── */}
      <main className="max-w-6xl mx-auto px-4 py-8">
        {filteredGames.length === 0 ? (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-center py-20"
          >
            <div className="text-6xl mb-4">🔍</div>
            <p className="text-lg text-[var(--color-text-secondary)]">
              No games found matching &ldquo;{search}&rdquo;
            </p>
            <Button
              variant="ghost"
              className="mt-4"
              onClick={() => {
                setSearch("");
                setSelectedCategory("all");
              }}
            >
              Clear Filters
            </Button>
          </motion.div>
        ) : (
          <motion.div
            variants={containerVariants}
            initial="hidden"
            animate="visible"
            key={`${selectedCategory}-${search}`}
            className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6"
          >
            {filteredGames.map((game) => {
              const diff = DIFFICULTY_LABELS[game.difficulty] ?? DIFFICULTY_LABELS[3];
              return (
                <motion.div key={game.id} variants={itemVariants}>
                  <Link href={`/play/${game.id}`} className="block h-full">
                    <Card hoverable className="p-6 h-full group relative overflow-hidden">
                      {/* Gradient accent bar */}
                      <div className="absolute top-0 left-0 right-0 h-1 hero-gradient opacity-0 group-hover:opacity-100 transition-opacity" />

                      <div className="flex items-start gap-4">
                        <div className="text-5xl flex-shrink-0 transition-transform group-hover:scale-110 group-hover:rotate-3">
                          {game.icon}
                        </div>
                        <div className="flex-1 min-w-0">
                          <h3 className="text-lg font-bold text-[var(--color-text)] group-hover:text-[var(--color-primary)] transition-colors">
                            {game.name}
                          </h3>
                          <p className="text-sm text-[var(--color-text-secondary)] line-clamp-2 mt-1">
                            {game.description}
                          </p>
                        </div>
                      </div>

                      <div className="mt-4 flex items-center gap-2 flex-wrap">
                        <span className="inline-flex items-center px-2.5 py-1 rounded-lg text-xs font-semibold bg-[var(--color-primary)]/10 text-[var(--color-primary)]">
                          {game.category}
                        </span>
                        <span className={`text-xs font-medium ${diff.color}`}>
                          {"⭐".repeat(game.difficulty)} {diff.label}
                        </span>
                        <span className="text-xs text-[var(--color-text-muted)]">
                          ~{game.estimatedMinutes}min
                        </span>
                      </div>

                      <div className="mt-3 flex gap-1.5 flex-wrap">
                        {game.tags.slice(0, 3).map((tag) => (
                          <span
                            key={tag}
                            className="inline-flex items-center px-2 py-0.5 rounded-md text-[10px] font-medium bg-[var(--color-surface-hover)] text-[var(--color-text-muted)]"
                          >
                            {tag}
                          </span>
                        ))}
                      </div>

                      {/* Play indicator */}
                      <div className="absolute bottom-4 right-4 opacity-0 group-hover:opacity-100 transition-all group-hover:translate-x-0 translate-x-2">
                        <span className="inline-flex items-center gap-1 px-3 py-1.5 rounded-full bg-[var(--color-primary)] text-white text-xs font-semibold shadow-lg">
                          Play →
                        </span>
                      </div>
                    </Card>
                  </Link>
                </motion.div>
              );
            })}
          </motion.div>
        )}

        {/* ─── Coming Soon ─── */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mt-20 text-center"
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-[var(--color-primary)]/10 text-[var(--color-primary)] text-sm font-medium mb-4">
            🚀 Phase 2 Coming Soon
          </div>
          <h2 className="text-2xl font-bold text-[var(--color-text)] mb-3">
            More Games On The Way
          </h2>
          <p className="text-[var(--color-text-secondary)] max-w-lg mx-auto">
            Crossword, Word Search, Jigsaw, Sliding Puzzle, Nonogram, Kakuro,
            Solitaire, Mahjong, Match-3, and many more premium casual games.
          </p>
          <div className="flex justify-center gap-3 mt-6 flex-wrap">
            {["Crossword", "Word Search", "Jigsaw", "Nonogram", "Solitaire", "Match-3"].map(
              (name) => (
                <span
                  key={name}
                  className="px-3 py-1.5 rounded-lg bg-[var(--color-surface)] border border-[var(--color-border)] text-sm text-[var(--color-text-muted)]"
                >
                  {name}
                </span>
              )
            )}
          </div>
        </motion.div>
      </main>

      {/* ─── Footer ─── */}
      <footer className="border-t border-[var(--color-border)] bg-[var(--color-background-alt)]">
        <div className="max-w-6xl mx-auto px-4 py-8">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="text-center sm:text-left">
              <p className="font-bold text-[var(--color-text)]">🧩 Puzzle Platform</p>
              <p className="text-sm text-[var(--color-text-muted)]">
                Powered by a reusable game engine • {games.length} games available
              </p>
            </div>
            <div className="flex items-center gap-4">
              <Link href="/stats" className="text-sm text-[var(--color-text-secondary)] hover:text-[var(--color-primary)] transition-colors">
                📊 Stats
              </Link>
              <span className="text-[var(--color-border)]">|</span>
              <span className="text-sm text-[var(--color-text-muted)]">
                v1.0.0
              </span>
            </div>
          </div>
        </div>
      </footer>

      <SettingsPanel open={settingsOpen} onClose={() => setSettingsOpen(false)} />
    </div>
  );
}
