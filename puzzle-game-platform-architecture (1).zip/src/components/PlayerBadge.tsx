"use client";

import { useEffect, useState } from "react";
import { streakService } from "@/platform/services/StreakService";
import { progressionService } from "@/platform/services/ProgressionService";

/**
 * PlayerBadge — The visible face of the retention spine.
 * Shows the daily streak (loss aversion) and player level (mastery).
 * Self-updates on game completion via platform events.
 */
export function PlayerBadge() {
  const [streak, setStreak] = useState(0);
  const [level, setLevel] = useState(1);

  useEffect(() => {
    const sync = () => {
      setStreak(streakService.getStreak());
      setLevel(progressionService.getLevel());
    };
    sync();
    // Re-sync whenever a game ends (streak/XP may have changed)
    const handler = () => sync();
    window.addEventListener("focus", handler);
    const interval = setInterval(sync, 2000);
    return () => {
      window.removeEventListener("focus", handler);
      clearInterval(interval);
    };
  }, []);

  return (
    <div className="flex items-center gap-1.5">
      <span
        className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold bg-orange-100 dark:bg-orange-900/40 text-orange-600 dark:text-orange-300"
        title={`${streak}-day streak`}
      >
        🔥 {streak}
      </span>
      <span
        className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold bg-indigo-100 dark:bg-indigo-900/40 text-indigo-600 dark:text-indigo-300"
        title={`Player level ${level}`}
      >
        Lv {level}
      </span>
    </div>
  );
}
