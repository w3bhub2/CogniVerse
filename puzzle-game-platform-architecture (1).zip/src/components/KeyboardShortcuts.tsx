"use client";

import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Modal } from "./ui/Modal";

interface ShortcutGroup {
  title: string;
  shortcuts: { keys: string[]; description: string }[];
}

const SHORTCUTS: ShortcutGroup[] = [
  {
    title: "Navigation",
    shortcuts: [
      { keys: ["Esc"], description: "Pause game / Go back" },
      { keys: ["/"], description: "Focus search" },
      { keys: ["?"], description: "Show this help" },
    ],
  },
  {
    title: "2048 Controls",
    shortcuts: [
      { keys: ["↑", "↓", "←", "→"], description: "Move tiles" },
      { keys: ["W", "A", "S", "D"], description: "Move tiles (alt)" },
      { keys: ["Ctrl", "Z"], description: "Undo last move" },
      { keys: ["Ctrl", "Shift", "Z"], description: "Redo move" },
    ],
  },
  {
    title: "Sudoku Controls",
    shortcuts: [
      { keys: ["1-9"], description: "Place number" },
      { keys: ["Backspace"], description: "Erase cell" },
      { keys: ["P"], description: "Toggle pencil mode" },
      { keys: ["Arrow Keys"], description: "Navigate cells" },
    ],
  },
  {
    title: "Minesweeper Controls",
    shortcuts: [
      { keys: ["Click"], description: "Reveal cell" },
      { keys: ["Right Click"], description: "Flag cell" },
    ],
  },
];

export function KeyboardShortcuts() {
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      // Don't trigger in input fields
      if (
        e.target instanceof HTMLInputElement ||
        e.target instanceof HTMLTextAreaElement
      )
        return;

      if (e.key === "?" && !e.ctrlKey && !e.metaKey) {
        e.preventDefault();
        setOpen((prev) => !prev);
      }
      if (e.key === "Escape" && open) {
        setOpen(false);
      }
    };

    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [open]);

  return (
    <>
      {/* Floating help button */}
      <button
        onClick={() => setOpen(true)}
        className="fixed bottom-4 right-4 z-40 w-10 h-10 rounded-full bg-[var(--color-surface)] border border-[var(--color-border)] shadow-lg flex items-center justify-center text-lg hover:scale-110 transition-transform"
        aria-label="Keyboard shortcuts"
        title="Keyboard shortcuts (?)"
      >
        ⌨️
      </button>

      <Modal open={open} onClose={() => setOpen(false)} title="⌨️ Keyboard Shortcuts">
        <div className="space-y-5 max-h-[60vh] overflow-y-auto">
          {SHORTCUTS.map((group) => (
            <div key={group.title}>
              <h3 className="text-xs font-bold uppercase tracking-wider text-[var(--color-text-muted)] mb-2">
                {group.title}
              </h3>
              <div className="space-y-1.5">
                {group.shortcuts.map((s, i) => (
                  <div
                    key={i}
                    className="flex items-center justify-between py-1.5"
                  >
                    <span className="text-sm text-[var(--color-text-secondary)]">
                      {s.description}
                    </span>
                    <div className="flex gap-1">
                      {s.keys.map((key) => (
                        <kbd
                          key={key}
                          className="px-2 py-0.5 text-xs font-mono font-medium bg-[var(--color-surface-hover)] border border-[var(--color-border)] rounded-md text-[var(--color-text)]"
                        >
                          {key}
                        </kbd>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
        <p className="mt-4 text-xs text-center text-[var(--color-text-muted)]">
          Press <kbd className="px-1.5 py-0.5 font-mono text-xs bg-[var(--color-surface-hover)] border border-[var(--color-border)] rounded">?</kbd> to toggle this panel
        </p>
      </Modal>
    </>
  );
}
