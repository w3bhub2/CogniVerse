"use client";

import { useEffect, useRef, useCallback } from "react";
import { eventBus, Events } from "@/engine";

/**
 * GameVisibilityHandler — Handles:
 * 1. Auto-save on tab close / visibility change
 * 2. Game pause when tab becomes hidden
 * 3. Game resume when tab becomes visible
 *
 * This is critical for mobile users who switch apps frequently.
 */
export function GameVisibilityHandler() {
  const saveStateRef = useRef<(() => void) | null>(null);
  const isPausedByVisibility = useRef(false);

  // Allow games to register their save callback
  const registerSaveCallback = useCallback((callback: () => void) => {
    saveStateRef.current = callback;
  }, []);

  useEffect(() => {
    // Before unload — save immediately
    const handleBeforeUnload = () => {
      if (saveStateRef.current) {
        saveStateRef.current();
      }
      // Also emit save event
      eventBus.emit(Events.SAVE_REQUEST, {});
    };

    // Visibility change — pause/resume game
    const handleVisibilityChange = () => {
      if (document.hidden) {
        // Tab hidden — save and pause
        if (saveStateRef.current) {
          saveStateRef.current();
        }
        eventBus.emit(Events.GAME_PAUSE, { reason: "visibility" });
        isPausedByVisibility.current = true;
      } else {
        // Tab visible — resume if we auto-paused
        if (isPausedByVisibility.current) {
          eventBus.emit(Events.GAME_RESUME, { reason: "visibility" });
          isPausedByVisibility.current = false;
        }
      }
    };

    // Page hide (mobile browsers)
    const handlePageHide = () => {
      if (saveStateRef.current) {
        saveStateRef.current();
      }
    };

    window.addEventListener("beforeunload", handleBeforeUnload);
    document.addEventListener("visibilitychange", handleVisibilityChange);
    window.addEventListener("pagehide", handlePageHide);

    return () => {
      window.removeEventListener("beforeunload", handleBeforeUnload);
      document.removeEventListener("visibilitychange", handleVisibilityChange);
      window.removeEventListener("pagehide", handlePageHide);
    };
  }, []);

  // Register for save events from the engine
  useEffect(() => {
    const unsub = eventBus.on(Events.SAVE_REQUEST, () => {
      if (saveStateRef.current) {
        saveStateRef.current();
      }
    });
    return unsub;
  }, []);

  // Expose registration via event bus
  useEffect(() => {
    const unsub = eventBus.on(
      "game:register-save" as string,
      (payload) => {
        const { callback } = payload as { callback: () => void };
        registerSaveCallback(callback);
      }
    );
    return unsub;
  }, [registerSaveCallback]);

  // This component renders nothing — it's a headless handler
  return null;
}

/**
 * Hook version for game renderers to register their save callback.
 */
export function useGameSaveRegistration(saveCallback: () => void) {
  useEffect(() => {
    // Register save callback on mount
    eventBus.emit("game:register-save" as string, {
      callback: saveCallback,
    });
  }, [saveCallback]);
}
