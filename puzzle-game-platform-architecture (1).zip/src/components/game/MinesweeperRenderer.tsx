"use client";

import { useState, useEffect, useCallback, useRef } from "react";
import {
  MinesweeperGame,
  type MinesweeperCell,
  type MinesweeperDifficulty,
} from "@/games/minesweeper";
import { EventSystem } from "@/engine";
import { Button, Timer, GameOverOverlay } from "@/components/ui";

interface Props {
  onSave?: (state: Record<string, unknown>) => void;
  savedState?: Record<string, unknown> | null;
}

export function MinesweeperRenderer({ onSave, savedState }: Props) {
  const eventsRef = useRef(new EventSystem());
  const gameRef = useRef(new MinesweeperGame());
  const [board, setBoard] = useState<MinesweeperCell[][]>([]);
  const [score, setScore] = useState(0);
  const [gameOver, setGameOver] = useState(false);
  const [won, setWon] = useState(false);
  const [timer, setTimer] = useState(0);
  const [flagsPlaced, setFlagsPlaced] = useState(0);
  const [totalMines, setTotalMines] = useState(10);
  const [difficulty, setDifficulty] =
    useState<MinesweeperDifficulty>("easy");
  const [rows, setRows] = useState(9);
  const [cols, setCols] = useState(9);
  const [longPressTimer, setLongPressTimer] = useState<ReturnType<typeof setTimeout> | null>(null);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const syncState = useCallback(() => {
    const g = gameRef.current;
    const saved = g.save() as { board: MinesweeperCell[][] };
    setBoard(saved.board);
    setScore(g.getScore());
    setGameOver(g.isGameOver());
    setWon(g.isWon());
    setFlagsPlaced(g.getFlagsPlaced());
    setTotalMines(g.getTotalMines());
    setRows(g.getRows());
    setCols(g.getCols());
  }, []);

  useEffect(() => {
    const game = gameRef.current;
    game.init(eventsRef.current);

    if (savedState) {
      game.load(savedState);
    } else {
      game.start();
    }

    syncState();

    timerRef.current = setInterval(() => {
      // Drive the game clock here since this renderer owns its loop;
      // update() is a no-op once the game is over.
      game.update(500);
      setTimer(game.getTimer());
    }, 500);

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [savedState, syncState]);

  const handleCellClick = useCallback(
    (row: number, col: number) => {
      gameRef.current.reveal(row, col);
      syncState();
      onSave?.(gameRef.current.save() as Record<string, unknown>);
    },
    [syncState, onSave]
  );

  const handleCellRightClick = useCallback(
    (e: React.MouseEvent, row: number, col: number) => {
      e.preventDefault();
      gameRef.current.toggleFlag(row, col);
      syncState();
    },
    [syncState]
  );

  const handleTouchStart = useCallback(
    (row: number, col: number) => {
      const timer = setTimeout(() => {
        gameRef.current.toggleFlag(row, col);
        syncState();
      }, 500);
      setLongPressTimer(timer);
    },
    [syncState]
  );

  const handleTouchEnd = useCallback(
    (row: number, col: number) => {
      if (longPressTimer) {
        clearTimeout(longPressTimer);
        setLongPressTimer(null);
        return;
      }
      gameRef.current.reveal(row, col);
      syncState();
      onSave?.(gameRef.current.save() as Record<string, unknown>);
    },
    [longPressTimer, syncState, onSave]
  );

  const handleRestart = useCallback(() => {
    gameRef.current.setDifficulty(difficulty);
    setSelectedCell(null);
    syncState();
  }, [difficulty, syncState]);

  const [selectedCell, setSelectedCell] = useState<[number, number] | null>(null);

  const getCellContent = (cell: MinesweeperCell) => {
    if (cell.isFlagged && !cell.isRevealed) return "🚩";
    if (!cell.isRevealed) return "";
    if (cell.isMine) return "💣";
    if (cell.adjacentMines === 0) return "";

    const colors = [
      "",
      "text-blue-600 dark:text-blue-400",
      "text-green-600 dark:text-green-400",
      "text-red-600 dark:text-red-400",
      "text-purple-600 dark:text-purple-400",
      "text-yellow-600 dark:text-yellow-400",
      "text-teal-600 dark:text-teal-400",
      "text-slate-600 dark:text-slate-400",
      "text-pink-600 dark:text-pink-400",
    ];

    return (
      <span className={`font-bold ${colors[cell.adjacentMines]}`}>
        {cell.adjacentMines}
      </span>
    );
  };

  const getCellClasses = (cell: MinesweeperCell) => {
    let classes =
      "flex items-center justify-center text-xs sm:text-sm font-bold rounded-sm transition-colors cursor-pointer aspect-square ";

    if (cell.isRevealed) {
      if (cell.isMine) {
        classes += "bg-red-400 dark:bg-red-600 ";
      } else {
        classes += "bg-slate-200 dark:bg-slate-600 ";
      }
    } else {
      classes +=
        "bg-slate-300 dark:bg-slate-500 hover:bg-slate-200 dark:hover:bg-slate-400 ";
    }

    return classes;
  };

  return (
    <div className="flex flex-col items-center gap-4 w-full mx-auto select-none">
      {/* Header */}
      <div className="w-full flex items-center justify-between max-w-lg">
        <div className="flex items-center gap-4">
          <div className="text-center">
            <p className="text-xs uppercase tracking-wider text-slate-500">
              Mines
            </p>
            <p className="text-xl font-bold text-red-500">
              {totalMines - flagsPlaced}
            </p>
          </div>
          <Timer elapsed={timer} />
          <div className="text-center">
            <p className="text-xs uppercase tracking-wider text-slate-500">
              Flags
            </p>
            <p className="text-xl font-bold text-slate-700 dark:text-slate-300">
              {flagsPlaced}
            </p>
          </div>
        </div>
        <Button variant="secondary" size="sm" onClick={handleRestart}>
          New Game
        </Button>
      </div>

      {/* Difficulty */}
      <div className="flex gap-2">
        {(["easy", "medium", "hard"] as MinesweeperDifficulty[]).map((d) => (
          <Button
            key={d}
            variant={d === difficulty ? "primary" : "ghost"}
            size="sm"
            onClick={() => {
              setDifficulty(d);
              gameRef.current.setDifficulty(d);
              syncState();
            }}
          >
            {d.charAt(0).toUpperCase() + d.slice(1)}
          </Button>
        ))}
      </div>

      {/* Board */}
      <div className="relative w-full overflow-x-auto">
        <div
          className="grid gap-[1px] bg-slate-400 dark:bg-slate-600 rounded-xl p-[2px] mx-auto"
          style={{
            gridTemplateColumns: `repeat(${cols}, minmax(0, 1fr))`,
            maxWidth: `${cols * 36 + 8}px`,
          }}
        >
          {board.map((row, r) =>
            row.map((cell, c) => (
              <div
                key={`${r}-${c}`}
                className={getCellClasses(cell)}
                onClick={() => handleCellClick(r, c)}
                onContextMenu={(e) => handleCellRightClick(e, r, c)}
                onTouchStart={() => handleTouchStart(r, c)}
                onTouchEnd={() => handleTouchEnd(r, c)}
              >
                {getCellContent(cell)}
              </div>
            ))
          )}
        </div>

        <GameOverOverlay
          visible={gameOver || won}
          won={won}
          score={score}
          onRestart={handleRestart}
          onHome={() => {}}
        />
      </div>

      <p className="text-xs text-slate-400 dark:text-slate-500 text-center">
        Click to reveal. Right-click or long-press to flag.
      </p>
    </div>
  );
}
