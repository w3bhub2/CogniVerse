"use client";

import { useState, useEffect, useCallback, useRef } from "react";
import { SudokuGame, type SudokuCell, type Difficulty } from "@/games/sudoku";
import { Engine, type EngineSnapshot } from "@/engine";
import { Button, GameOverOverlay } from "@/components/ui";

interface Props {
  onSave?: (state: Record<string, unknown>) => void;
  savedState?: Record<string, unknown> | null;
}

export function SudokuRenderer({ onSave, savedState }: Props) {
  const engineRef = useRef<Engine | null>(null);
  const gameRef = useRef<SudokuGame | null>(null);
  const [snap, setSnap] = useState<EngineSnapshot | null>(null);
  const [board, setBoard] = useState<SudokuCell[][]>([]);
  const [timer, setTimer] = useState(0);
  const [mistakes, setMistakes] = useState(0);
  const [hintsUsed, setHintsUsed] = useState(0);
  const [selectedCell, setSelectedCell] = useState<[number, number] | null>(null);
  const [pencilMode, setPencilMode] = useState(false);
  const [difficulty, setDifficulty] = useState<Difficulty>("medium");

  const refresh = useCallback(() => {
    const g = gameRef.current;
    if (!g) return;
    const saved = g.save() as { board: SudokuCell[][] };
    setBoard(saved.board);
    setTimer(g.getTimer());
    setMistakes(g.getMistakes());
    setHintsUsed(g.getHintsUsed());
  }, []);

  useEffect(() => {
    const engine = new Engine();
    const game = new SudokuGame();
    engineRef.current = engine;
    gameRef.current = game;

    const unsub = engine.subscribe((s) => {
      setSnap(s);
      refresh();
      if (s.state === "ended") {
        const state = engine.saveGame();
        if (state) onSave?.(state as Record<string, unknown>);
      }
    });

    (async () => {
      await engine.loadGame(game);
      if (savedState) game.load(savedState);
      else game.start();
      engine.startGame(); // tickBased → Engine drives the timer now
    })();

    return () => {
      unsub();
      void engine.destroyGame();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const persist = useCallback(() => {
    const state = engineRef.current?.saveGame();
    if (state) onSave?.(state as Record<string, unknown>);
  }, [onSave]);

  const handleNumberInput = useCallback(
    (num: number) => {
      if (!selectedCell) return;
      const [row, col] = selectedCell;
      const g = gameRef.current;
      if (!g) return;
      if (pencilMode) {
        g.toggleCandidate(row, col, num);
      } else {
        engineRef.current?.dispatch({ type: "place", row, col, value: num });
      }
      refresh();
      persist();
    },
    [selectedCell, pencilMode, refresh, persist]
  );

  const handleErase = useCallback(() => {
    if (!selectedCell) return;
    engineRef.current?.dispatch({
      type: "erase",
      row: selectedCell[0],
      col: selectedCell[1],
    });
    refresh();
    persist();
  }, [selectedCell, refresh, persist]);

  const handleHint = useCallback(() => {
    engineRef.current?.hint();
    refresh();
    persist();
  }, [refresh, persist]);

  const handleRestart = useCallback(
    (diff?: Difficulty) => {
      const g = gameRef.current;
      const engine = engineRef.current;
      if (!g || !engine) return;
      g.setDifficulty(diff ?? difficulty);
      setSelectedCell(null);
      engine.startGame();
      refresh();
    },
    [difficulty, refresh]
  );

  // Keyboard
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      const num = parseInt(e.key);
      if (num >= 1 && num <= 9 && selectedCell) {
        handleNumberInput(num);
        return;
      }
      if (e.key === "Backspace" || e.key === "Delete") handleErase();
      if (e.key === "p") setPencilMode((p) => !p);
      if (selectedCell && e.key.startsWith("Arrow")) {
        e.preventDefault();
        const [r, c] = selectedCell;
        const nr =
          e.key === "ArrowUp" ? Math.max(0, r - 1) : e.key === "ArrowDown" ? Math.min(8, r + 1) : r;
        const nc =
          e.key === "ArrowLeft" ? Math.max(0, c - 1) : e.key === "ArrowRight" ? Math.min(8, c + 1) : c;
        setSelectedCell([nr, nc]);
      }
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [selectedCell, handleNumberInput, handleErase]);

  // Digit inventory — how many of each digit remain to place
  const remaining = (num: number): number => {
    let placed = 0;
    for (const row of board) for (const cell of row) if (cell.value === num) placed++;
    return 9 - placed;
  };

  const formatTime = (ms: number) => {
    const s = Math.floor(ms / 1000);
    return `${String(Math.floor(s / 60)).padStart(2, "0")}:${String(s % 60).padStart(2, "0")}`;
  };

  const getCellClasses = (cell: SudokuCell, row: number, col: number) => {
    const isSelected = selectedCell?.[0] === row && selectedCell?.[1] === col;
    const selVal = selectedCell ? board[selectedCell[0]][selectedCell[1]]?.value : 0;
    const isSameValue = selVal !== 0 && cell.value === selVal;
    const isSameRow = selectedCell?.[0] === row;
    const isSameCol = selectedCell?.[1] === col;
    const isSameBox =
      selectedCell &&
      Math.floor(selectedCell[0] / 3) === Math.floor(row / 3) &&
      Math.floor(selectedCell[1] / 3) === Math.floor(col / 3);
    const isPeer = !isSelected && (isSameRow || isSameCol || isSameBox);

    let cls =
      "w-full aspect-square flex items-center justify-center text-sm sm:text-lg font-medium rounded-md transition-colors cursor-pointer ";

    if (cell.given) cls += "text-slate-900 dark:text-white font-bold ";
    else if (cell.value !== 0) cls += "text-indigo-600 dark:text-indigo-400 ";

    if (cell.error) cls += "bg-red-100 dark:bg-red-900/40 text-red-600 dark:text-red-400 ";
    else if (isSelected) cls += "bg-indigo-200 dark:bg-indigo-700/60 ";
    else if (isSameValue && cell.value !== 0) cls += "bg-indigo-100 dark:bg-indigo-800/40 ";
    else if (isPeer) cls += "bg-indigo-50 dark:bg-indigo-900/20 ";
    else cls += "hover:bg-slate-100 dark:hover:bg-slate-600 ";

    if (col % 3 === 0) cls += "border-l-2 border-l-slate-400 dark:border-l-slate-500 ";
    if (row % 3 === 0) cls += "border-t-2 border-t-slate-400 dark:border-t-slate-500 ";
    return cls;
  };

  return (
    <div className="flex flex-col items-center gap-4 w-full max-w-lg mx-auto select-none">
      <div className="w-full flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className="text-center">
            <p className="text-xs uppercase tracking-wider text-slate-500">Score</p>
            <p className="text-xl font-bold text-slate-900 dark:text-white">{snap?.score ?? 0}</p>
          </div>
          <div className="text-center">
            <p className="text-xs uppercase tracking-wider text-slate-500">Time</p>
            <p className="text-xl font-bold text-slate-900 dark:text-white tabular-nums">
              {formatTime(timer)}
            </p>
          </div>
          <div className="text-center">
            <p className="text-xs uppercase tracking-wider text-slate-500">Mistakes</p>
            <p className="text-xl font-bold text-red-500">{mistakes}/3</p>
          </div>
        </div>
      </div>

      <div className="flex gap-2 flex-wrap justify-center">
        {(["easy", "medium", "hard", "expert"] as Difficulty[]).map((d) => (
          <Button
            key={d}
            variant={d === difficulty ? "primary" : "ghost"}
            size="sm"
            onClick={() => {
              setDifficulty(d);
              handleRestart(d);
            }}
          >
            {d.charAt(0).toUpperCase() + d.slice(1)}
          </Button>
        ))}
      </div>

      <div className="relative w-full">
        <div className="grid grid-cols-9 gap-[1px] bg-slate-300 dark:bg-slate-600 rounded-xl p-[2px]">
          {board.map((row, r) =>
            row.map((cell, c) => (
              <div
                key={`${r}-${c}`}
                className={getCellClasses(cell, r, c)}
                onClick={() => setSelectedCell([r, c])}
              >
                {cell.value !== 0 ? (
                  cell.value
                ) : cell.candidates.size > 0 ? (
                  <div className="grid grid-cols-3 gap-0 w-full h-full text-[8px] sm:text-[10px] text-slate-400">
                    {[1, 2, 3, 4, 5, 6, 7, 8, 9].map((n) => (
                      <span key={n} className="flex items-center justify-center">
                        {cell.candidates.has(n) ? n : ""}
                      </span>
                    ))}
                  </div>
                ) : null}
              </div>
            ))
          )}
        </div>

        <GameOverOverlay
          visible={(snap?.gameOver === true || snap?.won === true) && !!snap}
          won={snap?.won === true}
          score={snap?.score ?? 0}
          onRestart={() => handleRestart()}
          onHome={() => {}}
        />
      </div>

      {/* T9 numpad with digit inventory */}
      <div className="w-full max-w-xs">
        <div className="grid grid-cols-3 gap-2">
          {[1, 2, 3, 4, 5, 6, 7, 8, 9].map((num) => {
            const left = remaining(num);
            return (
              <button
                key={num}
                onClick={() => handleNumberInput(num)}
                disabled={left <= 0}
                className={`relative h-14 rounded-xl font-bold text-xl transition-all
                  ${
                    left <= 0
                      ? "bg-slate-100 dark:bg-slate-800 text-slate-300 dark:text-slate-600"
                      : "bg-[var(--color-surface)] border border-[var(--color-border)] text-[var(--color-text)] hover:bg-[var(--color-surface-hover)] active:scale-95"
                  }`}
                aria-label={`Place ${num}, ${left} remaining`}
              >
                {num}
                <span className="absolute bottom-1 right-2 text-[10px] font-medium text-[var(--color-text-muted)]">
                  {left}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      <div className="flex justify-center gap-2 flex-wrap">
        <Button
          variant={pencilMode ? "primary" : "ghost"}
          size="sm"
          onClick={() => setPencilMode(!pencilMode)}
        >
          ✏️ Notes
        </Button>
        <Button variant="ghost" size="sm" onClick={handleErase}>
          🧹 Erase
        </Button>
        <Button variant="ghost" size="sm" onClick={handleHint} disabled={hintsUsed >= 3}>
          💡 Hint ({3 - hintsUsed})
        </Button>
        <Button variant="secondary" size="sm" onClick={() => handleRestart()}>
          🔄 New
        </Button>
      </div>
    </div>
  );
}
