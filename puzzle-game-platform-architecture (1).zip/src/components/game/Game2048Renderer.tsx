"use client";

import { useState, useEffect, useCallback, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Game2048, type Tile2048 } from "@/games/game2048";
import { Engine, type EngineSnapshot } from "@/engine";
import { Button, ScoreDisplay, GameOverOverlay } from "@/components/ui";

function getTileColor(value: number): string {
  const colors: Record<number, string> = {
    2: "bg-slate-200 dark:bg-slate-600 text-slate-800 dark:text-slate-200",
    4: "bg-amber-100 text-amber-800",
    8: "bg-orange-200 text-orange-800",
    16: "bg-orange-300 text-white",
    32: "bg-orange-400 text-white",
    64: "bg-orange-500 text-white",
    128: "bg-yellow-400 text-white",
    256: "bg-yellow-500 text-white",
    512: "bg-yellow-600 text-white",
    1024: "bg-red-400 text-white",
    2048: "bg-red-500 text-white",
  };
  return colors[value] ?? "bg-purple-600 text-white";
}

function getFontSize(value: number): string {
  if (value >= 1000) return "text-base sm:text-lg";
  if (value >= 100) return "text-lg sm:text-xl";
  return "text-xl sm:text-2xl";
}

interface Props {
  onSave?: (state: Record<string, unknown>) => void;
  onScoreChange?: (score: number) => void;
  savedState?: Record<string, unknown> | null;
}

export function Game2048Renderer({ onSave, onScoreChange, savedState }: Props) {
  const engineRef = useRef<Engine | null>(null);
  const gameRef = useRef<Game2048 | null>(null);
  const [snap, setSnap] = useState<EngineSnapshot | null>(null);
  const [tiles, setTiles] = useState<Tile2048[]>([]);
  const [bestScore, setBestScore] = useState(0);
  const touchStartRef = useRef<{ x: number; y: number } | null>(null);

  const refresh = useCallback(() => {
    if (gameRef.current) {
      setTiles(gameRef.current.getTiles().map((t) => ({ ...t })));
      onScoreChange?.(gameRef.current.getScore());
      if (gameRef.current.getScore() > bestScore) {
        setBestScore(gameRef.current.getScore());
      }
    }
  }, [onScoreChange, bestScore]);

  // One-time engine + game bootstrap
  useEffect(() => {
    const engine = new Engine();
    const game = new Game2048();
    engineRef.current = engine;
    gameRef.current = game;

    const unsub = engine.subscribe((s) => {
      setSnap(s);
      refresh();
      if (s.state === "ended" || s.state === "paused") {
        const state = engine.saveGame();
        if (state) onSave?.(state as Record<string, unknown>);
      }
    });

    (async () => {
      await engine.loadGame(game);
      if (savedState) {
        game.load(savedState);
      } else {
        game.start();
      }
      engine.startGame();
    })();

    try {
      const raw = localStorage.getItem("game2048_best");
      setBestScore(raw ? parseInt(raw, 10) || 0 : 0);
    } catch { /* ignore */ }

    return () => {
      unsub();
      void engine.destroyGame();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleMove = useCallback(
    (direction: "up" | "down" | "left" | "right") => {
      const engine = engineRef.current;
      if (!engine) return;
      engine.dispatch({ type: "move", direction });
      const state = engine.saveGame();
      if (state) onSave?.(state as Record<string, unknown>);
    },
    [onSave]
  );

  // Keyboard
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      const keyMap: Record<string, "up" | "down" | "left" | "right"> = {
        ArrowUp: "up", ArrowDown: "down", ArrowLeft: "left", ArrowRight: "right",
        w: "up", s: "down", a: "left", d: "right",
      };
      const dir = keyMap[e.key];
      if (dir) { e.preventDefault(); handleMove(dir); }
      if (e.key === "z" && (e.ctrlKey || e.metaKey)) {
        e.preventDefault();
        if (e.shiftKey) engineRef.current?.redo();
        else engineRef.current?.undo();
      }
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [handleMove]);

  const handleTouchStart = useCallback((e: React.TouchEvent) => {
    const t = e.touches[0];
    touchStartRef.current = { x: t.clientX, y: t.clientY };
  }, []);

  const handleTouchEnd = useCallback(
    (e: React.TouchEvent) => {
      if (!touchStartRef.current) return;
      const t = e.changedTouches[0];
      const dx = t.clientX - touchStartRef.current.x;
      const dy = t.clientY - touchStartRef.current.y;
      if (Math.max(Math.abs(dx), Math.abs(dy)) < 30) return;
      if (Math.abs(dx) > Math.abs(dy)) handleMove(dx > 0 ? "right" : "left");
      else handleMove(dy > 0 ? "down" : "up");
      touchStartRef.current = null;
    },
    [handleMove]
  );

  const handleRestart = useCallback(() => {
    const engine = engineRef.current;
    const game = gameRef.current;
    if (!engine || !game) return;
    game.start();
    engine.startGame();
  }, []);

  const score = snap?.score ?? 0;
  const gameOver = snap?.gameOver === true && snap?.won !== true;
  const won = snap?.won === true;

  return (
    <div className="flex flex-col items-center gap-4 w-full max-w-md mx-auto select-none">
      <div className="w-full flex items-center justify-between">
        <ScoreDisplay score={score} best={bestScore} />
        <div className="flex gap-2">
          <Button
            variant="ghost" size="sm"
            onClick={() => engineRef.current?.undo()}
            disabled={!snap?.canUndo}
          >↩</Button>
          <Button
            variant="ghost" size="sm"
            onClick={() => engineRef.current?.redo()}
            disabled={!snap?.canRedo}
          >↪</Button>
          <Button variant="secondary" size="sm" onClick={handleRestart}>
            New Game
          </Button>
        </div>
      </div>

      <div
        className="relative w-full aspect-square bg-slate-300 dark:bg-slate-600 rounded-2xl p-1.5"
        onTouchStart={handleTouchStart}
        onTouchEnd={handleTouchEnd}
      >
        {/* Static background cells */}
        <div className="grid grid-cols-4 gap-1.5 w-full h-full">
          {Array.from({ length: 16 }).map((_, i) => (
            <div key={i} className="rounded-xl bg-slate-200/60 dark:bg-slate-700/60" />
          ))}
        </div>

        {/* Animated tiles */}
        <div className="absolute inset-1.5">
          <AnimatePresence>
            {tiles.map((tile) => (
              <motion.div
                key={tile.id}
                className="absolute p-[3px]"
                style={{ width: "25%", height: "25%" }}
                initial={{
                  top: `${tile.row * 25}%`,
                  left: `${tile.col * 25}%`,
                  scale: tile.isNew || tile.isMerged ? 0 : 1,
                }}
                animate={{
                  top: `${tile.row * 25}%`,
                  left: `${tile.col * 25}%`,
                  scale: 1,
                }}
                exit={{ scale: 0, opacity: 0 }}
                transition={{ type: "spring", stiffness: 500, damping: 38 }}
              >
                <div
                  className={`w-full h-full flex items-center justify-center rounded-xl font-bold ${getTileColor(
                    tile.value
                  )} ${getFontSize(tile.value)}`}
                >
                  {tile.value}
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>

        <GameOverOverlay
          visible={gameOver || won}
          won={won}
          score={score}
          onRestart={handleRestart}
          onHome={() => {}}
        />
      </div>

      <p className="text-xs text-slate-400 dark:text-slate-500 text-center">
        Swipe or use arrow keys / WASD to play
      </p>
    </div>
  );
}
