export { Game2048Renderer } from "./Game2048Renderer";
export { SudokuRenderer } from "./SudokuRenderer";
export { MinesweeperRenderer } from "./MinesweeperRenderer";
