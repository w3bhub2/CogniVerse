"use client";

import { type ReactNode, useEffect } from "react";
import { ToastProvider } from "./ToastProvider";
import { AchievementToast } from "./AchievementToast";
import { KeyboardShortcuts } from "./KeyboardShortcuts";
import { GameVisibilityHandler } from "./GameVisibilityHandler";
import { themeEngine } from "@/platform/services/ThemeEngine";
import { audioService } from "@/platform/services/AudioService";
// Retention spine — instantiating registers their game:end listeners.
import "@/platform/services/StreakService";
import "@/platform/services/ProgressionService";

/**
 * ClientProviders — Initializes all client-side services and providers.
 * This is the single entry point for all client-side behavior.
 */
export function ClientProviders({ children }: { children: ReactNode }) {
  useEffect(() => {
    // Initialize theme engine
    themeEngine.apply(themeEngine.getCurrent().id);

    // Initialize audio on first user interaction (required by browsers)
    const initAudio = () => {
      audioService.init();
      document.removeEventListener("click", initAudio);
      document.removeEventListener("touchstart", initAudio);
    };
    document.addEventListener("click", initAudio);
    document.addEventListener("touchstart", initAudio);

    // Register service worker for PWA
    if ("serviceWorker" in navigator) {
      navigator.serviceWorker.register("/sw.js").catch(() => {
        // Service worker registration failed — non-critical
      });
    }

    return () => {
      document.removeEventListener("click", initAudio);
      document.removeEventListener("touchstart", initAudio);
    };
  }, []);

  return (
    <>
      {children}
      <ToastProvider />
      <AchievementToast />
      <KeyboardShortcuts />
      <GameVisibilityHandler />
    </>
  );
}
