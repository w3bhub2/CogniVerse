/**
 * HapticsService — Vibration patterns for game feedback.
 *
 * Uses Capacitor Haptics on native, navigator.vibrate on web.
 * Patterns follow Material Design haptic guidelines.
 *
 * Responsibilities:
 *   - Provide consistent haptic feedback across platforms
 *   - Respect user's haptics preference setting
 *   - Map game events to appropriate vibration patterns
 *
 * Future Extension Points:
 *   - Custom pattern editor
 *   - Intensity levels
 *   - Per-game haptic profiles
 */

export type HapticPattern =
  | "tap"
  | "success"
  | "failure"
  | "merge"
  | "reveal"
  | "flag"
  | "undo"
  | "achievement"
  | "game_over"
  | "game_win";

interface VibrationPattern {
  /** Vibration durations in ms [vibrate, pause, vibrate, ...] */
  pattern: number[];
  /** Haptic intensity hint (0-1) */
  intensity: number;
}

const PATTERNS: Record<HapticPattern, VibrationPattern> = {
  tap: { pattern: [10], intensity: 0.3 },
  success: { pattern: [30, 50, 60], intensity: 0.7 },
  failure: { pattern: [50, 30, 50, 30, 50], intensity: 0.8 },
  merge: { pattern: [15, 20, 25], intensity: 0.5 },
  reveal: { pattern: [8], intensity: 0.2 },
  flag: { pattern: [20, 30, 10], intensity: 0.4 },
  undo: { pattern: [10, 20, 10], intensity: 0.3 },
  achievement: { pattern: [20, 40, 30, 40, 50], intensity: 0.9 },
  game_over: { pattern: [40, 30, 40, 30, 40, 30, 60], intensity: 0.8 },
  game_win: { pattern: [20, 30, 20, 30, 20, 30, 40, 50, 60], intensity: 1.0 },
};

class HapticsService {
  private enabled = true;
  private capacitorHaptics: unknown = null;

  constructor() {
    this.loadPreference();
    this.detectCapacitor();
  }

  /**
   * Trigger a haptic pattern.
   */
  trigger(pattern: HapticPattern): void {
    if (!this.enabled) return;

    const { pattern: durations } = PATTERNS[pattern];

    // Try Capacitor Haptics first (native)
    if (this.capacitorHaptics) {
      this.triggerCapacitor(pattern);
      return;
    }

    // Fallback to Web Vibration API
    if (typeof navigator !== "undefined" && navigator.vibrate) {
      navigator.vibrate(durations);
    }
  }

  /**
   * Enable/disable haptics.
   */
  setEnabled(enabled: boolean): void {
    this.enabled = enabled;
    this.savePreference();
  }

  isEnabled(): boolean {
    return this.enabled;
  }

  /**
   * Check if vibration is supported on this device.
   */
  isSupported(): boolean {
    if (this.capacitorHaptics) return true;
    return typeof navigator !== "undefined" && "vibrate" in navigator;
  }

  /* ─── Private ─── */

  private async triggerCapacitor(pattern: HapticPattern): Promise<void> {
    try {
      const haptics = this.capacitorHaptics as {
        vibrate?: (options: { duration: number }) => Promise<void>;
        impact?: (options: { style: string }) => Promise<void>;
      };

      // Use impact for simple patterns, vibrate for complex
      if (pattern === "tap" || pattern === "reveal") {
        await haptics.impact?.({ style: "LIGHT" });
      } else if (pattern === "success" || pattern === "merge") {
        await haptics.impact?.({ style: "MEDIUM" });
      } else if (pattern === "achievement" || pattern === "game_win") {
        await haptics.impact?.({ style: "HEAVY" });
      } else {
        // Use vibrate for custom patterns
        const { pattern: durations } = PATTERNS[pattern];
        await haptics.vibrate?.({ duration: durations[0] ?? 20 });
      }
    } catch {
      // Capacitor haptics not available
    }
  }

  private detectCapacitor(): void {
    try {
      // Dynamic import for Capacitor (only available in native context)
      if (typeof window !== "undefined" && "Capacitor" in window) {
        import("@capacitor/haptics").then((mod) => {
          this.capacitorHaptics = mod.Haptics;
        }).catch(() => {
          // Not in Capacitor context
        });
      }
    } catch {
      // Not available
    }
  }

  private loadPreference(): void {
    try {
      const raw = localStorage.getItem("puzzle_platform_haptics");
      if (raw !== null) {
        this.enabled = raw === "true";
      }
    } catch {
      // Ignore
    }
  }

  private savePreference(): void {
    try {
      localStorage.setItem("puzzle_platform_haptics", String(this.enabled));
    } catch {
      // Ignore
    }
  }
}

export const hapticsService = new HapticsService();
