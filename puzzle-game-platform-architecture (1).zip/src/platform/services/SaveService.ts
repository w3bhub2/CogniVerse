/**
 * SaveService — Manages game save/load through the API and local storage.
 *
 * Responsibilities:
 *   - Save game state to server (PostgreSQL) via API
 *   - Load game state from server
 *   - LocalStorage fallback for offline play
 *   - Auto-save on game pause/end
 *   - Save slot management
 *
 * Flow:
 *   1. Game requests save via event bus
 *   2. SaveService serializes state
 *   3. SaveService POSTs to /api/saves
 *   4. SaveService stores in localStorage as backup
 *   5. On load, prefers server state, falls back to local
 *
 * Future Extension Points:
 *   - Cloud sync (Google Play Games)
 *   - Save versioning / migration
 *   - Save conflict resolution
 */

import { eventBus, Events } from "@/engine";

export interface SaveData {
  gameId: string;
  state: Record<string, unknown>;
  score: number;
  moves: number;
  timeElapsed: number;
  timestamp: number;
  version: string;
}

export interface SaveSlot {
  id: number;
  data: SaveData;
  label: string;
}

const STORAGE_PREFIX = "puzzle_platform_save_";

export class SaveService {
  private gameId: string;

  constructor(gameId: string) {
    this.gameId = gameId;
    this.setupListeners();
  }

  /* ─── Public API ─── */

  /**
   * Save game state to server and local storage.
   */
  async save(state: Record<string, unknown>, meta?: {
    score?: number;
    moves?: number;
    timeElapsed?: number;
  }): Promise<boolean> {
    const saveData: SaveData = {
      gameId: this.gameId,
      state,
      score: meta?.score ?? 0,
      moves: meta?.moves ?? 0,
      timeElapsed: meta?.timeElapsed ?? 0,
      timestamp: Date.now(),
      version: "1.0.0",
    };

    try {
      // Save to server
      const response = await fetch("/api/saves", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(saveData),
      });

      if (response.ok) {
        eventBus.emit(Events.SAVE_COMPLETE, { gameId: this.gameId });
      }
    } catch {
      // Server save failed, continue with local
    }

    // Always save locally as backup
    this.saveLocal(saveData);

    return true;
  }

  /**
   * Load the latest save from server, falling back to local.
   */
  async load(): Promise<SaveData | null> {
    try {
      const response = await fetch(
        `/api/saves?gameId=${encodeURIComponent(this.gameId)}`
      );
      if (response.ok) {
        const data = await response.json();
        if (data.save) {
          this.saveLocal(data.save); // Sync local
          return data.save;
        }
      }
    } catch {
      // Server load failed, try local
    }

    return this.loadLocal();
  }

  /**
   * Check if a save exists for this game.
   */
  hasSave(): boolean {
    return this.loadLocal() !== null;
  }

  /**
   * Delete the save for this game.
   */
  async deleteSave(): Promise<void> {
    try {
      await fetch(`/api/saves?gameId=${encodeURIComponent(this.gameId)}`, {
        method: "DELETE",
      });
    } catch {
      // Ignore server errors
    }
    localStorage.removeItem(STORAGE_PREFIX + this.gameId);
  }

  /**
   * Get save metadata without the full state (for list views).
   */
  getSavePreview(): { score: number; timestamp: number; timeElapsed: number } | null {
    const local = this.loadLocal();
    if (!local) return null;
    return {
      score: local.score,
      timestamp: local.timestamp,
      timeElapsed: local.timeElapsed,
    };
  }

  /* ─── Private ─── */

  private setupListeners(): void {
    eventBus.on<Record<string, unknown>>(Events.SAVE_REQUEST, (payload) => {
      if (payload.gameId === this.gameId) {
        this.save(payload as unknown as Record<string, unknown>);
      }
    });
  }

  private saveLocal(data: SaveData): void {
    try {
      localStorage.setItem(
        STORAGE_PREFIX + this.gameId,
        JSON.stringify(data)
      );
    } catch {
      // Storage full or unavailable
    }
  }

  private loadLocal(): SaveData | null {
    try {
      const raw = localStorage.getItem(STORAGE_PREFIX + this.gameId);
      if (!raw) return null;
      return JSON.parse(raw) as SaveData;
    } catch {
      return null;
    }
  }
}
