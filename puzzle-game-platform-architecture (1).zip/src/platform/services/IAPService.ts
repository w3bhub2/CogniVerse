/**
 * IAPService — In-App Purchase management via RevenueCat.
 *
 * RevenueCat handles:
 *   - Cross-platform purchase restoration
 *   - Receipt validation
 *   - Subscription management
 *   - Analytics on purchases
 *
 * Product tiers (defined in RevenueCat dashboard):
 *   - remove_ads_lifetime: One-time purchase, removes all ads
 *   - hint_pack_small: 10 hints
 *   - hint_pack_medium: 30 hints
 *   - hint_pack_large: 100 hints
 *
 * Future Extension Points:
 *   - Season pass
 *   - Cosmetic bundles
 *   - Subscription tiers
 *   - Regional pricing
 */

import { eventBus, Events } from "@/engine";

export type ProductId =
  | "remove_ads_lifetime"
  | "hint_pack_small"
  | "hint_pack_medium"
  | "hint_pack_large";

export interface Product {
  id: ProductId;
  title: string;
  description: string;
  price: string;
  currency: string;
}

export interface PurchaseResult {
  success: boolean;
  productId?: ProductId;
  error?: string;
}

const PRODUCTS: Record<ProductId, Omit<Product, "price" | "currency">> = {
  remove_ads_lifetime: {
    id: "remove_ads_lifetime",
    title: "Remove Ads Forever",
    description: "Enjoy all games without any advertisements",
  },
  hint_pack_small: {
    id: "hint_pack_small",
    title: "10 Hints",
    description: "Get 10 hints to use across all games",
  },
  hint_pack_medium: {
    id: "hint_pack_medium",
    title: "30 Hints",
    description: "Get 30 hints — best value!",
  },
  hint_pack_large: {
    id: "hint_pack_large",
    title: "100 Hints",
    description: "Get 100 hints — ultimate pack",
  },
};

class IAPService {
  private revenueCat: unknown = null;
  private purchasedProducts = new Set<string>();
  private initialized = false;

  constructor() {
    this.loadPurchases();
    this.detectRevenueCat();
  }

  /**
   * Initialize RevenueCat with API key.
   * Must be called once at app start.
   */
  async initialize(apiKey: string, appUserId?: string): Promise<void> {
    if (this.initialized) return;

    try {
      const rc = this.revenueCat as {
        configure?: (options: {
          apiKey: string;
          appUserID?: string;
        }) => Promise<void>;
      };
      await rc.configure?.({ apiKey, appUserID: appUserId });
      this.initialized = true;

      // Restore purchases on init
      await this.restorePurchases();
    } catch {
      console.warn("[IAPService] RevenueCat initialization failed");
    }
  }

  /**
   * Get all available products with pricing.
   */
  async getProducts(): Promise<Product[]> {
    if (!this.revenueCat) {
      // Return products without pricing (fallback)
      return Object.values(PRODUCTS).map((p) => ({
        ...p,
        price: "N/A",
        currency: "USD",
      }));
    }

    try {
      const rc = this.revenueCat as {
        getOfferings?: () => Promise<{
          current?: { availablePackages: Array<{
            identifier: string;
            product: { priceString: string; currencyCode: string; title: string; description: string };
          }> };
        }>;
      };
      const offerings = await rc.getOfferings?.();
      const packages = offerings?.current?.availablePackages ?? [];

      return packages.map((pkg) => {
        const base = PRODUCTS[pkg.identifier as ProductId];
        return {
          id: pkg.identifier as ProductId,
          title: base?.title ?? pkg.product.title,
          description: base?.description ?? pkg.product.description,
          price: pkg.product.priceString,
          currency: pkg.product.currencyCode,
        };
      });
    } catch {
      return Object.values(PRODUCTS).map((p) => ({
        ...p,
        price: "N/A",
        currency: "USD",
      }));
    }
  }

  /**
   * Purchase a product.
   */
  async purchase(productId: ProductId): Promise<PurchaseResult> {
    try {
      if (!this.revenueCat) {
        return { success: false, error: "IAP not available" };
      }

      const rc = this.revenueCat as {
        purchasePackage?: (options: { aPackage: { identifier: string } }) => Promise<{
          customerInfo?: { entitlements?: { active?: Record<string, unknown> } };
        }>;
      };

      const result = await rc.purchasePackage?.({
        aPackage: { identifier: productId },
      });

      if (result?.customerInfo?.entitlements?.active?.[productId]) {
        this.purchasedProducts.add(productId);
        this.savePurchases();

        eventBus.emit("iap:purchased" as string, { productId });
        return { success: true, productId };
      }

      return { success: false, error: "Purchase not confirmed" };
    } catch (err) {
      const message = err instanceof Error ? err.message : "Purchase failed";
      return { success: false, error: message };
    }
  }

  /**
   * Restore previous purchases (for new device reinstalls).
   */
  async restorePurchases(): Promise<void> {
    try {
      if (!this.revenueCat) return;

      const rc = this.revenueCat as {
        restorePurchases?: () => Promise<{
          entitlements?: { active?: Record<string, unknown> };
        }>;
      };
      const result = await rc.restorePurchases?.();
      const active = result?.entitlements?.active ?? {};

      for (const key of Object.keys(active)) {
        this.purchasedProducts.add(key);
      }
      this.savePurchases();
    } catch {
      // Ignore restore failures
    }
  }

  /**
   * Check if a product has been purchased.
   */
  hasPurchased(productId: ProductId): boolean {
    return this.purchasedProducts.has(productId);
  }

  /**
   * Check if ads should be disabled.
   */
  isAdFree(): boolean {
    return this.hasPurchased("remove_ads_lifetime");
  }

  /**
   * Get total hints available (from purchases).
   */
  getHintCount(): number {
    let count = 0;
    if (this.hasPurchased("hint_pack_small")) count += 10;
    if (this.hasPurchased("hint_pack_medium")) count += 30;
    if (this.hasPurchased("hint_pack_large")) count += 100;
    return count;
  }

  /* ─── Private ─── */

  private detectRevenueCat(): void {
    if (typeof window !== "undefined" && "Capacitor" in window) {
      import("@revenuecat/purchases-capacitor").then((mod) => {
        this.revenueCat = mod.Purchases;
      }).catch(() => {
        // RevenueCat not available
      });
    }
  }

  private loadPurchases(): void {
    try {
      const raw = localStorage.getItem("puzzle_platform_iap");
      if (raw) {
        const arr = JSON.parse(raw) as string[];
        arr.forEach((id) => this.purchasedProducts.add(id));
      }
    } catch { /* ignore */ }
  }

  private savePurchases(): void {
    try {
      localStorage.setItem(
        "puzzle_platform_iap",
        JSON.stringify([...this.purchasedProducts])
      );
    } catch { /* ignore */ }
  }
}

export const iapService = new IAPService();
