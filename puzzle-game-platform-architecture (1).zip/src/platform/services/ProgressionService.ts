/**
 * ProgressionService — One shared XP + player level across all games.
 *
 * Design rules (from the competitive audit):
 *   - One wallet, one XP, one streak. Never per-game currencies.
 *   - XP rewards completion and wins, scaled by difficulty.
 *   - Level curve is shallow early (fast dopamine) and flattens.
 */

import { eventBus, Events } from "@/engine";

export interface ProgressionState {
  xp: number;
  level: number;
  gamesPlayed: number;
  gamesWon: number;
}

const STORAGE_KEY = "puzzle_platform_progression";

/** Cumulative XP required to *reach* a given level. */
export function xpForLevel(level: number): number {
  return Math.floor(80 * (level - 1) * Math.pow(level, 1.35));
}

export function levelForXp(xp: number): number {
  let level = 1;
  while (xpForLevel(level + 1) <= xp && level < 999) level++;
  return level;
}

class ProgressionService {
  private state: ProgressionState;

  constructor() {
    this.state = this.load();
    eventBus.on(Events.GAME_END, (payload) => {
      const { result, gameId } = payload as {
        gameId?: string;
        result?: { score: number; won: boolean; metrics?: Record<string, number> };
      };
      if (!result) return;
      const difficulty = result.metrics?.difficulty ?? 2;
      this.awardXp(this.computeXp(result.won, result.score, difficulty), {
        gameId: gameId ?? "unknown",
      });
    });
  }

  /* ─── Public API ─── */

  getState(): ProgressionState {
    return { ...this.state };
  }

  getLevel(): number {
    return this.state.level;
  }

  getXp(): number {
    return this.state.xp;
  }

  /** Progress 0..1 toward the next level. */
  getLevelProgress(): number {
    const current = xpForLevel(this.state.level);
    const next = xpForLevel(this.state.level + 1);
    if (next === current) return 1;
    return Math.min(1, (this.state.xp - current) / (next - current));
  }

  awardXp(amount: number, meta?: { gameId?: string }): void {
    if (amount <= 0) return;
    const before = this.state.level;
    this.state.xp += amount;
    this.state.level = levelForXp(this.state.xp);
    this.persist();

    eventBus.emit("progression:xp" as string, { amount, total: this.state.xp });
    if (this.state.level > before) {
      eventBus.emit("progression:levelup" as string, {
        level: this.state.level,
        gameId: meta?.gameId,
      });
    }
  }

  /* ─── Private ─── */

  private computeXp(won: boolean, score: number, difficulty: number): number {
    const base = won ? 40 : 10;
    const diffBonus = Math.max(1, difficulty) * 8;
    const scoreBonus = Math.min(40, Math.floor(Math.sqrt(Math.max(0, score)) / 4));
    return base + diffBonus + scoreBonus;
  }

  private load(): ProgressionState {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) return JSON.parse(raw) as ProgressionState;
    } catch { /* ignore */ }
    return { xp: 0, level: 1, gamesPlayed: 0, gamesWon: 0 };
  }

  private persist(): void {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(this.state));
    } catch { /* ignore */ }
  }
}

export const progressionService = new ProgressionService();
