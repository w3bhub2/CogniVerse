/**
 * ThemeEngine — Full theme system with CSS custom properties.
 *
 * Responsibilities:
 *   - Dynamic CSS variable injection
 *   - Multiple theme presets
 *   - Per-game theme overrides
 *   - Seasonal/event themes
 *   - High contrast accessibility mode
 *   - Color palette generation
 *   - Smooth theme transitions
 *
 * Future Extension Points:
 *   - User-created custom themes
 *   - Theme marketplace
 *   - Dynamic color extraction from game assets
 */

import { eventBus, Events } from "@/engine";

export interface ThemeColors {
  primary: string;
  primaryLight: string;
  primaryDark: string;
  secondary: string;
  secondaryLight: string;
  accent: string;
  accentLight: string;
  background: string;
  backgroundAlt: string;
  surface: string;
  surfaceHover: string;
  surfaceActive: string;
  text: string;
  textSecondary: string;
  textMuted: string;
  textInverse: string;
  border: string;
  borderLight: string;
  success: string;
  warning: string;
  error: string;
  info: string;
  shadow: string;
  overlay: string;
  gradient: string;
}

export interface Theme {
  id: string;
  name: string;
  colors: ThemeColors;
  dark: boolean;
  borderRadius: string;
  fontFamily: string;
  spacing: string;
}

/* ─── Built-in Themes ─── */

const LIGHT_THEME: Theme = {
  id: "default-light",
  name: "Light",
  dark: false,
  borderRadius: "12px",
  fontFamily: "'Inter', system-ui, sans-serif",
  spacing: "4px",
  colors: {
    primary: "#6366f1",
    primaryLight: "#818cf8",
    primaryDark: "#4f46e5",
    secondary: "#0ea5e9",
    secondaryLight: "#38bdf8",
    accent: "#f59e0b",
    accentLight: "#fbbf24",
    background: "#f8fafc",
    backgroundAlt: "#f1f5f9",
    surface: "#ffffff",
    surfaceHover: "#f8fafc",
    surfaceActive: "#f1f5f9",
    text: "#0f172a",
    textSecondary: "#475569",
    textMuted: "#94a3b8",
    textInverse: "#ffffff",
    border: "#e2e8f0",
    borderLight: "#f1f5f9",
    success: "#10b981",
    warning: "#f59e0b",
    error: "#ef4444",
    info: "#3b82f6",
    shadow: "rgba(15, 23, 42, 0.08)",
    overlay: "rgba(15, 23, 42, 0.5)",
    gradient: "linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%)",
  },
};

const DARK_THEME: Theme = {
  id: "default-dark",
  name: "Dark",
  dark: true,
  borderRadius: "12px",
  fontFamily: "'Inter', system-ui, sans-serif",
  spacing: "4px",
  colors: {
    primary: "#818cf8",
    primaryLight: "#a5b4fc",
    primaryDark: "#6366f1",
    secondary: "#38bdf8",
    secondaryLight: "#7dd3fc",
    accent: "#fbbf24",
    accentLight: "#fcd34d",
    background: "#0f172a",
    backgroundAlt: "#1e293b",
    surface: "#1e293b",
    surfaceHover: "#334155",
    surfaceActive: "#475569",
    text: "#f1f5f9",
    textSecondary: "#94a3b8",
    textMuted: "#64748b",
    textInverse: "#0f172a",
    border: "#334155",
    borderLight: "#1e293b",
    success: "#34d399",
    warning: "#fbbf24",
    error: "#f87171",
    info: "#60a5fa",
    shadow: "rgba(0, 0, 0, 0.3)",
    overlay: "rgba(0, 0, 0, 0.6)",
    gradient: "linear-gradient(135deg, #818cf8 0%, #a78bfa 100%)",
  },
};

const NEON_THEME: Theme = {
  id: "neon",
  name: "Neon",
  dark: true,
  borderRadius: "16px",
  fontFamily: "'Orbitron', monospace",
  spacing: "4px",
  colors: {
    primary: "#00ff88",
    primaryLight: "#66ffbb",
    primaryDark: "#00cc6a",
    secondary: "#00ccff",
    secondaryLight: "#66ddff",
    accent: "#ff00ff",
    accentLight: "#ff66ff",
    background: "#0a0a0f",
    backgroundAlt: "#12121a",
    surface: "#1a1a2e",
    surfaceHover: "#252540",
    surfaceActive: "#303050",
    text: "#e0e0ff",
    textSecondary: "#a0a0cc",
    textMuted: "#606080",
    textInverse: "#0a0a0f",
    border: "#2a2a40",
    borderLight: "#1a1a2e",
    success: "#00ff88",
    warning: "#ffaa00",
    error: "#ff3366",
    info: "#00ccff",
    shadow: "rgba(0, 255, 136, 0.1)",
    overlay: "rgba(10, 10, 15, 0.85)",
    gradient: "linear-gradient(135deg, #00ff88 0%, #00ccff 50%, #ff00ff 100%)",
  },
};

const WARM_THEME: Theme = {
  id: "warm",
  name: "Sunset",
  dark: false,
  borderRadius: "16px",
  fontFamily: "'Nunito', system-ui, sans-serif",
  spacing: "4px",
  colors: {
    primary: "#e85d04",
    primaryLight: "#f48c06",
    primaryDark: "#dc2f02",
    secondary: "#ffba08",
    secondaryLight: "#ffc300",
    accent: "#9d0208",
    accentLight: "#d00000",
    background: "#fefae0",
    backgroundAlt: "#faedcd",
    surface: "#ffffff",
    surfaceHover: "#fefae0",
    surfaceActive: "#faedcd",
    text: "#370617",
    textSecondary: "#6a040f",
    textMuted: "#9d0208",
    textInverse: "#ffffff",
    border: "#e9d8a6",
    borderLight: "#faedcd",
    success: "#2d6a4f",
    warning: "#e85d04",
    error: "#d00000",
    info: "#023e8a",
    shadow: "rgba(55, 6, 23, 0.1)",
    overlay: "rgba(55, 6, 23, 0.5)",
    gradient: "linear-gradient(135deg, #e85d04 0%, #dc2f02 100%)",
  },
};

export const BUILTIN_THEMES: Record<string, Theme> = {
  light: LIGHT_THEME,
  dark: DARK_THEME,
  neon: NEON_THEME,
  warm: WARM_THEME,
};

const STORAGE_KEY = "puzzle_platform_theme";

export class ThemeEngine {
  private currentTheme: Theme = LIGHT_THEME;
  private customThemes = new Map<string, Theme>();
  private root: HTMLElement | null = null;

  constructor() {
    if (typeof document !== "undefined") {
      this.root = document.documentElement;
    }
    this.loadSaved();
  }

  /* ─── Public API ─── */

  /**
   * Apply a theme by ID.
   */
  apply(themeId: string): void {
    const theme = BUILTIN_THEMES[themeId] ?? this.customThemes.get(themeId);
    if (!theme) return;

    this.currentTheme = theme;
    this.injectCSSVars(theme);
    this.applyClasses(theme);
    this.persist();

    eventBus.emit(Events.THEME_CHANGE, {
      themeId,
      dark: theme.dark,
    });
  }

  /**
   * Toggle between light and dark.
   */
  toggleDarkLight(): Theme {
    const newTheme = this.currentTheme.dark ? "light" : "dark";
    this.apply(newTheme);
    return this.currentTheme;
  }

  /**
   * Get current theme.
   */
  getCurrent(): Theme {
    return this.currentTheme;
  }

  /**
   * Get all available theme IDs and names.
   */
  getAvailable(): { id: string; name: string; dark: boolean }[] {
    const builtins = Object.values(BUILTIN_THEMES).map((t) => ({
      id: t.id,
      name: t.name,
      dark: t.dark,
    }));
    const customs = Array.from(this.customThemes.values()).map((t) => ({
      id: t.id,
      name: t.name,
      dark: t.dark,
    }));
    return [...builtins, ...customs];
  }

  /**
   * Register a custom theme.
   */
  registerTheme(theme: Theme): void {
    this.customThemes.set(theme.id, theme);
  }

  /**
   * Apply a game-specific color override.
   */
  applyGameAccent(color: string): void {
    if (!this.root) return;
    this.root.style.setProperty("--game-accent", color);
  }

  /**
   * Reset game accent to theme default.
   */
  resetGameAccent(): void {
    if (!this.root) return;
    this.root.style.setProperty(
      "--game-accent",
      this.currentTheme.colors.primary
    );
  }

  /* ─── Private ─── */

  private injectCSSVars(theme: Theme): void {
    if (!this.root) return;

    const vars = theme.colors;
    const root = this.root;

    Object.entries(vars).forEach(([key, value]) => {
      const cssKey = `--color-${key.replace(/([A-Z])/g, "-$1").toLowerCase()}`;
      root.style.setProperty(cssKey, value);
    });

    root.style.setProperty("--border-radius", theme.borderRadius);
    root.style.setProperty("--font-family", theme.fontFamily);
    root.style.setProperty("--spacing", theme.spacing);
    root.style.setProperty(
      "--game-accent",
      vars.primary
    );
  }

  private applyClasses(theme: Theme): void {
    if (!this.root) return;
    this.root.classList.remove("light", "dark");
    this.root.classList.add(theme.dark ? "dark" : "light");
    this.root.style.colorScheme = theme.dark ? "dark" : "light";
  }

  private loadSaved(): void {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) {
        const { themeId } = JSON.parse(raw);
        if (themeId && (BUILTIN_THEMES[themeId] || this.customThemes.has(themeId))) {
          this.apply(themeId);
          return;
        }
      }
    } catch { /* ignore */ }

    // Default: respect system preference
    if (
      typeof window !== "undefined" &&
      window.matchMedia("(prefers-color-scheme: dark)").matches
    ) {
      this.apply("dark");
    } else {
      this.apply("light");
    }
  }

  private persist(): void {
    try {
      localStorage.setItem(
        STORAGE_KEY,
        JSON.stringify({ themeId: this.currentTheme.id })
      );
    } catch { /* ignore */ }
  }
}

export const themeEngine = new ThemeEngine();
