/**
 * SettingsService — Manages user preferences.
 *
 * Responsibilities:
 *   - Persist user settings (audio, haptics, theme, language)
 *   - Provide defaults for new users
 *   - Emit change events so UI and services react
 *
 * Flow:
 *   1. User changes a setting
 *   2. SettingsService updates the value
 *   3. SettingsService persists to localStorage
 *   4. SettingsService emits SETTINGS_CHANGE event
 *
 * Future Extension Points:
 *   - Server-side settings sync
 *   - Per-game setting overrides
 *   - Parental controls
 */

import { eventBus, Events } from "@/engine";

export interface UserSettings {
  soundEnabled: boolean;
  musicEnabled: boolean;
  hapticsEnabled: boolean;
  theme: "light" | "dark" | "system";
  language: string;
  showTimer: boolean;
  showScore: boolean;
  animationsEnabled: boolean;
  fontSize: "small" | "medium" | "large";
  highContrast: boolean;
  reduceMotion: boolean;
}

const DEFAULT_SETTINGS: UserSettings = {
  soundEnabled: true,
  musicEnabled: true,
  hapticsEnabled: true,
  theme: "system",
  language: "en",
  showTimer: true,
  showScore: true,
  animationsEnabled: true,
  fontSize: "medium",
  highContrast: false,
  reduceMotion: false,
};

const STORAGE_KEY = "puzzle_platform_settings";

export class SettingsService {
  private settings: UserSettings;

  constructor() {
    this.settings = this.load();
  }

  /* ─── Public API ─── */

  getAll(): UserSettings {
    return { ...this.settings };
  }

  get<K extends keyof UserSettings>(key: K): UserSettings[K] {
    return this.settings[key];
  }

  set<K extends keyof UserSettings>(key: K, value: UserSettings[K]): void {
    this.settings[key] = value;
    this.persist();
    eventBus.emit(Events.SETTINGS_CHANGE, { key, value });
  }

  update(partial: Partial<UserSettings>): void {
    Object.assign(this.settings, partial);
    this.persist();
    eventBus.emit(Events.SETTINGS_CHANGE, { settings: this.settings });
  }

  reset(): void {
    this.settings = { ...DEFAULT_SETTINGS };
    this.persist();
    eventBus.emit(Events.SETTINGS_CHANGE, { settings: this.settings });
  }

  /* ─── Private ─── */

  private load(): UserSettings {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (!raw) return { ...DEFAULT_SETTINGS };
      return { ...DEFAULT_SETTINGS, ...JSON.parse(raw) };
    } catch {
      return { ...DEFAULT_SETTINGS };
    }
  }

  private persist(): void {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(this.settings));
    } catch {
      // Storage full or unavailable
    }
  }
}
