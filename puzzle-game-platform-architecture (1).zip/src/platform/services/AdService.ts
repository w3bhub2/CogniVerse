/**
 * AdService — Ad integration layer.
 *
 * Provides a clean interface for ad display that works with any ad network.
 * Currently stubbed — ready for AdMob/Capacitor integration.
 *
 * Architecture:
 *   - Game emits IAP_TRIGGER event when ad opportunity arises
 *   - AdService checks eligibility (cooldown, daily cap, user preference)
 *   - AdService requests ad from network
 *   - On completion, AdService rewards player via event
 *
 * Future Extension Points:
 *   - Mediation (AdMob + ironSource + Unity Ads)
 *   - A/B testing ad frequencies
 *   - Regional ad network selection
 *   - Ad-free tiers for subscribers
 */

import { eventBus, Events } from "@/engine";

export type AdFormat = "rewarded" | "interstitial" | "banner";

export interface AdConfig {
  /** Minimum seconds between interstitial ads */
  interstitialCooldown: number;
  /** Maximum rewarded ads per day */
  dailyRewardedCap: number;
  /** Minimum games played before showing first interstitial */
  minGamesBeforeFirstAd: number;
  /** Whether ads are enabled (false = ad-free purchase) */
  enabled: boolean;
}

export interface AdReward {
  type: "hints" | "coins" | "extra_life" | "undo_pack";
  amount: number;
}

const DEFAULT_CONFIG: AdConfig = {
  interstitialCooldown: 90, // 90 seconds between interstitials
  dailyRewardedCap: 10,
  minGamesBeforeFirstAd: 3,
  enabled: true,
};

const STORAGE_KEY = "puzzle_platform_ad_state";

interface AdState {
  lastInterstitialTime: number;
  gamesPlayedSinceLastAd: number;
  rewardedCountToday: number;
  lastRewardedDate: string;
}

class AdService {
  private config: AdConfig = { ...DEFAULT_CONFIG };
  private state: AdState = this.loadState();
  private adNetwork: unknown = null; // Will hold Capacitor AdMob reference

  constructor() {
    this.detectAdNetwork();
  }

  /* ─── Public API ─── */

  /**
   * Configure ad parameters.
   */
  configure(config: Partial<AdConfig>): void {
    this.config = { ...this.config, ...config };
  }

  /**
   * Check if an interstitial ad can be shown.
   */
  canShowInterstitial(): boolean {
    if (!this.config.enabled) return false;
    if (this.state.gamesPlayedSinceLastAd < this.config.minGamesBeforeFirstAd) {
      return false;
    }
    const elapsed = (Date.now() - this.state.lastInterstitialTime) / 1000;
    return elapsed >= this.config.interstitialCooldown;
  }

  /**
   * Check if a rewarded ad can be shown.
   */
  canShowRewarded(): boolean {
    if (!this.config.enabled) return false;
    if (this.isNewDay()) {
      this.state.rewardedCountToday = 0;
    }
    return this.state.rewardedCountToday < this.config.dailyRewardedCap;
  }

  /**
   * Record that a game was played (for interstitial timing).
   */
  recordGamePlayed(): void {
    this.state.gamesPlayedSinceLastAd++;
    this.persistState();
  }

  /**
   * Show an interstitial ad.
   * Returns true if ad was shown successfully.
   */
  async showInterstitial(): Promise<boolean> {
    if (!this.canShowInterstitial()) return false;

    try {
      // In production: await this.adNetwork.showInterstitial()
      console.log("[AdService] Interstitial shown");

      this.state.lastInterstitialTime = Date.now();
      this.state.gamesPlayedSinceLastAd = 0;
      this.persistState();

      eventBus.emit("ad:shown" as string, {
        format: "interstitial",
        timestamp: Date.now(),
      });

      return true;
    } catch {
      return false;
    }
  }

  /**
   * Show a rewarded ad.
   * Returns the reward if completed, null if skipped/failed.
   */
  async showRewarded(reward: AdReward): Promise<AdReward | null> {
    if (!this.canShowRewarded()) return null;

    try {
      // In production: const completed = await this.adNetwork.showRewarded()
      const completed = true; // Stub

      if (completed) {
        this.state.rewardedCountToday++;
        this.persistState();

        eventBus.emit("ad:rewarded" as string, {
          reward,
          timestamp: Date.now(),
        });

        return reward;
      }

      return null;
    } catch {
      return null;
    }
  }

  /**
   * Disable ads (for ad-free purchase).
   */
  disable(): void {
    this.config.enabled = false;
    eventBus.emit(Events.SETTINGS_CHANGE, { key: "adsEnabled", value: false });
  }

  /**
   * Re-enable ads.
   */
  enable(): void {
    this.config.enabled = true;
  }

  /**
   * Get current ad state for UI display.
   */
  getState(): {
    enabled: boolean;
    canShowInterstitial: boolean;
    canShowRewarded: boolean;
    rewardedRemaining: number;
  } {
    const remaining = this.config.dailyRewardedCap - this.state.rewardedCountToday;
    return {
      enabled: this.config.enabled,
      canShowInterstitial: this.canShowInterstitial(),
      canShowRewarded: this.canShowRewarded(),
      rewardedRemaining: Math.max(0, remaining),
    };
  }

  /* ─── Private ─── */

  private detectAdNetwork(): void {
    // Detect Capacitor AdMob at runtime
    if (typeof window !== "undefined" && "Capacitor" in window) {
      import("@capacitor-community/admob").then((mod) => {
        this.adNetwork = mod.AdMob;
      }).catch(() => {
        // AdMob not available
      });
    }
  }

  private isNewDay(): boolean {
    const today = new Date().toISOString().split("T")[0];
    return this.state.lastRewardedDate !== today;
  }

  private loadState(): AdState {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) return JSON.parse(raw);
    } catch { /* ignore */ }
    return {
      lastInterstitialTime: 0,
      gamesPlayedSinceLastAd: 0,
      rewardedCountToday: 0,
      lastRewardedDate: "",
    };
  }

  private persistState(): void {
    this.state.lastRewardedDate = new Date().toISOString().split("T")[0];
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(this.state));
    } catch { /* ignore */ }
  }
}

export const adService = new AdService();
