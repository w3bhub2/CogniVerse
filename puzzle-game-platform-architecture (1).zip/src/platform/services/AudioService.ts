/**
 * AudioService — Manages sound effects and music.
 *
 * Responsibilities:
 *   - Play/stop/pause sound effects
 *   - Background music management
 *   - Volume control
 *   - Respect user audio preferences
 *
 * Flow:
 *   1. Game requests a sound via event bus or direct call
 *   2. AudioService checks if audio is enabled
 *   3. AudioService plays the sound via Web Audio API
 *
 * Future Extension Points:
 *   - Spatial audio
 *   - Dynamic music layers
 *   - Audio visualization
 */

export type SoundId =
  | "tile_merge"
  | "tile_move"
  | "button_click"
  | "game_start"
  | "game_win"
  | "game_lose"
  | "achievement"
  | "undo"
  | "redo"
  | "error";

class AudioService {
  private audioContext: AudioContext | null = null;
  private soundEnabled: boolean = true;
  private musicEnabled: boolean = true;
  private volume: number = 0.7;

  /**
   * Initialize the audio context (must be called from a user gesture).
   */
  init(): void {
    if (typeof window === "undefined") return;
    try {
      this.audioContext = new AudioContext();
    } catch {
      // Audio not supported
    }
  }

  /**
   * Play a sound effect.
   */
  play(soundId: SoundId): void {
    if (!this.soundEnabled || !this.audioContext) return;

    // Use a simple oscillator-based synthesis for demo
    // In production, load audio files from /public/audio/
    const freq = this.getFrequency(soundId);
    if (!freq) return;

    const osc = this.audioContext.createOscillator();
    const gain = this.audioContext.createGain();

    osc.connect(gain);
    gain.connect(this.audioContext.destination);

    osc.frequency.value = freq;
    osc.type = "sine";
    gain.gain.value = this.volume * 0.3;
    gain.gain.exponentialRampToValueAtTime(
      0.001,
      this.audioContext.currentTime + 0.15
    );

    osc.start();
    osc.stop(this.audioContext.currentTime + 0.15);
  }

  setSoundEnabled(enabled: boolean): void {
    this.soundEnabled = enabled;
  }

  setMusicEnabled(enabled: boolean): void {
    this.musicEnabled = enabled;
  }

  setVolume(volume: number): void {
    this.volume = Math.max(0, Math.min(1, volume));
  }

  private getFrequency(soundId: SoundId): number | null {
    const frequencies: Record<SoundId, number> = {
      tile_merge: 880,
      tile_move: 440,
      button_click: 660,
      game_start: 523,
      game_win: 784,
      game_lose: 220,
      achievement: 1047,
      undo: 330,
      redo: 392,
      error: 200,
    };
    return frequencies[soundId] ?? null;
  }
}

export const audioService = new AudioService();
