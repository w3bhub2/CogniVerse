/**
 * StreakService — Daily-return retention spine.
 *
 * Implements the three elements the retention literature requires:
 *   1. A daily action with low friction (any completed game counts)
 *   2. A freeze so one missed day doesn't destroy investment
 *   3. Escalating acknowledgement of long streaks
 *
 * Listens for game:end and records completion automatically.
 */

import { eventBus, Events } from "@/engine";

export interface StreakState {
  current: number;
  best: number;
  lastCompletedDay: string | null; // YYYY-MM-DD
  freezesAvailable: number;
  totalCompletions: number;
}

const STORAGE_KEY = "puzzle_platform_streak";

class StreakService {
  private state: StreakState;

  constructor() {
    this.state = this.load();
    eventBus.on(Events.GAME_END, (payload) => {
      const { result } = payload as {
        result?: { won?: boolean };
      };
      // Any finished game counts; a win is not required,
      // keeping the daily action low-friction.
      if (result) this.recordCompletion();
    });
  }

  /* ─── Public API ─── */

  getStreak(): number {
    this.reconcile();
    return this.state.current;
  }

  getBest(): number {
    return this.state.best;
  }

  getFreezes(): number {
    return this.state.freezesAvailable;
  }

  getTotalCompletions(): number {
    return this.state.totalCompletions;
  }

  /**
   * Record a completed game today. Safe to call multiple times per day.
   */
  recordCompletion(dayKey?: string): void {
    const today = dayKey ?? this.todayKey();
    if (this.state.lastCompletedDay === today) return;

    const yesterday = this.keyDaysAgo(1);
    if (
      this.state.lastCompletedDay === yesterday ||
      this.state.lastCompletedDay === null
    ) {
      this.state.current += 1;
    } else if (this.state.freezesAvailable > 0) {
      // Spend a freeze instead of resetting.
      this.state.freezesAvailable -= 1;
      this.state.current += 1;
    } else {
      this.state.current = 1;
    }

    this.state.best = Math.max(this.state.best, this.state.current);
    this.state.lastCompletedDay = today;
    this.state.totalCompletions += 1;

    // Earn a freeze every 7-day streak.
    if (this.state.current % 7 === 0) {
      this.state.freezesAvailable += 1;
    }

    this.persist();
    eventBus.emit("streak:update" as string, {
      streak: this.state.current,
      best: this.state.best,
    });
  }

  /**
   * Full state for UI (calendar, counters).
   */
  getState(): StreakState {
    this.reconcile();
    return { ...this.state };
  }

  /* ─── Private ─── */

  /** If the streak is stale and no freeze applies, reset to 0. */
  private reconcile(): void {
    const last = this.state.lastCompletedDay;
    if (!last) return;
    if (last === this.todayKey() || last === this.keyDaysAgo(1)) return;
    if (this.state.freezesAvailable > 0) return;
    if (this.state.current > 0) {
      this.state.current = 0;
      this.persist();
    }
  }

  private todayKey(): string {
    return this.dayKey(new Date());
  }

  private keyDaysAgo(n: number): string {
    const d = new Date();
    d.setDate(d.getDate() - n);
    return this.dayKey(d);
  }

  private dayKey(d: Date): string {
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
  }

  private load(): StreakState {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) return JSON.parse(raw) as StreakState;
    } catch { /* ignore */ }
    return {
      current: 0,
      best: 0,
      lastCompletedDay: null,
      freezesAvailable: 1, // grace freeze for new players
      totalCompletions: 0,
    };
  }

  private persist(): void {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(this.state));
    } catch { /* ignore */ }
  }
}

export const streakService = new StreakService();
