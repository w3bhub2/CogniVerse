/**
 * AnalyticsService — Tracks game events and user behavior.
 *
 * Responsibilities:
 *   - Track game starts, pauses, ends, scores
 *   - Track feature usage
 *   - Batch and send events to the server
 *   - Store events locally when offline
 *
 * Flow:
 *   1. Game or platform emits an event
 *   2. AnalyticsService captures it with metadata
 *   3. Events are batched and sent to /api/analytics
 *   4. Failed sends are retried from local queue
 *
 * Future Extension Points:
 *   - A/B testing integration
 *   - Funnel analysis
 *   - Revenue tracking
 *   - Crash reporting
 */

import { eventBus, Events } from "@/engine";

export interface AnalyticsEvent {
  name: string;
  properties: Record<string, unknown>;
  timestamp: number;
  sessionId: string;
  userId?: string;
}

const STORAGE_KEY = "puzzle_platform_analytics";
const BATCH_SIZE = 20;
const FLUSH_INTERVAL_MS = 30_000;

export class AnalyticsService {
  private queue: AnalyticsEvent[] = [];
  private sessionId: string;
  private flushTimer: ReturnType<typeof setInterval> | null = null;
  private enabled: boolean = true;

  constructor() {
    this.sessionId = this.generateSessionId();
    this.loadQueuedEvents();
    this.setupAutoFlush();
    this.setupListeners();
  }

  /* ─── Public API ─── */

  /**
   * Track a named event with properties.
   */
  track(name: string, properties: Record<string, unknown> = {}): void {
    if (!this.enabled) return;

    const event: AnalyticsEvent = {
      name,
      properties,
      timestamp: Date.now(),
      sessionId: this.sessionId,
    };

    this.queue.push(event);
    this.persist();

    if (this.queue.length >= BATCH_SIZE) {
      this.flush();
    }
  }

  /**
   * Flush all queued events to the server.
   */
  async flush(): Promise<void> {
    if (this.queue.length === 0) return;

    const events = [...this.queue];
    this.queue = [];
    this.persist();

    try {
      await fetch("/api/analytics", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ events }),
      });
    } catch {
      // Re-queue failed events
      this.queue = [...events, ...this.queue];
      this.persist();
    }
  }

  /**
   * Enable or disable tracking.
   */
  setEnabled(enabled: boolean): void {
    this.enabled = enabled;
    if (!enabled) {
      this.queue = [];
      this.persist();
    }
  }

  /* ─── Private ─── */

  private setupListeners(): void {
    eventBus.on(Events.GAME_START, (payload) => {
      const { gameId } = payload as { gameId: string };
      this.track("game_start", { gameId });
    });

    eventBus.on(Events.GAME_END, (payload) => {
      const { gameId, result } = payload as {
        gameId: string;
        result: { score: number; won: boolean; timeElapsed: number };
      };
      this.track("game_end", {
        gameId,
        score: result.score,
        won: result.won,
        timeElapsed: result.timeElapsed,
      });
    });

    eventBus.on(Events.GAME_PAUSE, (payload) => {
      const { gameId } = payload as { gameId: string };
      this.track("game_pause", { gameId });
    });

    eventBus.on(Events.ACHIEVEMENT_UNLOCKED, (payload) => {
      this.track("achievement_unlocked", payload as Record<string, unknown>);
    });
  }

  private setupAutoFlush(): void {
    if (typeof window === "undefined") return;
    this.flushTimer = setInterval(() => this.flush(), FLUSH_INTERVAL_MS);
  }

  private persist(): void {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(this.queue));
    } catch {
      // Ignore
    }
  }

  private loadQueuedEvents(): void {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) {
        this.queue = JSON.parse(raw);
      }
    } catch {
      this.queue = [];
    }
  }

  private generateSessionId(): string {
    return `s_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
  }
}
