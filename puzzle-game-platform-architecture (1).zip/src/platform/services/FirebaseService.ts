/**
 * FirebaseService — Thin wrapper for Firebase SDKs.
 *
 * Wraps Firebase Analytics, Crashlytics, and Remote Config
 * behind a clean interface that works in both web and Capacitor.
 *
 * Initialization is lazy — only connects when Firebase is available.
 * All methods no-op gracefully if Firebase isn't initialized.
 *
 * Future Extension Points:
 *   - Firebase Auth integration
 *   - Firestore cloud sync
 *   - Cloud Messaging (push notifications)
 *   - A/B Testing via Remote Config
 */

import { eventBus, Events } from "@/engine";

class FirebaseService {
  private analytics: unknown = null;
  private crashlytics: unknown = null;
  private remoteConfig: unknown = null;
  private initialized = false;

  /**
   * Initialize Firebase. Call once at app start.
   * In Capacitor: uses native Firebase SDK.
   * In web: uses Firebase JS SDK.
   */
  async initialize(config?: {
    analyticsEnabled?: boolean;
    crashlyticsEnabled?: boolean;
    remoteConfigEnabled?: boolean;
  }): Promise<void> {
    if (this.initialized) return;

    try {
      // Try to load Firebase dynamically
      const firebaseApp = await this.loadFirebaseApp();
      if (!firebaseApp) return;

      if (config?.analyticsEnabled !== false) {
        this.analytics = await this.loadAnalytics(firebaseApp);
      }
      if (config?.crashlyticsEnabled !== false) {
        this.crashlytics = await this.loadCrashlytics(firebaseApp);
      }
      if (config?.remoteConfigEnabled !== false) {
        this.remoteConfig = await this.loadRemoteConfig(firebaseApp);
      }

      this.initialized = true;

      // Listen for game events and log them
      this.setupEventListeners();
    } catch {
      console.warn("[FirebaseService] Initialization failed — running without Firebase");
    }
  }

  /* ─── Analytics ─── */

  /**
   * Log a custom analytics event.
   */
  logEvent(name: string, params?: Record<string, unknown>): void {
    if (!this.analytics) return;
    try {
      const analytics = this.analytics as {
        logEvent?: (name: string, params?: Record<string, unknown>) => void;
      };
      analytics.logEvent?.(name, params);
    } catch { /* ignore */ }
  }

  /**
   * Set a user property.
   */
  setUserProperty(name: string, value: string): void {
    if (!this.analytics) return;
    try {
      const analytics = this.analytics as {
        setAnalyticsCollectionEnabled?: (enabled: boolean) => void;
      };
      // Firebase Analytics doesn't have setUserProperty directly in v9+
      // Use logEvent with user_properties instead
      this.logEvent("set_user_property", { name, value });
    } catch { /* ignore */ }
  }

  /* ─── Crashlytics ─── */

  /**
   * Record a non-fatal error.
   */
  recordError(error: Error, context?: Record<string, string>): void {
    if (!this.crashlytics) return;
    try {
      const cr = this.crashlytics as {
        recordError?: (error: Error) => void;
        setAttribute?: (key: string, value: string) => void;
      };
      if (context) {
        for (const [key, value] of Object.entries(context)) {
          cr.setAttribute?.(key, value);
        }
      }
      cr.recordError?.(error);
    } catch { /* ignore */ }
  }

  /**
   * Log a custom message to Crashlytics.
   */
  log(message: string): void {
    if (!this.crashlytics) return;
    try {
      const cr = this.crashlytics as {
        log?: (message: string) => void;
      };
      cr.log?.(message);
    } catch { /* ignore */ }
  }

  /* ─── Remote Config ─── */

  /**
   * Fetch and activate remote config values.
   */
  async fetchConfig(): Promise<void> {
    if (!this.remoteConfig) return;
    try {
      const rc = this.remoteConfig as {
        fetchAndActivate?: () => Promise<boolean>;
      };
      await rc.fetchAndActivate?.();
    } catch { /* ignore */ }
  }

  /**
   * Get a remote config value.
   */
  getString(key: string, defaultValue: string = ""): string {
    if (!this.remoteConfig) return defaultValue;
    try {
      const rc = this.remoteConfig as {
        getString?: (key: string) => string;
      };
      return rc.getString?.(key) ?? defaultValue;
    } catch {
      return defaultValue;
    }
  }

  /**
   * Get a remote config boolean.
   */
  getBoolean(key: string, defaultValue: boolean = false): boolean {
    if (!this.remoteConfig) return defaultValue;
    try {
      const rc = this.remoteConfig as {
        getBoolean?: (key: string) => boolean;
      };
      return rc.getBoolean?.(key) ?? defaultValue;
    } catch {
      return defaultValue;
    }
  }

  /**
   * Get a remote config number.
   */
  getNumber(key: string, defaultValue: number = 0): number {
    if (!this.remoteConfig) return defaultValue;
    try {
      const rc = this.remoteConfig as {
        getNumber?: (key: string) => number;
      };
      return rc.getNumber?.(key) ?? defaultValue;
    } catch {
      return defaultValue;
    }
  }

  /* ─── Private ─── */

  private setupEventListeners(): void {
    // Auto-log game events to Firebase Analytics
    eventBus.on(Events.GAME_START, (payload) => {
      const { gameId } = payload as { gameId: string };
      this.logEvent("game_start", { game_id: gameId });
    });

    eventBus.on(Events.GAME_END, (payload) => {
      const { gameId, result } = payload as {
        gameId: string;
        result: { score: number; won: boolean; timeElapsed: number };
      };
      this.logEvent("game_end", {
        game_id: gameId,
        score: result.score,
        won: result.won,
        time_seconds: Math.floor(result.timeElapsed / 1000),
      });
    });

    eventBus.on(Events.ACHIEVEMENT_UNLOCKED, (payload) => {
      const { id, name } = payload as { id: string; name: string };
      this.logEvent("achievement_unlocked", {
        achievement_id: id,
        achievement_name: name,
      });
    });
  }

  private async loadFirebaseApp(): Promise<unknown> {
    try {
      const mod = await import("firebase/app");
      // In production, Firebase config comes from environment
      const config: Record<string, string> = {
        apiKey: process.env.NEXT_PUBLIC_FIREBASE_API_KEY ?? "",
        authDomain: process.env.NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN ?? "",
        projectId: process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID ?? "",
        storageBucket: process.env.NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET ?? "",
        messagingSenderId: process.env.NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID ?? "",
        appId: process.env.NEXT_PUBLIC_FIREBASE_APP_ID ?? "",
      };

      if (!config.apiKey) return null;

      const initializeApp = (mod as { initializeApp: (config: Record<string, string>) => unknown }).initializeApp;
      return initializeApp(config);
    } catch {
      return null;
    }
  }

  private async loadAnalytics(app: unknown): Promise<unknown> {
    try {
      const mod = await import("firebase/analytics");
      const getAnalytics = (mod as { getAnalytics: (app: unknown) => unknown }).getAnalytics;
      return getAnalytics(app);
    } catch {
      return null;
    }
  }

  private async loadCrashlytics(_app: unknown): Promise<unknown> {
    // Firebase Crashlytics requires native SDK via Capacitor
    // On web, crash reporting is not available via Firebase JS SDK
    // In Capacitor builds, use @capacitor-firebase/crashlytics
    // For now, return null — will be enabled in native builds
    return null;
  }

  private async loadRemoteConfig(app: unknown): Promise<unknown> {
    try {
      const mod = await import("firebase/remote-config");
      const getRemoteConfig = (mod as { getRemoteConfig: (app: unknown) => unknown }).getRemoteConfig;
      return getRemoteConfig(app);
    } catch {
      return null;
    }
  }
}

export const firebaseService = new FirebaseService();
