/**
 * DailyPuzzleService — One shared seed per game per calendar day.
 *
 * The same seed for every player on the same day is what makes a
 * "daily puzzle" comparable and shareable (the Wordle/NYT effect).
 * Built on SeededRandom so generation stays deterministic.
 */

import { SeededRandom } from "@/engine";

class DailyPuzzleService {
  /**
   * Deterministic seed for a game on a given day (defaults to today).
   */
  getSeed(gameId: string, date: Date = new Date()): number {
    const key = `${gameId}:${this.dayKey(date)}`;
    return new SeededRandom(key).nextInt(1, 2_147_483_647);
  }

  /**
   * Stable YYYY-MM-DD key in local time.
   */
  dayKey(date: Date = new Date()): string {
    const y = date.getFullYear();
    const m = String(date.getMonth() + 1).padStart(2, "0");
    const d = String(date.getDate()).padStart(2, "0");
    return `${y}-${m}-${d}`;
  }

  /**
   * Human label, e.g. "July 27".
   */
  label(date: Date = new Date()): string {
    return date.toLocaleDateString(undefined, {
      month: "long",
      day: "numeric",
    });
  }
}

export const dailyPuzzleService = new DailyPuzzleService();
