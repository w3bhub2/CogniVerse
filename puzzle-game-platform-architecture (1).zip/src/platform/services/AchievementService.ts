/**
 * AchievementService — Tracks and unlocks achievements.
 *
 * Responsibilities:
 *   - Define achievement conditions
 *   - Check conditions on game events
 *   - Persist unlocked achievements
 *   - Notify the user of new unlocks
 *
 * Flow:
 *   1. Game emits a score or event
 *   2. AchievementService evaluates all achievement conditions
 *   3. If conditions met, unlock and persist
 *   4. Emit ACHIEVEMENT_UNLOCKED event
 *
 * Future Extension Points:
 *   - Tiered achievements (bronze, silver, gold)
 *   - Secret achievements
 *   - Leaderboard integration
 */

import { eventBus, Events } from "@/engine";

export interface Achievement {
  id: string;
  name: string;
  description: string;
  icon: string;
  condition: AchievementCondition;
  unlockedAt?: number;
}

export interface AchievementCondition {
  type: "score_above" | "games_played" | "games_won" | "win_streak" | "total_moves";
  value: number;
  gameId?: string;
}

const STORAGE_KEY = "puzzle_platform_achievements";

const ACHIEVEMENT_DEFINITIONS: Omit<Achievement, "unlockedAt">[] = [
  {
    id: "first_game",
    name: "First Steps",
    description: "Complete your first game",
    icon: "🎮",
    condition: { type: "games_played", value: 1 },
  },
  {
    id: "first_win",
    name: "Winner",
    description: "Win your first game",
    icon: "🏆",
    condition: { type: "games_won", value: 1 },
  },
  {
    id: "score_1000",
    name: "High Scorer",
    description: "Score over 1,000 points in a single game",
    icon: "⭐",
    condition: { type: "score_above", value: 1000 },
  },
  {
    id: "score_10000",
    name: "Point Master",
    description: "Score over 10,000 points in a single game",
    icon: "🌟",
    condition: { type: "score_above", value: 10000 },
  },
  {
    id: "games_10",
    name: "Dedicated",
    description: "Play 10 games",
    icon: "🎯",
    condition: { type: "games_played", value: 10 },
  },
  {
    id: "games_100",
    name: "Obsessed",
    description: "Play 100 games",
    icon: "💎",
    condition: { type: "games_played", value: 100 },
  },
  {
    id: "win_streak_3",
    name: "Hat Trick",
    description: "Win 3 games in a row",
    icon: "🔥",
    condition: { type: "win_streak", value: 3 },
  },
  {
    id: "win_streak_5",
    name: "On Fire",
    description: "Win 5 games in a row",
    icon: "🔥",
    condition: { type: "win_streak", value: 5 },
  },
];

export class AchievementService {
  private achievements: Achievement[];
  private stats: {
    gamesPlayed: number;
    gamesWon: number;
    winStreak: number;
    bestWinStreak: number;
    highestScore: number;
    totalMoves: number;
  };

  constructor() {
    this.stats = this.loadStats();
    this.achievements = this.loadAchievements();
    this.setupListeners();
  }

  getAchievements(): Achievement[] {
    return this.achievements.map((a) => ({ ...a }));
  }

  getUnlockedCount(): number {
    return this.achievements.filter((a) => a.unlockedAt).length;
  }

  getTotalCount(): number {
    return this.achievements.length;
  }

  getStats() {
    return { ...this.stats };
  }

  /* ─── Private ─── */

  private setupListeners(): void {
    eventBus.on(Events.GAME_END, (payload) => {
      const { result } = payload as {
        result: { score: number; won: boolean };
      };

      this.stats.gamesPlayed++;

      if (result.won) {
        this.stats.gamesWon++;
        this.stats.winStreak++;
        this.stats.bestWinStreak = Math.max(
          this.stats.bestWinStreak,
          this.stats.winStreak
        );
      } else {
        this.stats.winStreak = 0;
      }

      this.stats.highestScore = Math.max(
        this.stats.highestScore,
        result.score
      );

      this.persistStats();
      this.evaluateAll();
    });
  }

  private evaluateAll(): void {
    for (const achievement of this.achievements) {
      if (achievement.unlockedAt) continue;
      if (this.evaluateCondition(achievement.condition)) {
        achievement.unlockedAt = Date.now();
        this.persistAchievements();
        eventBus.emit(Events.ACHIEVEMENT_UNLOCKED, {
          id: achievement.id,
          name: achievement.name,
          description: achievement.description,
          icon: achievement.icon,
        });
      }
    }
  }

  private evaluateCondition(condition: AchievementCondition): boolean {
    switch (condition.type) {
      case "games_played":
        return this.stats.gamesPlayed >= condition.value;
      case "games_won":
        return this.stats.gamesWon >= condition.value;
      case "win_streak":
        return this.stats.winStreak >= condition.value;
      case "score_above":
        return this.stats.highestScore >= condition.value;
      case "total_moves":
        return this.stats.totalMoves >= condition.value;
      default:
        return false;
    }
  }

  private loadAchievements(): Achievement[] {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) {
        const saved = JSON.parse(raw) as Achievement[];
        // Merge with definitions to pick up new achievements
        return ACHIEVEMENT_DEFINITIONS.map((def) => {
          const existing = saved.find((s) => s.id === def.id);
          return { ...def, unlockedAt: existing?.unlockedAt };
        });
      }
    } catch {
      // Ignore
    }
    return ACHIEVEMENT_DEFINITIONS.map((d) => ({ ...d }));
  }

  private persistAchievements(): void {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(this.achievements));
    } catch {
      // Ignore
    }
  }

  private loadStats() {
    try {
      const raw = localStorage.getItem("puzzle_platform_stats");
      if (raw) return JSON.parse(raw);
    } catch {
      // Ignore
    }
    return {
      gamesPlayed: 0,
      gamesWon: 0,
      winStreak: 0,
      bestWinStreak: 0,
      highestScore: 0,
      totalMoves: 0,
    };
  }

  private persistStats(): void {
    try {
      localStorage.setItem(
        "puzzle_platform_stats",
        JSON.stringify(this.stats)
      );
    } catch {
      // Ignore
    }
  }
}
