# Platform

Shared services used by all games. Games never import these directly.

## Services

- **SaveService** — Save/load game state (localStorage + PostgreSQL)
- **SettingsService** — User preferences (audio, theme, accessibility)
- **ThemeService** — Light/dark mode management
- **AnalyticsService** — Event tracking with offline queue
- **AudioService** — Sound effects via Web Audio API
- **AchievementService** — Achievement tracking and persistence
