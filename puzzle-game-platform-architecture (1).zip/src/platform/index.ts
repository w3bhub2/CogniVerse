/**
 * @platform — Puzzle Platform Service Layer
 *
 * Reusable services shared by all games.
 * Games never import these directly — the platform orchestrates them.
 */
export * from "./services";
export { usePlatformStore } from "./store";
