/**
 * Global Zustand Store — Lightweight client state management.
 *
 * Responsibilities:
 *   - Global UI state (modals, drawers, active game)
 *   - Performance stats
 *   - Achievement notifications queue
 *   - Theme state
 */

import { create } from "zustand";

interface PlatformState {
  // Active game
  activeGameId: string | null;
  setActiveGameId: (id: string | null) => void;

  // UI state
  sidebarOpen: boolean;
  toggleSidebar: () => void;
  setSidebarOpen: (open: boolean) => void;

  // Settings modal
  settingsOpen: boolean;
  setSettingsOpen: (open: boolean) => void;

  // Performance
  fps: number;
  setFps: (fps: number) => void;

  // Loading
  isLoading: boolean;
  setLoading: (loading: boolean) => void;

  // Achievement notification queue
  pendingAchievements: Array<{
    id: string;
    name: string;
    icon: string;
    description: string;
  }>;
  addAchievement: (a: {
    id: string;
    name: string;
    icon: string;
    description: string;
  }) => void;
  popAchievement: () => void;
}

export const usePlatformStore = create<PlatformState>((set) => ({
  activeGameId: null,
  setActiveGameId: (id) => set({ activeGameId: id }),

  sidebarOpen: false,
  toggleSidebar: () => set((s) => ({ sidebarOpen: !s.sidebarOpen })),
  setSidebarOpen: (open) => set({ sidebarOpen: open }),

  settingsOpen: false,
  setSettingsOpen: (open) => set({ settingsOpen: open }),

  fps: 0,
  setFps: (fps) => set({ fps }),

  isLoading: false,
  setLoading: (loading) => set({ isLoading: loading }),

  pendingAchievements: [],
  addAchievement: (a) =>
    set((s) => ({ pendingAchievements: [...s.pendingAchievements, a] })),
  popAchievement: () =>
    set((s) => ({
      pendingAchievements: s.pendingAchievements.slice(1),
    })),
}));
