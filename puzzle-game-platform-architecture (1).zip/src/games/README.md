# Games

Game modules implementing the `GameModule` interface.

## Structure

Each game is a directory containing:
- `*Game.ts` — Game logic implementing `GameModule`
- `index.ts` — Re-exports

## Registered Games

- `game2048/` — 2048 tile-sliding puzzle
- `sudoku/` — Classic number placement
- `minesweeper/` — Mine-clearing logic game

## Adding a New Game

1. Create directory `src/games/mygame/`
2. Implement `GameModule` interface
3. Register in `GameRegistry.ts`
4. Create renderer in `src/components/game/`
5. Add to `GamePlayer.tsx`
