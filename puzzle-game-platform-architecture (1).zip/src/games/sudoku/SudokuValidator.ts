/**
 * SudokuValidator — Fairness guarantees for generated puzzles.
 *
 * Responsibilities:
 *   - Prove a puzzle has exactly one solution (uniqueness)
 *   - Detect rule conflicts (duplicate in row/column/box)
 *
 * Why this exists: a generator that removes cells without a uniqueness
 * check can ship multi-solution puzzles — unfair, and a category-standard
 * violation. Every shipped Sudoku must pass `hasUniqueSolution`.
 */

/**
 * Count solutions of a partial grid, stopping at `limit`.
 * Empty cells are 0.
 */
export function countSolutions(grid: number[][], limit = 2): number {
  const g = grid.map((row) => [...row]);
  let count = 0;

  const fits = (r: number, c: number, v: number): boolean => {
    for (let i = 0; i < 9; i++) {
      if (g[r][i] === v || g[i][c] === v) return false;
    }
    const br = Math.floor(r / 3) * 3;
    const bc = Math.floor(c / 3) * 3;
    for (let i = 0; i < 3; i++) {
      for (let j = 0; j < 3; j++) {
        if (g[br + i][bc + j] === v) return false;
      }
    }
    return true;
  };

  const solve = (): void => {
    if (count >= limit) return;
    for (let r = 0; r < 9; r++) {
      for (let c = 0; c < 9; c++) {
        if (g[r][c] === 0) {
          for (let v = 1; v <= 9; v++) {
            if (fits(r, c, v)) {
              g[r][c] = v;
              solve();
              g[r][c] = 0;
              if (count >= limit) return;
            }
          }
          return; // dead end on this branch
        }
      }
    }
    count++;
  };

  solve();
  return count;
}

/**
 * True when the givens produce exactly one completed grid.
 */
export function hasUniqueSolution(givens: number[][]): boolean {
  return countSolutions(givens, 2) === 1;
}

/**
 * True when placing `value` at (row, col) breaks a Sudoku rule.
 * Ignores the cell itself. This is the conflict model used for
 * player feedback (as opposed to comparing against the solution).
 */
export function hasConflict(
  grid: { value: number }[][],
  row: number,
  col: number,
  value: number
): boolean {
  if (value === 0) return false;
  for (let i = 0; i < 9; i++) {
    if (i !== col && grid[row][i].value === value) return true;
    if (i !== row && grid[i][col].value === value) return true;
  }
  const br = Math.floor(row / 3) * 3;
  const bc = Math.floor(col / 3) * 3;
  for (let r = br; r < br + 3; r++) {
    for (let c = bc; c < bc + 3; c++) {
      if ((r !== row || c !== col) && grid[r][c].value === value) return true;
    }
  }
  return false;
}
