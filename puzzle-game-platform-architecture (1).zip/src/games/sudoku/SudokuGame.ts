/**
 * Sudoku — Classic number placement puzzle.
 *
 * Game-specific responsibilities:
 *   - 9x9 grid management
 *   - Puzzle generation with unique solution
 *   - Constraint validation (row, column, box)
 *   - Difficulty levels
 *   - Pencil marks (candidates)
 *   - Hint system
 */

import type {
  GameModule,
  GameMeta,
  GameState,
  GameResult,
  GameAction,
  GameCapabilities,
} from "@/engine";
import type { EventSystem } from "@/engine";
import { hasUniqueSolution, hasConflict } from "./SudokuValidator";

export type Difficulty = "easy" | "medium" | "hard" | "expert";

export interface SudokuCell {
  value: number;
  given: boolean;
  candidates: Set<number>;
  error: boolean;
}

interface SudokuSave {
  board: (number | 0)[][];
  solution: number[][];
  given: boolean[][];
  difficulty: Difficulty;
  mistakes: number;
  hintsUsed: number;
  score: number;
  moves: number;
  timer: number;
}

export class SudokuGame implements GameModule {
  meta: GameMeta = {
    id: "sudoku",
    name: "Sudoku",
    description:
      "Fill a 9×9 grid so each row, column, and 3×3 box contains 1-9.",
    icon: "🔢",
    category: "logic",
    difficulty: 3,
    estimatedMinutes: 20,
    tags: ["number", "logic", "grid", "puzzle"],
    version: "1.0.0",
  };

  capabilities: GameCapabilities = {
    hint: true,
    actions: ["place", "erase", "toggle-candidate", "hint"],
    tickBased: true, // timer advances via Engine loop
  };

  private board: SudokuCell[][] = [];
  private solution: number[][] = [];
  private given: boolean[][] = [];
  private difficulty: Difficulty = "medium";
  private mistakes = 0;
  private hintsUsed = 0;
  private score = 0;
  private moves = 0;
  private timer = 0;
  private gameOver = false;
  private won = false;
  private events: EventSystem | null = null;
  private maxMistakes = 3;

  /* ─── Lifecycle ─── */

  init(events: EventSystem): void {
    this.events = events;
  }

  start(): void {
    // Preserve current difficulty (only reset if not set)
    if (!this.difficulty) this.difficulty = "medium";
    this.mistakes = 0;
    this.hintsUsed = 0;
    this.score = 0;
    this.moves = 0;
    this.timer = 0;
    this.gameOver = false;
    this.won = false;
    this.generatePuzzle();
  }

  pause(): void {}
  resume(): void {}

  update(deltaMs: number): void {
    if (!this.gameOver && !this.won) {
      this.timer += deltaMs;
    }
  }

  save(): GameState {
    const boardValues = this.board.map((row) =>
      row.map((cell) => cell.value)
    );
    const givenBoard = this.given;
    return {
      board: boardValues,
      solution: this.solution,
      given: givenBoard,
      difficulty: this.difficulty,
      mistakes: this.mistakes,
      hintsUsed: this.hintsUsed,
      score: this.score,
      moves: this.moves,
      timer: this.timer,
    };
  }

  load(state: GameState): void {
    const s = state as unknown as SudokuSave;
    if (s.board && s.solution) {
      this.solution = s.solution;
      this.given = s.given;
      this.difficulty = s.difficulty;
      this.mistakes = s.mistakes;
      this.hintsUsed = s.hintsUsed;
      this.score = s.score;
      this.moves = s.moves;
      this.timer = s.timer;

      this.board = s.board.map((row, r) =>
        row.map((val, c) => ({
          value: val,
          given: s.given[r]?.[c] ?? false,
          candidates: new Set<number>(),
          error: false,
        }))
      );
    }
  }

  destroy(): void {
    this.events = null;
  }

  /* ─── Game Logic ─── */

  /**
   * Place a number in a cell.
   */
  placeNumber(row: number, col: number, value: number): boolean {
    if (this.gameOver || this.won) return false;
    if (row < 0 || row > 8 || col < 0 || col > 8) return false;
    if (this.board[row][col].given) return false;

    this.board[row][col].value = value;
    this.board[row][col].candidates.clear();
    this.moves++;

    // Validate using RULE CONFLICTS (duplicate in row/column/box),
    // not solution comparison. This is the category-standard model:
    // it teaches the rules and allows hypothesis testing.
    if (value !== 0 && hasConflict(this.board, row, col, value)) {
      this.board[row][col].error = true;
      this.mistakes++;
      this.score = Math.max(0, this.score - 10);

      this.events?.emit("sudoku:mistake", {
        row,
        col,
        mistakes: this.mistakes,
      });

      if (this.mistakes >= this.maxMistakes) {
        this.gameOver = true;
        this.events?.emit("sudoku:gameover", { reason: "too_many_mistakes" });
      }
    } else if (value !== 0) {
      this.board[row][col].error = false;
      this.score += 10;
      this.clearCandidateFromPeers(row, col, value);

      // Check win
      if (this.isComplete()) {
        this.won = true;
        this.score += Math.max(0, 1000 - this.mistakes * 50 - this.hintsUsed * 100);
        this.events?.emit("sudoku:win", { score: this.score });
      }
    }

    return true;
  }

  /**
   * Toggle a pencil mark (candidate).
   */
  toggleCandidate(row: number, col: number, num: number): void {
    if (this.gameOver || this.won) return;
    if (row < 0 || row > 8 || col < 0 || col > 8) return;
    if (this.board[row][col].given || this.board[row][col].value !== 0) return;

    const cell = this.board[row][col];
    if (cell.candidates.has(num)) {
      cell.candidates.delete(num);
    } else {
      cell.candidates.add(num);
    }
  }

  /**
   * Erase a cell.
   */
  erase(row: number, col: number): void {
    if (this.gameOver || this.won) return;
    if (this.board[row][col].given) return;
    this.board[row][col].value = 0;
    this.board[row][col].error = false;
    this.board[row][col].candidates.clear();
  }

  /**
   * Get a hint — reveal one correct cell.
   */
  hint(): void {
    if (this.gameOver || this.won) return;

    // Find an empty or wrong cell
    const candidates: [number, number][] = [];
    for (let r = 0; r < 9; r++) {
      for (let c = 0; c < 9; c++) {
        if (!this.given[r][c] && this.board[r][c].value !== this.solution[r][c]) {
          candidates.push([r, c]);
        }
      }
    }

    if (candidates.length === 0) return;

    const [r, c] = candidates[Math.floor(Math.random() * candidates.length)];
    this.board[r][c].value = this.solution[r][c];
    this.board[r][c].error = false;
    this.board[r][c].candidates.clear();
    this.given[r][c] = true;
    this.hintsUsed++;

    this.events?.emit("sudoku:hint", { row: r, col: c });

    if (this.isComplete()) {
      this.won = true;
      this.score += Math.max(0, 1000 - this.mistakes * 50 - this.hintsUsed * 100);
    }
  }

  /**
   * Set difficulty and generate a new puzzle.
   */
  setDifficulty(difficulty: Difficulty): void {
    this.difficulty = difficulty;
    this.start();
  }

  /* ─── Getters ─── */

  getBoard(): SudokuCell[][] {
    return this.board;
  }

  getDifficulty(): Difficulty {
    return this.difficulty;
  }

  getMistakes(): number {
    return this.mistakes;
  }

  getTimer(): number {
    return this.timer;
  }

  getHintsUsed(): number {
    return this.hintsUsed;
  }

  /* ─── GameModule Interface ─── */

  getScore(): number {
    return this.score;
  }

  isGameOver(): boolean {
    return this.gameOver;
  }

  isWon(): boolean {
    return this.won;
  }

  getResult(): GameResult {
    return {
      score: this.score,
      won: this.won,
      timeElapsed: Math.floor(this.timer / 1000),
      moves: this.moves,
      metrics: {
        mistakes: this.mistakes,
        hintsUsed: this.hintsUsed,
        difficulty: ["easy", "medium", "hard", "expert"].indexOf(
          this.difficulty
        ),
      },
    };
  }

  /* ─── Internal: Puzzle Generation ─── */

  private generatePuzzle(): void {
    // Generate a complete valid solution
    this.solution = Array.from({ length: 9 }, () => Array(9).fill(0));
    this.solveSudoku(this.solution);

    // Create puzzle by removing cells
    this.given = Array.from({ length: 9 }, () => Array(9).fill(true));

    const cellsToRemove =
      this.difficulty === "easy"
        ? 35
        : this.difficulty === "medium"
        ? 45
        : this.difficulty === "hard"
        ? 52
        : 56;

    const positions: [number, number][] = [];
    for (let r = 0; r < 9; r++) {
      for (let c = 0; c < 9; c++) {
        positions.push([r, c]);
      }
    }

    // Shuffle
    for (let i = positions.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [positions[i], positions[j]] = [positions[j], positions[i]];
    }

    // Remove cells ONE AT A TIME, verifying uniqueness after each removal.
    // If removing a cell creates multiple solutions, revert it.
    // This guarantees every shipped puzzle has exactly one solution.
    let removed = 0;
    for (const [r, c] of positions) {
      if (removed >= cellsToRemove) break;
      this.given[r][c] = false;

      const givensGrid = this.buildGivensGrid();
      if (!hasUniqueSolution(givensGrid)) {
        this.given[r][c] = true; // revert — would be ambiguous
      } else {
        removed++;
      }
    }

    // Build the board
    this.board = Array.from({ length: 9 }, (_, r) =>
      Array.from({ length: 9 }, (_, c) => ({
        value: this.given[r][c] ? this.solution[r][c] : 0,
        given: this.given[r][c],
        candidates: new Set<number>(),
        error: false,
      }))
    );
  }

  private solveSudoku(board: number[][]): boolean {
    for (let r = 0; r < 9; r++) {
      for (let c = 0; c < 9; c++) {
        if (board[r][c] === 0) {
          const nums = this.shuffle([1, 2, 3, 4, 5, 6, 7, 8, 9]);
          for (const num of nums) {
            if (this.isValidPlacement(board, r, c, num)) {
              board[r][c] = num;
              if (this.solveSudoku(board)) return true;
              board[r][c] = 0;
            }
          }
          return false;
        }
      }
    }
    return true;
  }

  private isValidPlacement(
    board: number[][],
    row: number,
    col: number,
    num: number
  ): boolean {
    // Check row
    for (let c = 0; c < 9; c++) {
      if (board[row][c] === num) return false;
    }

    // Check column
    for (let r = 0; r < 9; r++) {
      if (board[r][col] === num) return false;
    }

    // Check 3x3 box
    const boxR = Math.floor(row / 3) * 3;
    const boxC = Math.floor(col / 3) * 3;
    for (let r = boxR; r < boxR + 3; r++) {
      for (let c = boxC; c < boxC + 3; c++) {
        if (board[r][c] === num) return false;
      }
    }

    return true;
  }

  private isComplete(): boolean {
    for (let r = 0; r < 9; r++) {
      for (let c = 0; c < 9; c++) {
        if (this.board[r][c].value !== this.solution[r][c]) return false;
      }
    }
    return true;
  }

  private clearCandidateFromPeers(
    row: number,
    col: number,
    value: number
  ): void {
    // Clear from same row
    for (let c = 0; c < 9; c++) {
      this.board[row][c].candidates.delete(value);
    }

    // Clear from same column
    for (let r = 0; r < 9; r++) {
      this.board[r][col].candidates.delete(value);
    }

    // Clear from same box
    const boxR = Math.floor(row / 3) * 3;
    const boxC = Math.floor(col / 3) * 3;
    for (let r = boxR; r < boxR + 3; r++) {
      for (let c = boxC; c < boxC + 3; c++) {
        this.board[r][c].candidates.delete(value);
      }
    }
  }

  private shuffle<T>(arr: T[]): T[] {
    const result = [...arr];
    for (let i = result.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [result[i], result[j]] = [result[j], result[i]];
    }
    return result;
  }

  private buildGivensGrid(): number[][] {
    return this.solution.map((row, r) =>
      row.map((v, c) => (this.given[r][c] ? v : 0))
    );
  }

  /* ─── Contract: Engine v2 ─── */

  handleAction(action: GameAction): boolean {
    switch (action.type) {
      case "place":
        return this.placeNumber(
          action.row as number,
          action.col as number,
          action.value as number
        );
      case "erase":
        this.erase(action.row as number, action.col as number);
        return true;
      case "hint":
        this.hint();
        return true;
      default:
        return false;
    }
  }

  /** Prove the current puzzle is fair: exactly one solution. */
  validate(): { valid: boolean; reason?: string } {
    const unique = hasUniqueSolution(this.buildGivensGrid());
    return unique
      ? { valid: true }
      : { valid: false, reason: "Puzzle has multiple solutions" };
  }
}
