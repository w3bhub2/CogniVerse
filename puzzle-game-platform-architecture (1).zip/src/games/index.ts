/**
 * @games — Game Modules
 *
 * Each game implements the GameModule interface from @/engine.
 * The GameRegistry provides lookup and instantiation.
 *
 * To add a new game:
 *   1. Create a new directory under src/games/
 *   2. Implement GameModule interface
 *   3. Register it in GameRegistry.ts
 *   4. Create a React renderer component
 */
export { gameRegistry } from "./GameRegistry";
export { Game2048 } from "./game2048";
export { SudokuGame } from "./sudoku";
export { MinesweeperGame } from "./minesweeper";
