/**
 * Minesweeper — Classic mine-clearing puzzle.
 *
 * Game-specific responsibilities:
 *   - Grid generation with mines
 *   - Flood-fill reveal logic
 *   - Flag/unflag mines
 *   - Win/lose detection
 *   - Difficulty presets
 */

import type {
  GameModule,
  GameMeta,
  GameState,
  GameResult,
  GameAction,
  GameCapabilities,
} from "@/engine";
import type { EventSystem } from "@/engine";

export type MinesweeperDifficulty = "easy" | "medium" | "hard";

export interface MinesweeperCell {
  isMine: boolean;
  isRevealed: boolean;
  isFlagged: boolean;
  adjacentMines: number;
}

interface DifficultyConfig {
  rows: number;
  cols: number;
  mines: number;
}

const DIFFICULTY_CONFIGS: Record<MinesweeperDifficulty, DifficultyConfig> = {
  easy: { rows: 9, cols: 9, mines: 10 },
  medium: { rows: 16, cols: 16, mines: 40 },
  hard: { rows: 16, cols: 30, mines: 99 },
};

export class MinesweeperGame implements GameModule {
  meta: GameMeta = {
    id: "minesweeper",
    name: "Minesweeper",
    description:
      "Reveal all safe cells without triggering any mines. Use numbers as clues.",
    icon: "💣",
    category: "logic",
    difficulty: 2,
    estimatedMinutes: 10,
    tags: ["logic", "grid", "mines", "puzzle"],
    version: "1.0.0",
  };

  capabilities: GameCapabilities = {
    actions: ["reveal", "flag"],
    tickBased: true,
  };

  private board: MinesweeperCell[][] = [];
  private rows = 9;
  private cols = 9;
  private totalMines = 10;
  private difficulty: MinesweeperDifficulty = "easy";
  private flagsPlaced = 0;
  private cellsRevealed = 0;
  private score = 0;
  private moves = 0;
  private timer = 0;
  private gameOver = false;
  private won = false;
  private firstClick = true;
  private events: EventSystem | null = null;

  /* ─── Lifecycle ─── */

  init(events: EventSystem): void {
    this.events = events;
  }

  start(): void {
    this.initBoard();
    this.flagsPlaced = 0;
    this.cellsRevealed = 0;
    this.score = 0;
    this.moves = 0;
    this.timer = 0;
    this.gameOver = false;
    this.won = false;
    this.firstClick = true;
  }

  pause(): void {}
  resume(): void {}

  update(deltaMs: number): void {
    if (!this.gameOver && !this.won) {
      this.timer += deltaMs;
    }
  }

  save(): GameState {
    return {
      board: this.board.map((row) =>
        row.map((cell) => ({
          isMine: cell.isMine,
          isRevealed: cell.isRevealed,
          isFlagged: cell.isFlagged,
          adjacentMines: cell.adjacentMines,
        }))
      ),
      rows: this.rows,
      cols: this.cols,
      totalMines: this.totalMines,
      difficulty: this.difficulty,
      flagsPlaced: this.flagsPlaced,
      cellsRevealed: this.cellsRevealed,
      score: this.score,
      moves: this.moves,
      timer: this.timer,
      firstClick: this.firstClick,
    };
  }

  load(state: GameState): void {
    const s = state as unknown as {
      board: MinesweeperCell[][];
      rows: number;
      cols: number;
      totalMines: number;
      difficulty: MinesweeperDifficulty;
      flagsPlaced: number;
      cellsRevealed: number;
      score: number;
      moves: number;
      timer: number;
      firstClick: boolean;
    };
    this.rows = s.rows;
    this.cols = s.cols;
    this.totalMines = s.totalMines;
    this.difficulty = s.difficulty;
    this.flagsPlaced = s.flagsPlaced;
    this.cellsRevealed = s.cellsRevealed;
    this.score = s.score;
    this.moves = s.moves;
    this.timer = s.timer;
    this.firstClick = s.firstClick;
    this.board = s.board;
  }

  destroy(): void {
    this.events = null;
  }

  /* ─── Game Logic ─── */

  /**
   * Reveal a cell. On first click, places mines ensuring no mine at (row, col).
   */
  reveal(row: number, col: number): void {
    if (this.gameOver || this.won) return;
    if (row < 0 || row >= this.rows || col < 0 || col >= this.cols) return;

    const cell = this.board[row][col];
    if (cell.isRevealed || cell.isFlagged) return;

    if (this.firstClick) {
      this.placeMines(row, col);
      this.firstClick = false;
    }

    this.moves++;

    if (cell.isMine) {
      // Game over — reveal all mines
      cell.isRevealed = true;
      this.gameOver = true;
      this.revealAllMines();
      this.events?.emit("minesweeper:gameover", { row, col });
      return;
    }

    // Flood-fill reveal
    this.floodReveal(row, col);

    // Score: points per cell revealed
    this.score = this.cellsRevealed * 10;

    // Check win
    const totalSafeCells = this.rows * this.cols - this.totalMines;
    if (this.cellsRevealed >= totalSafeCells) {
      this.won = true;
      this.score += Math.max(
        0,
        5000 - Math.floor(this.timer / 1000) * 10 - this.moves * 5
      );
      this.events?.emit("minesweeper:win", { score: this.score });
    }
  }

  /**
   * Toggle flag on a cell.
   */
  toggleFlag(row: number, col: number): void {
    if (this.gameOver || this.won) return;
    if (row < 0 || row >= this.rows || col < 0 || col >= this.cols) return;
    if (this.firstClick) return;

    const cell = this.board[row][col];
    if (cell.isRevealed) return;

    cell.isFlagged = !cell.isFlagged;
    this.flagsPlaced += cell.isFlagged ? 1 : -1;
    this.moves++;
  }

  /**
   * Chord — reveal all neighbors if flags match adjacent count.
   */
  chord(row: number, col: number): void {
    if (this.gameOver || this.won) return;

    const cell = this.board[row][col];
    if (!cell.isRevealed || cell.adjacentMines === 0) return;

    const neighbors = this.getNeighbors(row, col);
    const adjacentFlags = neighbors.filter(
      ([r, c]) => this.board[r][c].isFlagged
    ).length;

    if (adjacentFlags === cell.adjacentMines) {
      for (const [r, c] of neighbors) {
        if (!this.board[r][c].isRevealed && !this.board[r][c].isFlagged) {
          this.reveal(r, c);
        }
      }
    }
  }

  /**
   * Set difficulty and restart.
   */
  setDifficulty(difficulty: MinesweeperDifficulty): void {
    this.difficulty = difficulty;
    const config = DIFFICULTY_CONFIGS[difficulty];
    this.rows = config.rows;
    this.cols = config.cols;
    this.totalMines = config.mines;
    this.start();
  }

  /* ─── Getters ─── */

  getBoard(): MinesweeperCell[][] {
    return this.board;
  }

  getRows(): number {
    return this.rows;
  }

  getCols(): number {
    return this.cols;
  }

  getFlagsPlaced(): number {
    return this.flagsPlaced;
  }

  getTotalMines(): number {
    return this.totalMines;
  }

  getTimer(): number {
    return this.timer;
  }

  getDifficulty(): MinesweeperDifficulty {
    return this.difficulty;
  }

  /* ─── GameModule Interface ─── */

  getScore(): number {
    return this.score;
  }

  isGameOver(): boolean {
    return this.gameOver;
  }

  isWon(): boolean {
    return this.won;
  }

  getResult(): GameResult {
    return {
      score: this.score,
      won: this.won,
      timeElapsed: Math.floor(this.timer / 1000),
      moves: this.moves,
      metrics: {
        mines: this.totalMines,
        flagsPlaced: this.flagsPlaced,
        cellsRevealed: this.cellsRevealed,
      },
    };
  }

  /* ─── Internal ─── */

  private initBoard(): void {
    this.board = Array.from({ length: this.rows }, () =>
      Array.from({ length: this.cols }, () => ({
        isMine: false,
        isRevealed: false,
        isFlagged: false,
        adjacentMines: 0,
      }))
    );
  }

  private placeMines(safeRow: number, safeCol: number): void {
    let placed = 0;
    while (placed < this.totalMines) {
      const r = Math.floor(Math.random() * this.rows);
      const c = Math.floor(Math.random() * this.cols);

      // Don't place mine on safe zone (first click + neighbors)
      if (Math.abs(r - safeRow) <= 1 && Math.abs(c - safeCol) <= 1) continue;
      if (this.board[r][c].isMine) continue;

      this.board[r][c].isMine = true;
      placed++;
    }

    // Calculate adjacent mine counts
    for (let r = 0; r < this.rows; r++) {
      for (let c = 0; c < this.cols; c++) {
        if (this.board[r][c].isMine) continue;
        this.board[r][c].adjacentMines = this.getNeighbors(r, c).filter(
          ([nr, nc]) => this.board[nr][nc].isMine
        ).length;
      }
    }
  }

  private floodReveal(row: number, col: number): void {
    if (row < 0 || row >= this.rows || col < 0 || col >= this.cols) return;

    const cell = this.board[row][col];
    if (cell.isRevealed || cell.isFlagged || cell.isMine) return;

    cell.isRevealed = true;
    this.cellsRevealed++;

    if (cell.adjacentMines === 0) {
      for (const [r, c] of this.getNeighbors(row, col)) {
        this.floodReveal(r, c);
      }
    }
  }

  private revealAllMines(): void {
    for (const row of this.board) {
      for (const cell of row) {
        if (cell.isMine) cell.isRevealed = true;
      }
    }
  }

  private getNeighbors(row: number, col: number): [number, number][] {
    const neighbors: [number, number][] = [];
    for (let dr = -1; dr <= 1; dr++) {
      for (let dc = -1; dc <= 1; dc++) {
        if (dr === 0 && dc === 0) continue;
        const nr = row + dr;
        const nc = col + dc;
        if (nr >= 0 && nr < this.rows && nc >= 0 && nc < this.cols) {
          neighbors.push([nr, nc]);
        }
      }
    }
    return neighbors;
  }
}
