/**
 * GameRegistry — Central registry of all available game modules.
 *
 * Responsibilities:
 *   - Register game modules
 *   - Look up games by ID
 *   - List all available games
 *   - Provide metadata for the game browser
 *
 * Flow:
 *   1. Games are registered at startup
 *   2. Platform queries the registry for the game list
 *   3. Platform retrieves a game module by ID for the engine
 *
 * Future Extension Points:
 *   - Dynamic game loading (code splitting)
 *   - Game version management
 *   - A/B testing game variants
 */

import type { GameModule, GameMeta } from "@/engine";
import { Game2048 } from "./game2048";
import { SudokuGame } from "./sudoku";
import { MinesweeperGame } from "./minesweeper";

class GameRegistryImpl {
  private factories = new Map<string, () => GameModule>();

  constructor() {
    this.registerDefaults();
  }

  /**
   * Register a game with a factory function.
   * Factory is called each time a new instance is needed.
   */
  register(factory: () => GameModule): void {
    // Create a temporary instance to get meta
    const temp = factory();
    this.factories.set(temp.meta.id, factory);
  }

  /**
   * Get a new instance of a game by ID.
   */
  get(id: string): GameModule | null {
    const factory = this.factories.get(id);
    return factory ? factory() : null;
  }

  /**
   * Get metadata for all registered games.
   */
  getAllMeta(): GameMeta[] {
    const metas: GameMeta[] = [];
    for (const factory of this.factories.values()) {
      metas.push(factory().meta);
    }
    return metas;
  }

  /**
   * Get metadata for a single game.
   */
  getMeta(id: string): GameMeta | null {
    const game = this.get(id);
    return game?.meta ?? null;
  }

  /**
   * Get all game IDs.
   */
  getIds(): string[] {
    return Array.from(this.factories.keys());
  }

  /**
   * Get games by category.
   */
  getByCategory(category: GameMeta["category"]): GameMeta[] {
    return this.getAllMeta().filter((m) => m.category === category);
  }

  /**
   * Get the total number of registered games.
   */
  count(): number {
    return this.factories.size;
  }

  /* ─── Private ─── */

  private registerDefaults(): void {
    this.register(() => new Game2048());
    this.register(() => new SudokuGame());
    this.register(() => new MinesweeperGame());
  }
}

/** Singleton game registry. */
export const gameRegistry = new GameRegistryImpl();
