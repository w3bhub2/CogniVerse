/**
 * Game 2048 — Slide tiles to merge and reach 2048.
 *
 * Engine v2 contract:
 *   - `capabilities` declares accepted actions + that it is event-driven.
 *   - `handleAction({type:"move", direction})` is the single input path.
 *   - Tiles carry stable IDs so the renderer can animate real slides
 *     and merge pops instead of re-rendering a static grid.
 */

import type {
  GameModule,
  GameMeta,
  GameState,
  GameResult,
  GameAction,
  GameCapabilities,
} from "@/engine";
import type { EventSystem } from "@/engine";

export interface Tile2048 {
  id: number;
  value: number;
  row: number;
  col: number;
  /** Spawned this move — renderer pops it in. */
  isNew: boolean;
  /** Result of a merge this move — renderer pops it. */
  isMerged: boolean;
}

type Direction = "up" | "down" | "left" | "right";

interface HistoryEntry {
  tiles: Tile2048[];
  score: number;
  nextId: number;
}

const SIZE = 4;

export class Game2048 implements GameModule {
  meta: GameMeta = {
    id: "2048",
    name: "2048",
    description:
      "Slide numbered tiles on a 4×4 grid and combine them to reach 2048.",
    icon: "🔢",
    category: "number",
    difficulty: 2,
    estimatedMinutes: 10,
    tags: ["number", "sliding", "merge", "puzzle"],
    version: "2.0.0",
  };

  capabilities: GameCapabilities = {
    undo: true,
    redo: true,
    hint: true,
    actions: ["move"],
    tickBased: false, // event-driven; Engine skips the rAF loop
  };

  private tiles: Tile2048[] = [];
  private nextId = 1;
  private score = 0;
  private bestScore = 0;
  private moves = 0;
  private won = false;
  private gameOver = false;
  private events: EventSystem | null = null;
  private history: HistoryEntry[] = [];
  private redoStack: HistoryEntry[] = [];

  /* ─── Lifecycle ─── */

  init(events: EventSystem): void {
    this.events = events;
    this.bestScore = this.loadBestScore();
  }

  start(): void {
    this.tiles = [];
    this.nextId = 1;
    this.score = 0;
    this.moves = 0;
    this.won = false;
    this.gameOver = false;
    this.history = [];
    this.redoStack = [];
    this.spawnTile();
    this.spawnTile();
  }

  pause(): void {}
  resume(): void {}
  update(_deltaMs: number): void {}

  save(): GameState {
    return {
      // Grid view kept for compatibility + analytics
      board: this.toGrid(),
      tiles: this.tiles.map(({ id, value, row, col }) => ({ id, value, row, col })),
      nextId: this.nextId,
      score: this.score,
      bestScore: this.bestScore,
      moves: this.moves,
      won: this.won,
      gameOver: this.gameOver,
    };
  }

  load(state: GameState): void {
    const s = state as {
      tiles?: { id: number; value: number; row: number; col: number }[];
      board?: number[][];
      nextId?: number;
      score?: number;
      bestScore?: number;
      moves?: number;
      won?: boolean;
      gameOver?: boolean;
    };

    if (s.tiles && s.tiles.length) {
      this.tiles = s.tiles.map((t) => ({
        ...t,
        isNew: false,
        isMerged: false,
      }));
      this.nextId = s.nextId ?? Math.max(0, ...s.tiles.map((t) => t.id)) + 1;
    } else if (s.board) {
      this.tiles = [];
      this.nextId = 1;
      for (let r = 0; r < SIZE; r++) {
        for (let c = 0; c < SIZE; c++) {
          const v = s.board[r]?.[c] ?? 0;
          if (v) this.tiles.push({ id: this.nextId++, value: v, row: r, col: c, isNew: false, isMerged: false });
        }
      }
    }

    if (typeof s.score === "number") this.score = s.score;
    if (typeof s.bestScore === "number") this.bestScore = s.bestScore;
    if (typeof s.moves === "number") this.moves = s.moves;
    if (typeof s.won === "boolean") this.won = s.won;
    if (typeof s.gameOver === "boolean") this.gameOver = s.gameOver;
  }

  destroy(): void {
    this.events = null;
  }

  /* ─── Engine v2 input ─── */

  handleAction(action: GameAction): boolean {
    if (action.type === "move") {
      return this.move(action.direction as Direction);
    }
    return false;
  }

  /** Tiles for the renderer (stable IDs enable slide/merge animation). */
  getTiles(): Tile2048[] {
    return this.tiles;
  }

  /* ─── Core move logic (tile-identity based) ─── */

  move(direction: Direction): boolean {
    if (this.gameOver) return false;

    this.pushHistory();

    const before = this.fingerprint();
    const moved = this.applyMove(direction);

    if (!moved) {
      this.history.pop();
      return false;
    }

    // Clear merge/new flags from previous move before spawning
    for (const t of this.tiles) {
      t.isNew = false;
      t.isMerged = false;
    }
    // Re-apply merge flags were set during applyMove on new tiles only.
    this.spawnTile();
    this.moves++;

    if (this.fingerprint() === before) {
      // Shouldn't happen since moved=true, but guard.
    }

    this.events?.emit("game2048:move", { direction, score: this.score });

    if (!this.won && this.hasWon()) {
      this.won = true;
      this.events?.emit("game2048:win", { score: this.score });
    }

    if (!this.canMove()) {
      this.gameOver = true;
      this.updateBestScore();
      this.events?.emit("game2048:gameover", { score: this.score });
    }

    this.redoStack = [];
    return true;
  }

  private applyMove(direction: Direction): boolean {
    const horizontal = direction === "left" || direction === "right";
    const reverse = direction === "right" || direction === "down";
    let changed = false;
    const result: Tile2048[] = [];

    for (let line = 0; line < SIZE; line++) {
      // Collect tiles on this line, ordered toward the movement edge
      let lineTiles = this.tiles
        .filter((t) => (horizontal ? t.row === line : t.col === line))
        .sort((a, b) => {
          const pa = horizontal ? a.col : a.row;
          const pb = horizontal ? b.col : b.row;
          return reverse ? pb - pa : pa - pb;
        });

      let slot = 0;
      let i = 0;
      while (i < lineTiles.length) {
        const cur = lineTiles[i];
        const nxt = lineTiles[i + 1];

        if (nxt && nxt.value === cur.value) {
          // Merge cur+nxt into one new tile
          const pos = reverse ? SIZE - 1 - slot : slot;
          const mergedValue = cur.value * 2;
          result.push({
            id: this.nextId++,
            value: mergedValue,
            row: horizontal ? line : pos,
            col: horizontal ? pos : line,
            isNew: false,
            isMerged: true,
          });
          this.score += mergedValue;
          changed = true;
          i += 2;
        } else {
          const pos = reverse ? SIZE - 1 - slot : slot;
          const newRow = horizontal ? line : pos;
          const newCol = horizontal ? pos : line;
          if (cur.row !== newRow || cur.col !== newCol) changed = true;
          result.push({ ...cur, row: newRow, col: newCol });
          i += 1;
        }
        slot++;
      }
    }

    if (changed) this.tiles = result;
    return changed;
  }

  /* ─── Queries ─── */

  getAvailableMoves(): Direction[] {
    const dirs: Direction[] = ["up", "down", "left", "right"];
    return dirs.filter((d) => {
      const prev = this.fingerprint();
      const savedTiles = this.tiles;
      const savedScore = this.score;
      // Simulate without committing
      const test = new Game2048();
      test.tiles = savedTiles.map((t) => ({ ...t }));
      test.nextId = this.nextId;
      test.applyMove(d);
      const changed = test.fingerprint() !== prev;
      void savedScore;
      return changed;
    });
  }

  getScore(): number {
    return this.score;
  }

  isGameOver(): boolean {
    return this.gameOver;
  }

  isWon(): boolean {
    return this.won;
  }

  getResult(): GameResult {
    return {
      score: this.score,
      won: this.won,
      timeElapsed: 0,
      moves: this.moves,
      metrics: { bestScore: this.bestScore, boardMax: this.getBoardMax() },
    };
  }

  /* ─── Undo / redo ─── */

  undo(): boolean {
    if (this.history.length === 0) return false;
    this.redoStack.push(this.snapshot());
    const prev = this.history.pop()!;
    this.restore(prev);
    return true;
  }

  redo(): boolean {
    if (this.redoStack.length === 0) return false;
    this.history.push(this.snapshot());
    const next = this.redoStack.pop()!;
    this.restore(next);
    return true;
  }

  canUndo(): boolean {
    return this.history.length > 0;
  }

  canRedo(): boolean {
    return this.redoStack.length > 0;
  }

  hint(): void {
    const moves = this.getAvailableMoves();
    if (moves.length > 0) {
      this.events?.emit("game2048:hint", { suggestedMove: moves[0] });
    }
  }

  /* ─── Internal helpers ─── */

  private toGrid(): number[][] {
    const grid = Array.from({ length: SIZE }, () => Array(SIZE).fill(0));
    for (const t of this.tiles) grid[t.row][t.col] = t.value;
    return grid;
  }

  private spawnTile(): void {
    const occupied = new Set(this.tiles.map((t) => t.row * SIZE + t.col));
    const empty: [number, number][] = [];
    for (let r = 0; r < SIZE; r++) {
      for (let c = 0; c < SIZE; c++) {
        if (!occupied.has(r * SIZE + c)) empty.push([r, c]);
      }
    }
    if (empty.length === 0) return;
    const [row, col] = empty[Math.floor(Math.random() * empty.length)];
    this.tiles.push({
      id: this.nextId++,
      value: Math.random() < 0.9 ? 2 : 4,
      row,
      col,
      isNew: true,
      isMerged: false,
    });
  }

  private canMove(): boolean {
    if (this.tiles.length < SIZE * SIZE) return true;
    const grid = this.toGrid();
    for (let r = 0; r < SIZE; r++) {
      for (let c = 0; c < SIZE; c++) {
        const v = grid[r][c];
        if (c < SIZE - 1 && v === grid[r][c + 1]) return true;
        if (r < SIZE - 1 && v === grid[r + 1][c]) return true;
      }
    }
    return false;
  }

  private hasWon(): boolean {
    return this.tiles.some((t) => t.value >= 2048);
  }

  private getBoardMax(): number {
    return this.tiles.reduce((m, t) => Math.max(m, t.value), 0);
  }

  private fingerprint(): string {
    return this.tiles
      .slice()
      .sort((a, b) => a.id - b.id)
      .map((t) => `${t.row},${t.col},${t.value}`)
      .join("|");
  }

  private snapshot(): HistoryEntry {
    return {
      tiles: this.tiles.map((t) => ({ ...t })),
      score: this.score,
      nextId: this.nextId,
    };
  }

  private restore(entry: HistoryEntry): void {
    this.tiles = entry.tiles.map((t) => ({ ...t, isNew: false, isMerged: false }));
    this.score = entry.score;
    this.nextId = entry.nextId;
    this.gameOver = false;
    this.won = this.hasWon();
  }

  private pushHistory(): void {
    this.history.push(this.snapshot());
    if (this.history.length > 50) this.history.shift();
  }

  private loadBestScore(): number {
    try {
      const raw = localStorage.getItem("game2048_best");
      return raw ? parseInt(raw, 10) || 0 : 0;
    } catch {
      return 0;
    }
  }

  private updateBestScore(): void {
    if (this.score > this.bestScore) {
      this.bestScore = this.score;
      try {
        localStorage.setItem("game2048_best", String(this.bestScore));
      } catch {
        // Ignore
      }
    }
  }
}
