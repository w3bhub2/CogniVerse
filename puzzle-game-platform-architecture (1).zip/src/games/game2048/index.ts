export { Game2048 } from "./Game2048";
export type { Tile2048 } from "./Game2048";
