/**
 * @engine — Puzzle Platform Game Engine
 *
 * Reusable engine that powers all 50+ games.
 * Games implement the GameModule interface;
 * the Engine orchestrates lifecycle, input, saves, and scoring.
 */
export * from "./core";
