# Engine

Reusable game engine powering all 50+ puzzle games.

## Contents

- `EventSystem.ts` — Publish/subscribe event bus
- `GameModule.ts` — Interface every game implements
- `Engine.ts` — Game loop and lifecycle manager

## Usage

```typescript
import { Engine } from "@/engine";
import { Game2048 } from "@/games";

const engine = new Engine();
await engine.loadGame(new Game2048());
engine.startGame();
```

## Events

The engine emits typed events via the event bus. See `Events` in `EventSystem.ts` for the full list.
