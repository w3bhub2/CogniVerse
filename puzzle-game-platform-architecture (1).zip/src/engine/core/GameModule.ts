/**
 * GameModule — The contract that every game must implement.
 *
 * Responsibilities:
 *   - Define the public API the engine uses to control a game
 *   - Guarantee a consistent lifecycle across all games
 *   - Keep game-specific logic isolated from the platform
 *
 * Flow:
 *   1. Engine calls `init()` to set up the game
 *   2. Engine calls `start()` to begin gameplay
 *   3. Engine calls `update()` on each tick with delta time
 *   4. Engine calls `pause()` / `resume()` for lifecycle events
 *   5. Engine calls `save()` to persist state
 *   6. Engine calls `destroy()` to clean up
 *
 * Future Extension Points:
 *   - Multiplayer hooks (sync state across peers)
 *   - Replay recording (snapshot each update)
 *   - Spectator mode (read-only state access)
 */

import { EventSystem } from "./EventSystem";

/**
 * Serializable game state that can be saved/loaded.
 */
export type GameState = Record<string, unknown>;

/**
 * A discrete player action dispatched through the Engine.
 * Games opt in via `handleAction`. Keeps input handling uniform
 * across games so the Engine — not each renderer — owns the loop.
 */
export interface GameAction {
  type: string;
  [key: string]: unknown;
}

/**
 * Static capability declaration. The platform UI reads this to
 * decide which buttons (undo/hint/etc.) to render.
 */
export interface GameCapabilities {
  undo?: boolean;
  redo?: boolean;
  hint?: boolean;
  /** Action types this game accepts via Engine.dispatch() */
  actions?: string[];
  /** True when the game advances on its own (timers, gravity). */
  tickBased?: boolean;
}

/**
 * Metadata about a game for the platform browser / store.
 */
export interface GameMeta {
  /** Unique identifier (e.g. "2048", "sudoku", "word-search") */
  id: string;
  /** Display name */
  name: string;
  /** One-line description */
  description: string;
  /** Emoji or icon identifier */
  icon: string;
  /** Category for filtering */
  category: GameCategory;
  /** Difficulty rating 1-5 */
  difficulty: number;
  /** Estimated play time in minutes */
  estimatedMinutes: number;
  /** Tags for search */
  tags: string[];
  /** Version string */
  version: string;
}

export type GameCategory =
  | "number"
  | "logic"
  | "word"
  | "visual"
  | "strategy"
  | "memory"
  | "puzzle";

/**
 * Result returned when a game ends.
 */
export interface GameResult {
  /** Final score */
  score: number;
  /** Whether the player won */
  won: boolean;
  /** Time elapsed in seconds */
  timeElapsed: number;
  /** Moves made */
  moves: number;
  /** Additional game-specific metrics */
  metrics?: Record<string, number>;
}

/**
 * The interface every game module must implement.
 * This is the ONLY contract between games and the engine.
 */
export interface GameModule {
  /** Static metadata (no runtime dependency) */
  meta: GameMeta;

  /** Initialize the game. Called once before start. */
  init(eventBus: EventSystem): void | Promise<void>;

  /** Start or restart the game. */
  start(): void;

  /** Pause gameplay. */
  pause(): void;

  /** Resume from pause. */
  resume(): void;

  /** Game tick — called every frame with delta time in ms. */
  update(deltaMs: number): void;

  /**
   * Save the current game state.
   * Must return a JSON-serializable object.
   */
  save(): GameState;

  /**
   * Restore game state from a previous save.
   * Must handle partial/incomplete saves gracefully.
   */
  load(state: GameState): void;

  /** Clean up resources. Called when leaving the game. */
  destroy(): void;

  /**
   * Return the current score.
   * The engine uses this for the score display.
   */
  getScore(): number;

  /**
   * Return whether the game is over.
   */
  isGameOver(): boolean;

  /**
   * Return whether the game is in a won state.
   */
  isWon(): boolean;

  /**
   * Return the current game result (used when game is over).
   */
  getResult(): GameResult;

  /**
   * Handle an undo action if supported.
   * Returns true if undo was performed.
   */
  undo?(): boolean;

  /**
   * Handle a redo action if supported.
   * Returns true if redo was performed.
   */
  redo?(): boolean;

  /**
   * Whether undo is currently available.
   */
  canUndo?(): boolean;

  /**
   * Whether redo is currently available.
   */
  canRedo?(): boolean;

  /**
   * Handle hint if supported.
   */
  hint?(): void;

  /**
   * Handle a dispatched player action.
   * Return true when the action changed game state.
   */
  handleAction?(action: GameAction): boolean;

  /**
   * Static capability declaration for platform UI.
   */
  capabilities?: GameCapabilities;

  /**
   * Validate the current/generated puzzle is fair and solvable.
   * Runs in CI and before a puzzle is presented to the player.
   */
  validate?(): { valid: boolean; reason?: string };
}
