/**
 * EventMiddleware — Interceptor chain for events.
 *
 * Responsibilities:
 *   - Allow cross-cutting concerns (logging, validation, throttling)
 *   - Enable event transformation before delivery
 *   - Support event cancellation
 *   - Rate limiting for high-frequency events
 *
 * Flow:
 *   1. Event is emitted
 *   2. Middleware chain executes in order
 *   3. Any middleware can modify, cancel, or log the event
 *   4. If not cancelled, event reaches listeners
 */

export interface MiddlewareContext {
  eventName: string;
  payload: Record<string, unknown>;
  timestamp: number;
  cancelled: boolean;
  metadata: Record<string, unknown>;
}

export type MiddlewareNext = () => void;

export type MiddlewareFn = (
  ctx: MiddlewareContext,
  next: MiddlewareNext
) => void;

export class EventMiddleware {
  private middlewares: MiddlewareFn[] = [];

  /**
   * Add a middleware to the chain.
   */
  use(middleware: MiddlewareFn): void {
    this.middlewares.push(middleware);
  }

  /**
   * Remove a middleware.
   */
  remove(middleware: MiddlewareFn): void {
    const idx = this.middlewares.indexOf(middleware);
    if (idx >= 0) this.middlewares.splice(idx, 1);
  }

  /**
   * Execute the middleware chain.
   * Returns true if the event was NOT cancelled.
   */
  execute(ctx: MiddlewareContext): boolean {
    let index = 0;

    const next = (): void => {
      if (ctx.cancelled) return;
      if (index < this.middlewares.length) {
        const middleware = this.middlewares[index++];
        middleware(ctx, next);
      }
    };

    next();
    return !ctx.cancelled;
  }

  /**
   * Clear all middlewares.
   */
  clear(): void {
    this.middlewares = [];
  }
}

/* ─── Built-in Middlewares ─── */

/**
 * Logger middleware — logs all events to console in dev mode.
 */
export const loggerMiddleware: MiddlewareFn = (ctx, next) => {
  if (process.env.NODE_ENV === "development") {
    console.log(
      `[Event] ${ctx.eventName}`,
      ctx.payload,
      `(${new Date(ctx.timestamp).toISOString()})`
    );
  }
  next();
};

/**
 * Rate limiter middleware — throttles high-frequency events.
 */
export function createRateLimiter(
  maxPerSecond: number,
  eventFilter?: string[]
): MiddlewareFn {
  const counts = new Map<string, number>();
  const windows = new Map<string, number>();

  return (ctx, next) => {
    if (eventFilter && !eventFilter.includes(ctx.eventName)) {
      next();
      return;
    }

    const now = Date.now();
    const windowKey = ctx.eventName;
    const windowStart = windows.get(windowKey) ?? 0;

    if (now - windowStart > 1000) {
      windows.set(windowKey, now);
      counts.set(windowKey, 1);
      next();
      return;
    }

    const count = counts.get(windowKey) ?? 0;
    if (count >= maxPerSecond) {
      ctx.cancelled = true;
      return;
    }

    counts.set(windowKey, count + 1);
    next();
  };
}

/**
 * Validation middleware — ensures payload has required fields.
 */
export function createValidator(
  requiredFields: string[]
): MiddlewareFn {
  return (ctx, next) => {
    for (const field of requiredFields) {
      if (!(field in ctx.payload)) {
        console.warn(
          `[Validation] Event "${ctx.eventName}" missing required field: ${field}`
        );
        ctx.cancelled = true;
        return;
      }
    }
    next();
  };
}
