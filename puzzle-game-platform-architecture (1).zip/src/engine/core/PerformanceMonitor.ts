/**
 * PerformanceMonitor — Tracks rendering and game loop performance.
 *
 * Responsibilities:
 *   - FPS measurement (rolling average)
 *   - Frame time tracking
 *   - Memory usage (when available)
 *   - Performance warnings
 *   - Stats for analytics
 */

export interface PerformanceStats {
  fps: number;
  avgFrameTime: number;
  maxFrameTime: number;
  frameCount: number;
  memoryUsageMB?: number;
}

export class PerformanceMonitor {
  private frames: number[] = [];
  private lastTime = 0;
  private frameCount = 0;
  private maxFrameTime = 0;
  private sampleSize = 60;
  private warningThreshold = 30; // fps
  private onWarning?: (fps: number) => void;

  setWarningCallback(cb: (fps: number) => void): void {
    this.onWarning = cb;
  }

  /**
   * Call at the start of each frame.
   */
  tick(): void {
    const now = performance.now();

    if (this.lastTime > 0) {
      const delta = now - this.lastTime;
      this.frames.push(delta);
      this.maxFrameTime = Math.max(this.maxFrameTime, delta);

      if (this.frames.length > this.sampleSize) {
        this.frames.shift();
      }

      const fps = this.getFPS();
      if (fps < this.warningThreshold && fps > 0) {
        this.onWarning?.(fps);
      }
    }

    this.lastTime = now;
    this.frameCount++;
  }

  /**
   * Get current FPS (rolling average).
   */
  getFPS(): number {
    if (this.frames.length === 0) return 0;
    const avg = this.frames.reduce((a, b) => a + b, 0) / this.frames.length;
    return avg > 0 ? Math.round(1000 / avg) : 0;
  }

  /**
   * Get average frame time in ms.
   */
  getAvgFrameTime(): number {
    if (this.frames.length === 0) return 0;
    return this.frames.reduce((a, b) => a + b, 0) / this.frames.length;
  }

  /**
   * Get full stats.
   */
  getStats(): PerformanceStats {
    const stats: PerformanceStats = {
      fps: this.getFPS(),
      avgFrameTime: this.getAvgFrameTime(),
      maxFrameTime: this.maxFrameTime,
      frameCount: this.frameCount,
    };

    // Memory usage (Chrome only)
    if (
      typeof performance !== "undefined" &&
      "memory" in performance
    ) {
      const mem = (performance as { memory?: { usedJSHeapSize: number } })
        .memory;
      if (mem) {
        stats.memoryUsageMB = Math.round(mem.usedJSHeapSize / 1024 / 1024);
      }
    }

    return stats;
  }

  /**
   * Reset all counters.
   */
  reset(): void {
    this.frames = [];
    this.lastTime = 0;
    this.frameCount = 0;
    this.maxFrameTime = 0;
  }
}
