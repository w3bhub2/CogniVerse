/**
 * SeededRandom — Deterministic pseudo-random number generator.
 *
 * Uses Mulberry32 algorithm for fast, seedable randomness.
 * Critical for:
 *   - Reproducible puzzle generation
 *   - Replay systems
 *   - Deterministic testing
 *   - Fair multiplayer (shared seed)
 *
 * Flow:
 *   1. Initialize with a seed (number or string hash)
 *   2. Call next() for each random value
 *   3. Same seed always produces same sequence
 */

export class SeededRandom {
  private state: number;

  constructor(seed: number | string) {
    this.state =
      typeof seed === "number"
        ? seed
        : this.hashString(String(seed));
  }

  /**
   * Generate next random float in [0, 1).
   */
  next(): number {
    this.state |= 0;
    this.state = (this.state + 0x6d2b79f5) | 0;
    let t = Math.imul(this.state ^ (this.state >>> 15), 1 | this.state);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  }

  /**
   * Random integer in [min, max] inclusive.
   */
  nextInt(min: number, max: number): number {
    return Math.floor(this.next() * (max - min + 1)) + min;
  }

  /**
   * Random float in [min, max).
   */
  nextFloat(min: number, max: number): number {
    return this.next() * (max - min) + min;
  }

  /**
   * Pick a random element from an array.
   */
  pick<T>(arr: T[]): T {
    return arr[this.nextInt(0, arr.length - 1)];
  }

  /**
   * Shuffle an array in place (Fisher-Yates).
   */
  shuffle<T>(arr: T[]): T[] {
    const result = [...arr];
    for (let i = result.length - 1; i > 0; i--) {
      const j = this.nextInt(0, i);
      [result[i], result[j]] = [result[j], result[i]];
    }
    return result;
  }

  /**
   * Weighted random pick.
   */
  weightedPick<T>(items: T[], weights: number[]): T {
    const total = weights.reduce((a, b) => a + b, 0);
    let r = this.next() * total;
    for (let i = 0; i < items.length; i++) {
      r -= weights[i];
      if (r <= 0) return items[i];
    }
    return items[items.length - 1];
  }

  /**
   * Fork: create a child RNG with a derived seed.
   */
  fork(): SeededRandom {
    return new SeededRandom(this.nextInt(0, 2_147_483_647));
  }

  /**
   * Get current seed state (for serialization/replay).
   */
  getState(): number {
    return this.state;
  }

  /**
   * Restore a previous state.
   */
  setState(state: number): void {
    this.state = state;
  }

  /**
   * Generate a random seed.
   */
  static randomSeed(): number {
    return Math.floor(Math.random() * 2_147_483_647);
  }

  /**
   * Simple string hash (djb2).
   */
  private hashString(str: string): number {
    let hash = 5381;
    for (let i = 0; i < str.length; i++) {
      hash = ((hash << 5) + hash + str.charCodeAt(i)) | 0;
    }
    return hash;
  }
}
