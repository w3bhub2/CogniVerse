/**
 * ReplaySystem — Records and replays game sessions.
 *
 * Responsibilities:
 *   - Record all game inputs with timestamps
 *   - Replay recorded sessions deterministically
 *   - Save/load replay data
 *   - Speed control for replays
 *
 * Flow:
 *   1. Start recording — captures all input events
 *   2. Each input is stored with a timestamp offset
 *   3. Replay plays back inputs at correct timing
 *   4. Replay data can be serialized and shared
 */

export interface ReplayFrame {
  /** Milliseconds offset from recording start */
  time: number;
  /** Event name */
  event: string;
  /** Event payload */
  payload: Record<string, unknown>;
}

export interface ReplayData {
  /** Game identifier */
  gameId: string;
  /** Seed used for deterministic RNG */
  seed: number;
  /** All recorded frames */
  frames: ReplayFrame[];
  /** Total duration in ms */
  duration: number;
  /** Final game state */
  finalState?: Record<string, unknown>;
}

export class ReplaySystem {
  private recording = false;
  private playing = false;
  private frames: ReplayFrame[] = [];
  private startTime = 0;
  private playStartTime = 0;
  private playTimer: ReturnType<typeof setTimeout> | null = null;
  private playIndex = 0;
  private playSpeed = 1;
  private gameId: string;
  private seed: number;
  private onFrame?: (frame: ReplayFrame) => void;
  private onEnd?: () => void;

  constructor(gameId: string, seed: number) {
    this.gameId = gameId;
    this.seed = seed;
  }

  /* ─── Recording ─── */

  startRecording(): void {
    this.recording = true;
    this.frames = [];
    this.startTime = performance.now();
  }

  recordFrame(event: string, payload: Record<string, unknown>): void {
    if (!this.recording) return;
    this.frames.push({
      time: performance.now() - this.startTime,
      event,
      payload,
    });
  }

  stopRecording(): ReplayData {
    this.recording = false;
    return this.getReplayData();
  }

  isRecording(): boolean {
    return this.recording;
  }

  /* ─── Playback ─── */

  startPlayback(
    onFrame: (frame: ReplayFrame) => void,
    onEnd?: () => void
  ): void {
    if (this.frames.length === 0) return;

    this.playing = true;
    this.playStartTime = performance.now();
    this.playIndex = 0;
    this.onFrame = onFrame;
    this.onEnd = onEnd;
    this.scheduleNext();
  }

  stopPlayback(): void {
    this.playing = false;
    if (this.playTimer) {
      clearTimeout(this.playTimer);
      this.playTimer = null;
    }
  }

  setPlaySpeed(speed: number): void {
    this.playSpeed = Math.max(0.25, Math.min(4, speed));
  }

  isPlaying(): boolean {
    return this.playing;
  }

  /* ─── Serialization ─── */

  getReplayData(): ReplayData {
    return {
      gameId: this.gameId,
      seed: this.seed,
      frames: [...this.frames],
      duration:
        this.frames.length > 0
          ? this.frames[this.frames.length - 1].time
          : 0,
    };
  }

  loadReplayData(data: ReplayData): void {
    this.gameId = data.gameId;
    this.seed = data.seed;
    this.frames = [...data.frames];
  }

  serialize(): string {
    return JSON.stringify(this.getReplayData());
  }

  deserialize(json: string): void {
    this.loadReplayData(JSON.parse(json));
  }

  /* ─── Private ─── */

  private scheduleNext(): void {
    if (!this.playing || this.playIndex >= this.frames.length) {
      this.playing = false;
      this.onEnd?.();
      return;
    }

    const frame = this.frames[this.playIndex];
    const nextFrame = this.frames[this.playIndex + 1];

    const delay = nextFrame
      ? (nextFrame.time - frame.time) / this.playSpeed
      : 100;

    this.playTimer = setTimeout(() => {
      this.onFrame?.(frame);
      this.playIndex++;
      this.scheduleNext();
    }, delay);
  }
}
