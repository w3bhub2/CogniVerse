/**
 * Engine v2 — The single source of truth for game lifecycle and state.
 *
 * DESIGN (resolves the v1 "dual control plane" problem):
 *   - The Engine owns the loop. Renderers are pure views that subscribe
 *     to snapshots and forward input via dispatch(). They never run
 *     their own game timers.
 *   - Every state mutation goes through the Engine, which then notifies
 *     subscribers and emits standardized contract events (ARC-002).
 *   - Tick-based games opt in via `capabilities.tickBased`; event-driven
 *     games (2048, Sudoku) skip the rAF loop entirely.
 *
 * Flow:
 *   loadGame → startGame → dispatch(actions) → GAME_END → destroyGame
 *        ↑ saveGame()/loadSave() at any point
 */

import { EventSystem, Events, eventBus } from "./EventSystem";
import type {
  GameModule,
  GameState,
  GameResult,
  GameAction,
} from "./GameModule";
import { EventMiddleware, loggerMiddleware } from "./EventMiddleware";
import { PerformanceMonitor } from "./PerformanceMonitor";

export type EngineState = "idle" | "loaded" | "running" | "paused" | "ended";

/** Immutable-ish view of engine state for subscribers. */
export interface EngineSnapshot {
  state: EngineState;
  gameId: string | null;
  score: number;
  gameOver: boolean;
  won: boolean;
  elapsedMs: number;
  canUndo: boolean;
  canRedo: boolean;
  /** Bumps on every mutation so React re-renders cheaply. */
  version: number;
}

export type EngineListener = (snapshot: EngineSnapshot) => void;

export class Engine {
  private game: GameModule | null = null;
  private state: EngineState = "idle";
  private events: EventSystem;
  private middleware: EventMiddleware;
  private performanceMonitor: PerformanceMonitor;
  private listeners = new Set<EngineListener>();
  private rafId: number | null = null;
  private lastTick = 0;
  private elapsedMs = 0;
  private tickCount = 0;
  private version = 0;

  constructor(events: EventSystem = eventBus) {
    this.events = events;
    this.middleware = new EventMiddleware();
    this.performanceMonitor = new PerformanceMonitor();

    if (process.env.NODE_ENV === "development") {
      this.middleware.use(loggerMiddleware);
    }
  }

  getMiddleware(): EventMiddleware {
    return this.middleware;
  }

  getPerformance(): PerformanceMonitor {
    return this.performanceMonitor;
  }

  /* ─── Subscription ── */

  /**
   * Subscribe to engine state changes. Called immediately with the
   * current snapshot. Returns an unsubscribe function.
   */
  subscribe(listener: EngineListener): () => void {
    this.listeners.add(listener);
    listener(this.getSnapshot());
    return () => {
      this.listeners.delete(listener);
    };
  }

  getSnapshot(): EngineSnapshot {
    return {
      state: this.state,
      gameId: this.game?.meta.id ?? null,
      score: this.game?.getScore() ?? 0,
      gameOver: this.game?.isGameOver() ?? false,
      won: this.game?.isWon() ?? false,
      elapsedMs: this.elapsedMs,
      canUndo: this.game?.canUndo?.() ?? false,
      canRedo: this.game?.canRedo?.() ?? false,
      version: this.version,
    };
  }

  private notify(): void {
    this.version++;
    const snap = this.getSnapshot();
    for (const listener of this.listeners) listener(snap);
  }

  /* ─── Lifecycle ─── */

  async loadGame(game: GameModule): Promise<void> {
    if (this.state !== "idle") {
      await this.destroyGame();
    }

    this.game = game;
    this.state = "loaded";
    this.elapsedMs = 0;
    this.tickCount = 0;

    await game.init(this.events);
    this.events.emit(Events.GAME_LOAD, { gameId: game.meta.id });
    this.notify();
  }

  /** Start, optionally restoring a previous save first. */
  startGame(initialState?: GameState): void {
    if (!this.game || this.state === "running") return;

    if (initialState) this.game.load(initialState);
    this.game.start();
    this.state = "running";
    this.elapsedMs = 0;

    this.events.emit(Events.GAME_START, { gameId: this.game.meta.id });
    this.events.emit(Events.LEVEL_START, {
      gameId: this.game.meta.id,
      difficulty: this.game.meta.difficulty,
    });

    if (this.game.capabilities?.tickBased) {
      this.startLoop();
    }
    this.notify();
  }

  pauseGame(): void {
    if (!this.game || this.state !== "running") return;
    this.game.pause();
    this.state = "paused";
    this.stopLoop();
    this.events.emit(Events.GAME_PAUSE, { gameId: this.game.meta.id });
    this.notify();
  }

  resumeGame(): void {
    if (!this.game || this.state !== "paused") return;
    this.game.resume();
    this.state = "running";
    if (this.game.capabilities?.tickBased) this.startLoop();
    this.events.emit(Events.GAME_RESUME, { gameId: this.game.meta.id });
    this.notify();
  }

  async destroyGame(): Promise<void> {
    this.stopLoop();
    if (this.game) {
      if (this.state === "running") this.game.pause();
      this.game.destroy();
    }
    this.game = null;
    this.state = "idle";
    this.elapsedMs = 0;
    this.tickCount = 0;
    this.notify();
  }

  /* ─── Input ─── */

  /**
   * Forward a player action to the game. The single input path.
   * Returns true when the action changed game state.
   */
  dispatch(action: GameAction): boolean {
    if (!this.game || this.state !== "running") return false;
    if (!this.game.handleAction) return false;

    const ctx = {
      eventName: `dispatch:${action.type}`,
      payload: action as unknown as Record<string, unknown>,
      timestamp: Date.now(),
      cancelled: false,
      metadata: {},
    };
    if (!this.middleware.execute(ctx)) return false;

    const changed = this.game.handleAction(action);
    if (changed) {
      this.events.emit(Events.MOVE_MADE, {
        gameId: this.game.meta.id,
        action: action.type,
      });
      this.afterMutation();
    }
    return changed;
  }

  undo(): boolean {
    if (!this.game?.undo?.()) return false;
    this.events.emit(Events.UNDO_USED, { gameId: this.game.meta.id });
    this.afterMutation();
    return true;
  }

  redo(): boolean {
    if (!this.game?.redo?.()) return false;
    this.afterMutation();
    return true;
  }

  hint(): void {
    if (!this.game?.hint) return;
    this.game.hint();
    this.events.emit(Events.HINT_USED, { gameId: this.game.meta.id });
    this.afterMutation();
  }

  /* ─── Persistence ─── */

  saveGame(): GameState | null {
    if (!this.game) return null;
    const state = this.game.save();
    this.events.emit(Events.SAVE_REQUEST, {
      gameId: this.game.meta.id,
      state,
    });
    return state;
  }

  loadSave(state: GameState): void {
    if (!this.game) return;
    this.game.load(state);
    this.events.emit(Events.LOAD_COMPLETE, { gameId: this.game.meta.id });
    this.notify();
  }

  /* ─── Queries ─── */

  getGame(): GameModule | null {
    return this.game;
  }

  getState(): EngineState {
    return this.state;
  }

  getElapsedMs(): number {
    return this.elapsedMs;
  }

  getResult(): GameResult | null {
    if (!this.game || !this.game.isGameOver()) return null;
    return this.game.getResult();
  }

  /* ─── Internals ─── */

  /** After any state mutation: check game-over, notify views. */
  private afterMutation(): void {
    if (!this.game) return;

    if (this.game.isGameOver()) {
      this.state = "ended";
      this.stopLoop();

      const result = this.game.getResult();
      this.events.emit(Events.GAME_END, {
        gameId: this.game.meta.id,
        result,
      });
      if (result.won) {
        this.events.emit(Events.LEVEL_COMPLETE, {
          gameId: this.game.meta.id,
          result,
        });
      } else {
        this.events.emit(Events.LEVEL_FAIL, {
          gameId: this.game.meta.id,
          result,
        });
      }
    }

    this.notify();
  }

  private startLoop(): void {
    this.stopLoop();
    this.lastTick = performance.now();

    const tick = (now: number) => {
      if (this.state !== "running" || !this.game) return;

      const delta = now - this.lastTick;
      this.lastTick = now;
      // Ignore huge deltas (tab was hidden) so timers stay honest.
      if (delta < 1000) {
        this.elapsedMs += delta;
        this.game.update(delta);
      }
      this.tickCount++;
      this.performanceMonitor.tick();

      this.events.emit(Events.GAME_TICK, {
        delta,
        elapsed: this.elapsedMs,
        tick: this.tickCount,
      });

      if (this.game.isGameOver()) {
        this.afterMutation();
        return;
      }

      this.rafId = requestAnimationFrame(tick);
    };

    this.rafId = requestAnimationFrame(tick);
  }

  private stopLoop(): void {
    if (this.rafId !== null) {
      cancelAnimationFrame(this.rafId);
      this.rafId = null;
    }
  }
}
