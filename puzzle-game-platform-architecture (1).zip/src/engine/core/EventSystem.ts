/**
 * EventSystem — Publish/Subscribe event bus for the entire platform.
 *
 * Responsibilities:
 *   - Decouple game modules from platform services
 *   - Allow cross-system communication without direct imports
 *   - Support typed events for type safety
 *
 * Flow:
 *   1. Publisher emits an event with a name and payload
 *   2. EventSystem fans out to all registered listeners
 *   3. Listeners receive the payload and react accordingly
 *
 * Future Extension Points:
 *   - Event middleware / interceptors
 *   - Event replay / undo
 *   - Remote event sync for cloud saves
 */

export type EventPayload = Record<string, unknown>;

export type Listener<T = EventPayload> = (payload: T) => void;

export interface Unsubscribe {
  (): void;
}

export class EventSystem {
  private listeners = new Map<string, Set<Listener>>();
  private onceListeners = new Map<string, Set<Listener>>();

  /**
   * Subscribe to an event.
   * Returns an unsubscribe function.
   */
  on<T = EventPayload>(event: string, listener: Listener<T>): Unsubscribe {
    if (!this.listeners.has(event)) {
      this.listeners.set(event, new Set());
    }
    this.listeners.get(event)!.add(listener as Listener);

    return () => {
      this.listeners.get(event)?.delete(listener as Listener);
    };
  }

  /**
   * Subscribe to an event, firing only once.
   */
  once<T = EventPayload>(event: string, listener: Listener<T>): Unsubscribe {
    if (!this.onceListeners.has(event)) {
      this.onceListeners.set(event, new Set());
    }
    this.onceListeners.get(event)!.add(listener as Listener);

    return () => {
      this.onceListeners.get(event)?.delete(listener as Listener);
    };
  }

  /**
   * Emit an event to all subscribers.
   */
  emit<T = EventPayload>(event: string, payload?: T): void {
    const regularListeners = this.listeners.get(event);
    if (regularListeners) {
      for (const listener of regularListeners) {
        listener(payload ?? {});
      }
    }

    const onceListeners = this.onceListeners.get(event);
    if (onceListeners && onceListeners.size > 0) {
      for (const listener of onceListeners) {
        listener(payload ?? {});
      }
      this.onceListeners.delete(event);
    }
  }

  /**
   * Remove all listeners for an event, or all events.
   */
  off(event?: string): void {
    if (event) {
      this.listeners.delete(event);
      this.onceListeners.delete(event);
    } else {
      this.listeners.clear();
      this.onceListeners.clear();
    }
  }

  /**
   * Get the count of listeners for an event (for debugging).
   */
  listenerCount(event: string): number {
    return (
      (this.listeners.get(event)?.size ?? 0) +
      (this.onceListeners.get(event)?.size ?? 0)
    );
  }
}

/** Singleton event system shared across the platform. */
export const eventBus = new EventSystem();

/* ─── Well-known event names ─── */

export const Events = {
  // Engine lifecycle
  GAME_LOAD: "engine:game:load",
  GAME_START: "engine:game:start",
  GAME_PAUSE: "engine:game:pause",
  GAME_RESUME: "engine:game:resume",
  GAME_END: "engine:game:end",
  GAME_TICK: "engine:game:tick",
  GAME_ERROR: "engine:game:error",

  // Standardized gameplay events (PLATFORM_CONTRACT ARC-002)
  LEVEL_START: "game:level_start",
  LEVEL_COMPLETE: "game:level_complete",
  LEVEL_FAIL: "game:level_fail",
  MOVE_MADE: "game:move_made",
  HINT_USED: "game:hint_used",
  UNDO_USED: "game:undo_used",

  // Input
  INPUT_TAP: "input:tap",
  INPUT_SWIPE: "input:swipe",
  INPUT_KEY: "input:key",
  INPUT_DRAG: "input:drag",
  INPUT_UNDO: "input:undo",
  INPUT_REDO: "input:redo",

  // Save system
  SAVE_REQUEST: "save:request",
  SAVE_COMPLETE: "save:complete",
  SAVE_ERROR: "save:error",
  LOAD_REQUEST: "load:request",
  LOAD_COMPLETE: "load:complete",

  // Scoring
  SCORE_UPDATE: "score:update",
  SCORE_MILESTONE: "score:milestone",
  BEST_SCORE: "score:best",

  // Achievements
  ACHIEVEMENT_UNLOCKED: "achievement:unlocked",

  // Platform
  THEME_CHANGE: "platform:theme:change",
  SETTINGS_CHANGE: "platform:settings:change",
  AUDIO_TOGGLE: "platform:audio:toggle",
  HAPTICS_TOGGLE: "platform:haptics:toggle",
  LANGUAGE_CHANGE: "platform:language:change",

  // Navigation
  NAVIGATE: "platform:navigate",
  NAV_BACK: "platform:navigate:back",
} as const;
