"use client";

import { useCallback, useRef } from "react";

/**
 * useStableCallback — Returns a stable function reference.
 * Avoids re-renders from callback prop changes.
 */
export function useStableCallback<T extends (...args: unknown[]) => unknown>(
  callback: T
): T {
  const callbackRef = useRef(callback);
  callbackRef.current = callback;

  return useCallback(
    ((...args: unknown[]) => callbackRef.current(...args)) as T,
    []
  );
}

/**
 * useDebouncedCallback — Debounces rapid calls.
 * Useful for save operations that shouldn't fire on every move.
 */
export function useDebouncedCallback<T extends (...args: unknown[]) => unknown>(
  callback: T,
  delayMs: number
): T {
  const timeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const callbackRef = useRef(callback);
  callbackRef.current = callback;

  return useCallback(
    ((...args: unknown[]) => {
      if (timeoutRef.current) clearTimeout(timeoutRef.current);
      timeoutRef.current = setTimeout(() => {
        callbackRef.current(...args);
      }, delayMs);
    }) as T,
    [delayMs]
  );
}

/**
 * useThrottledCallback — Throttles calls to at most once per interval.
 * Useful for analytics events and high-frequency game events.
 */
export function useThrottledCallback<T extends (...args: unknown[]) => unknown>(
  callback: T,
  intervalMs: number
): T {
  const lastCallRef = useRef(0);
  const callbackRef = useRef(callback);
  callbackRef.current = callback;

  return useCallback(
    ((...args: unknown[]) => {
      const now = Date.now();
      if (now - lastCallRef.current >= intervalMs) {
        lastCallRef.current = now;
        callbackRef.current(...args);
      }
    }) as T,
    [intervalMs]
  );
}
