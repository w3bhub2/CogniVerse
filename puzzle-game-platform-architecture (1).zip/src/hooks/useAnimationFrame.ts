"use client";

import { useRef, useCallback, useEffect } from "react";

/**
 * useAnimationFrame — High-performance game loop hook.
 *
 * Uses requestAnimationFrame for smooth 60fps rendering.
 * Automatically pauses when tab is hidden.
 * Provides delta time in milliseconds.
 */
export function useAnimationFrame(
  callback: (deltaMs: number) => void,
  active: boolean = true
) {
  const callbackRef = useRef(callback);
  const frameRef = useRef<number>(0);
  const lastTimeRef = useRef(0);

  // Keep callback ref fresh without re-triggering effect
  useEffect(() => {
    callbackRef.current = callback;
  }, [callback]);

  useEffect(() => {
    if (!active) {
      if (frameRef.current) {
        cancelAnimationFrame(frameRef.current);
        frameRef.current = 0;
      }
      return;
    }

    lastTimeRef.current = performance.now();

    const loop = (now: number) => {
      const delta = now - lastTimeRef.current;
      lastTimeRef.current = now;

      // Skip large deltas (tab was hidden)
      if (delta < 100) {
        callbackRef.current(delta);
      }

      frameRef.current = requestAnimationFrame(loop);
    };

    frameRef.current = requestAnimationFrame(loop);

    return () => {
      if (frameRef.current) {
        cancelAnimationFrame(frameRef.current);
      }
    };
  }, [active]);
}

/**
 * useGameTimer — High-performance timer for game sessions.
 * Uses requestAnimationFrame instead of setInterval for accuracy.
 */
export function useGameTimer(running: boolean): number {
  const timeRef = useRef(0);
  const frameRef = useRef<number>(0);
  const lastRef = useRef(0);
  const [, setTick] = React.useState(0);

  useEffect(() => {
    if (!running) {
      if (frameRef.current) cancelAnimationFrame(frameRef.current);
      return;
    }

    lastRef.current = performance.now();

    const loop = (now: number) => {
      const delta = now - lastRef.current;
      lastRef.current = now;
      timeRef.current += delta;
      setTick((t) => t + 1); // Force re-render every frame
      frameRef.current = requestAnimationFrame(loop);
    };

    frameRef.current = requestAnimationFrame(loop);
    return () => {
      if (frameRef.current) cancelAnimationFrame(frameRef.current);
    };
  }, [running]);

  return timeRef.current;
}

import React from "react";
