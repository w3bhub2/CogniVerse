/**
 * Security utilities for API routes.
 *
 * Responsibilities:
 *   - Input sanitization
 *   - Rate limiting (in-memory sliding window)
 *   - Input validation
 *   - XSS prevention
 *   - Request size limits
 */

/* ─── Rate Limiter ─── */

interface RateLimitEntry {
  count: number;
  resetTime: number;
}

const rateLimitStore = new Map<string, RateLimitEntry>();

/**
 * Check if a request is rate-limited.
 * Returns true if the request should be blocked.
 */
export function isRateLimited(
  key: string,
  maxRequests: number = 100,
  windowMs: number = 60_000
): boolean {
  const now = Date.now();
  const entry = rateLimitStore.get(key);

  if (!entry || now > entry.resetTime) {
    rateLimitStore.set(key, { count: 1, resetTime: now + windowMs });
    return false;
  }

  entry.count++;
  return entry.count > maxRequests;
}

/* ─── Input Sanitization ─── */

/**
 * Sanitize a string to prevent XSS.
 */
export function sanitizeString(input: string): string {
  return input
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#x27;")
    .replace(/\//g, "&#x2F;")
    .slice(0, 1000); // Limit length
}

/**
 * Sanitize a game ID (alphanumeric + hyphens only).
 */
export function sanitizeGameId(input: string): string {
  return input.replace(/[^a-zA-Z0-9-]/g, "").slice(0, 50);
}

/**
 * Validate that a value is a safe JSON-serializable object.
 */
export function isSafeObject(obj: unknown): boolean {
  if (obj === null || obj === undefined) return false;
  if (typeof obj === "string") return obj.length < 10000;
  if (typeof obj === "number" || typeof obj === "boolean") return true;
  if (typeof obj !== "object") return false;
  if (Array.isArray(obj)) {
    return obj.length < 1000 && obj.every(isSafeObject);
  }
  const keys = Object.keys(obj as Record<string, unknown>);
  if (keys.length > 100) return false;
  return true;
}

/**
 * Validate request body size (prevent large payloads).
 */
export function validateBodySize(body: string, maxSize: number = 1_048_576): boolean {
  return Buffer.byteLength(body, "utf-8") <= maxSize;
}

/**
 * Get client IP from request headers.
 */
export function getClientIP(request: Request): string {
  return (
    request.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ??
    request.headers.get("x-real-ip") ??
    "unknown"
  );
}

/**
 * Create a standardized error response.
 */
export function errorResponse(
  message: string,
  status: number = 400
): Response {
  return Response.json(
    { error: message },
    {
      status,
      headers: {
        "Content-Type": "application/json",
        "X-Content-Type-Options": "nosniff",
      },
    }
  );
}

/**
 * Create a standardized success response.
 */
export function successResponse(data: Record<string, unknown>): Response {
  return Response.json(data, {
    headers: {
      "X-Content-Type-Options": "nosniff",
    },
  });
}
