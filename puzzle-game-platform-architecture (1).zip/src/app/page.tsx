import { gameRegistry } from "@/games";
import { GameBrowser } from "@/components/GameBrowser";

export const dynamic = "force-dynamic";

export default function HomePage() {
  const games = gameRegistry.getAllMeta();

  return (
    <main className="min-h-screen">
      <GameBrowser games={games} />
    </main>
  );
}
