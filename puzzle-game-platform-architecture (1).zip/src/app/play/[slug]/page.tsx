import { gameRegistry } from "@/games";
import { GamePlayer } from "@/components/GamePlayer";
import { notFound } from "next/navigation";

interface PageProps {
  params: Promise<{ slug: string }>;
}

export async function generateMetadata({ params }: PageProps) {
  const { slug } = await params;
  const meta = gameRegistry.getMeta(slug);
  if (!meta) return { title: "Game Not Found" };

  return {
    title: `${meta.name} — Puzzle Platform`,
    description: meta.description,
  };
}

export default async function GamePlayPage({ params }: PageProps) {
  const { slug } = await params;
  const meta = gameRegistry.getMeta(slug);
  if (!meta) notFound();

  return (
    <main className="min-h-screen bg-slate-50 dark:bg-slate-900">
      <GamePlayer gameId={slug} />
    </main>
  );
}
