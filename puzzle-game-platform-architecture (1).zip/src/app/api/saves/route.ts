import { db } from "@/db";
import { gameSaves } from "@/db/schema";
import { eq, desc } from "drizzle-orm";
import {
  isRateLimited,
  getClientIP,
  sanitizeGameId,
  isSafeObject,
  errorResponse,
  successResponse,
} from "@/lib/security";

export const dynamic = "force-dynamic";

/**
 * GET /api/saves?gameId=xxx
 * Fetch the latest save for a game.
 */
export async function GET(request: Request) {
  const ip = getClientIP(request);
  if (isRateLimited(`saves:${ip}:get`, 120)) {
    return errorResponse("Rate limit exceeded", 429);
  }

  const { searchParams } = new URL(request.url);
  const gameId = searchParams.get("gameId");

  if (!gameId) {
    return errorResponse("gameId is required");
  }

  const safeGameId = sanitizeGameId(gameId);

  try {
    const results = await db
      .select()
      .from(gameSaves)
      .where(eq(gameSaves.gameId, safeGameId))
      .orderBy(desc(gameSaves.updatedAt))
      .limit(1);

    const save = results[0] ?? null;
    return successResponse({ save });
  } catch {
    return errorResponse("Failed to fetch save", 500);
  }
}

/**
 * POST /api/saves
 * Create or update a game save.
 */
export async function POST(request: Request) {
  const ip = getClientIP(request);
  if (isRateLimited(`saves:${ip}:post`, 60)) {
    return errorResponse("Rate limit exceeded", 429);
  }

  try {
    const body = await request.text();

    // Size check
    if (body.length > 5_000_000) {
      return errorResponse("Payload too large", 413);
    }

    const parsed = JSON.parse(body);
    const { gameId, state, score, moves, timeElapsed, version } = parsed;

    if (!gameId || !state) {
      return errorResponse("gameId and state are required");
    }

    if (!isSafeObject(state)) {
      return errorResponse("Invalid state format");
    }

    const safeGameId = sanitizeGameId(String(gameId));

    // Check for existing save
    const existing = await db
      .select()
      .from(gameSaves)
      .where(eq(gameSaves.gameId, safeGameId))
      .limit(1);

    if (existing[0]) {
      await db
        .update(gameSaves)
        .set({
          state,
          score: typeof score === "number" ? score : 0,
          moves: typeof moves === "number" ? moves : 0,
          timeElapsed: typeof timeElapsed === "number" ? timeElapsed : 0,
          version: typeof version === "string" ? version.slice(0, 20) : "1.0.0",
          updatedAt: new Date(),
        })
        .where(eq(gameSaves.id, existing[0].id));
    } else {
      await db.insert(gameSaves).values({
        gameId: safeGameId,
        state,
        score: typeof score === "number" ? score : 0,
        moves: typeof moves === "number" ? moves : 0,
        timeElapsed: typeof timeElapsed === "number" ? timeElapsed : 0,
        version: typeof version === "string" ? version.slice(0, 20) : "1.0.0",
      });
    }

    return successResponse({ ok: true });
  } catch {
    return errorResponse("Failed to save", 500);
  }
}

/**
 * DELETE /api/saves?gameId=xxx
 */
export async function DELETE(request: Request) {
  const ip = getClientIP(request);
  if (isRateLimited(`saves:${ip}:delete`, 30)) {
    return errorResponse("Rate limit exceeded", 429);
  }

  const { searchParams } = new URL(request.url);
  const gameId = searchParams.get("gameId");

  if (!gameId) {
    return errorResponse("gameId is required");
  }

  const safeGameId = sanitizeGameId(gameId);

  try {
    const { sql } = await import("drizzle-orm");
    await db.execute(
      sql`DELETE FROM game_saves WHERE game_id = ${safeGameId}`
    );
    return successResponse({ ok: true });
  } catch {
    return errorResponse("Failed to delete save", 500);
  }
}
