import { db } from "@/db";
import { analyticsEvents } from "@/db/schema";
import {
  isRateLimited,
  getClientIP,
  errorResponse,
  successResponse,
} from "@/lib/security";

export const dynamic = "force-dynamic";

/**
 * POST /api/analytics
 * Receive batched analytics events.
 */
export async function POST(request: Request) {
  const ip = getClientIP(request);
  if (isRateLimited(`analytics:${ip}`, 30, 60_000)) {
    return errorResponse("Rate limit exceeded", 429);
  }

  try {
    const body = await request.text();

    if (body.length > 1_000_000) {
      return errorResponse("Payload too large", 413);
    }

    const parsed = JSON.parse(body);
    const { events } = parsed;

    if (!Array.isArray(events) || events.length === 0) {
      return errorResponse("events array is required");
    }

    // Limit batch size
    const limitedEvents = events.slice(0, 100);

    const batchSize = 50;
    for (let i = 0; i < limitedEvents.length; i += batchSize) {
      const batch = limitedEvents
        .slice(i, i + batchSize)
        .map(
          (e: {
            name?: string;
            properties?: Record<string, unknown>;
            sessionId?: string;
            timestamp?: number;
          }) => ({
            name: String(e.name ?? "unknown").slice(0, 100),
            properties:
              e.properties && typeof e.properties === "object"
                ? e.properties
                : {},
            sessionId: e.sessionId ? String(e.sessionId).slice(0, 50) : null,
            timestamp: typeof e.timestamp === "number" ? e.timestamp : Date.now(),
          })
        );

      await db.insert(analyticsEvents).values(batch);
    }

    return successResponse({ ok: true, received: limitedEvents.length });
  } catch {
    return errorResponse("Failed to store analytics", 500);
  }
}
