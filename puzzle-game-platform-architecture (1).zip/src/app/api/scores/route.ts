import { db } from "@/db";
import { gameScores } from "@/db/schema";
import { eq, desc } from "drizzle-orm";
import {
  isRateLimited,
  getClientIP,
  sanitizeGameId,
  errorResponse,
  successResponse,
} from "@/lib/security";

export const dynamic = "force-dynamic";

/**
 * GET /api/scores?gameId=xxx&limit=10
 * Fetch top scores for a game.
 */
export async function GET(request: Request) {
  const ip = getClientIP(request);
  if (isRateLimited(`scores:${ip}:get`, 120)) {
    return errorResponse("Rate limit exceeded", 429);
  }

  const { searchParams } = new URL(request.url);
  const gameId = searchParams.get("gameId");
  const limit = Math.min(
    Math.max(parseInt(searchParams.get("limit") ?? "10"), 1),
    100
  );

  if (!gameId) {
    return errorResponse("gameId is required");
  }

  const safeGameId = sanitizeGameId(gameId);

  try {
    const scores = await db
      .select()
      .from(gameScores)
      .where(eq(gameScores.gameId, safeGameId))
      .orderBy(desc(gameScores.score))
      .limit(limit);

    return successResponse({ scores });
  } catch {
    return errorResponse("Failed to fetch scores", 500);
  }
}

/**
 * POST /api/scores
 * Submit a new score.
 */
export async function POST(request: Request) {
  const ip = getClientIP(request);
  if (isRateLimited(`scores:${ip}:post`, 30)) {
    return errorResponse("Rate limit exceeded", 429);
  }

  try {
    const body = await request.text();

    if (body.length > 10_000) {
      return errorResponse("Payload too large", 413);
    }

    const parsed = JSON.parse(body);
    const { gameId, score, won, moves, timeElapsed, metrics } = parsed;

    if (!gameId || typeof score !== "number") {
      return errorResponse("gameId and score are required");
    }

    // Validate score is reasonable
    if (score < 0 || score > 999_999_999) {
      return errorResponse("Invalid score value");
    }

    const safeGameId = sanitizeGameId(String(gameId));

    await db.insert(gameScores).values({
      gameId: safeGameId,
      score: Math.floor(score),
      won: typeof won === "boolean" ? won : false,
      moves: typeof moves === "number" ? Math.max(0, Math.floor(moves)) : 0,
      timeElapsed: typeof timeElapsed === "number" ? Math.max(0, Math.floor(timeElapsed)) : 0,
      metrics: metrics && typeof metrics === "object" ? metrics : null,
    });

    return successResponse({ ok: true });
  } catch {
    return errorResponse("Failed to submit score", 500);
  }
}
