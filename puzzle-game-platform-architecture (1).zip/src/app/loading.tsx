/**
 * Root loading state — shown while the main page is loading.
 * Uses skeleton screens for a polished feel.
 */
export default function Loading() {
  return (
    <main className="min-h-screen bg-[var(--color-background)]">
      {/* Hero skeleton */}
      <div className="h-[40vh] bg-gradient-to-br from-indigo-600 to-purple-600 animate-pulse">
        <div className="max-w-6xl mx-auto px-4 pt-16 text-center">
          <div className="h-4 w-32 bg-white/20 rounded-full mx-auto mb-4" />
          <div className="h-12 w-80 bg-white/20 rounded-xl mx-auto mb-3" />
          <div className="h-6 w-64 bg-white/15 rounded-lg mx-auto" />
        </div>
      </div>

      {/* Search skeleton */}
      <div className="max-w-6xl mx-auto px-4 py-6">
        <div className="h-12 bg-[var(--color-surface)] rounded-2xl mb-4 shimmer" />
        <div className="flex gap-2 mb-8">
          {[1, 2, 3, 4, 5].map((i) => (
            <div key={i} className="h-9 w-24 bg-[var(--color-surface)] rounded-full shimmer" />
          ))}
        </div>

        {/* Card grid skeleton */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1, 2, 3].map((i) => (
            <div key={i} className="bg-[var(--color-surface)] rounded-2xl p-6 border border-[var(--color-border)]">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-[var(--color-surface-hover)] rounded-xl shimmer" />
                <div className="flex-1">
                  <div className="h-5 w-32 bg-[var(--color-surface-hover)] rounded-md mb-2 shimmer" />
                  <div className="h-4 w-full bg-[var(--color-surface-hover)] rounded-md shimmer" />
                </div>
              </div>
              <div className="flex gap-2 mt-4">
                <div className="h-6 w-16 bg-[var(--color-surface-hover)] rounded-lg shimmer" />
                <div className="h-6 w-20 bg-[var(--color-surface-hover)] rounded-lg shimmer" />
              </div>
            </div>
          ))}
        </div>
      </div>
    </main>
  );
}
