"use client";

import { useEffect } from "react";

/**
 * Route-level error boundary — catches errors within any route segment.
 * Replaces the default Next.js error page with a branded experience.
 */
export default function ErrorPage({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  useEffect(() => {
    console.error("[Route Error]", error);
  }, [error]);

  return (
    <main className="min-h-screen flex items-center justify-center bg-[var(--color-background)] px-4">
      <div className="text-center max-w-md">
        <div className="text-6xl mb-6">💥</div>
        <h1 className="text-2xl font-bold text-[var(--color-text)] mb-2">
          Something Broke
        </h1>
        <p className="text-[var(--color-text-muted)] mb-2">
          An unexpected error interrupted your game. Don&apos;t worry — your data is safe.
        </p>
        {error.digest && (
          <p className="text-xs text-[var(--color-text-muted)] mb-6 font-mono bg-[var(--color-surface)] px-3 py-2 rounded-lg">
            Error ID: {error.digest}
          </p>
        )}
        <div className="flex flex-col sm:flex-row gap-3 justify-center">
          <button
            onClick={reset}
            className="inline-flex items-center justify-center gap-2 px-6 py-3 rounded-xl bg-[var(--color-primary)] text-white font-semibold hover:opacity-90 transition-opacity"
          >
            🔄 Try Again
          </button>
          <a
            href="/"
            className="inline-flex items-center justify-center gap-2 px-6 py-3 rounded-xl border border-[var(--color-border)] text-[var(--color-text-secondary)] font-medium hover:bg-[var(--color-surface-hover)] transition-colors"
          >
            🏠 Go Home
          </a>
        </div>
      </div>
    </main>
  );
}
