import Link from "next/link";

/**
 * Custom 404 page — matches the Puzzle Platform design system.
 * Not a generic Next.js default. Branded, helpful, and fast.
 */
export default function NotFound() {
  return (
    <main className="min-h-screen flex items-center justify-center bg-[var(--color-background)] px-4">
      <div className="text-center max-w-md">
        <div className="relative mb-8">
          <span className="text-8xl block animate-float">🧩</span>
          <span className="absolute -top-2 -right-2 text-4xl animate-spin-slow">✨</span>
        </div>

        <h1 className="text-6xl font-black text-[var(--color-text)] mb-2 tracking-tighter">
          404
        </h1>
        <h2 className="text-xl font-semibold text-[var(--color-text-secondary)] mb-4">
          Piece Missing
        </h2>
        <p className="text-[var(--color-text-muted)] mb-8 leading-relaxed">
          This puzzle piece doesn&apos;t exist yet. Maybe it&apos;s in a future update, or you took a wrong turn.
        </p>

        <div className="flex flex-col sm:flex-row gap-3 justify-center">
          <Link
            href="/"
            className="inline-flex items-center justify-center gap-2 px-6 py-3 rounded-xl bg-[var(--color-primary)] text-white font-semibold hover:opacity-90 transition-opacity"
          >
            🏠 Back to Games
          </Link>
          <Link
            href="/stats"
            className="inline-flex items-center justify-center gap-2 px-6 py-3 rounded-xl border border-[var(--color-border)] text-[var(--color-text-secondary)] font-medium hover:bg-[var(--color-surface-hover)] transition-colors"
          >
            📊 Your Stats
          </Link>
        </div>
      </div>
    </main>
  );
}
