import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import { ClientProviders } from "@/components/ClientProviders";
import "./globals.css";

export const metadata: Metadata = {
  title: {
    default: "Puzzle Platform — Premium Puzzle Games",
    template: "%s — Puzzle Platform",
  },
  description:
    "Challenge your brain with 50+ premium casual puzzle games. 2048, Sudoku, Minesweeper and more — all powered by one lightning-fast engine.",
  manifest: "/manifest.json",
  keywords: ["puzzle", "games", "2048", "sudoku", "minesweeper", "brain", "casual", "free"],
  authors: [{ name: "Puzzle Platform Studio" }],
  creator: "Puzzle Platform Studio",
  appleWebApp: {
    capable: true,
    statusBarStyle: "black-translucent",
    title: "Puzzle Platform",
  },
  openGraph: {
    type: "website",
    locale: "en_US",
    url: "https://puzzle-platform.app",
    siteName: "Puzzle Platform",
    title: "Puzzle Platform — 50+ Premium Puzzle Games",
    description: "Challenge your brain with 50+ premium casual puzzle games. Free to play.",
    images: [
      {
        url: "/images/og-image.png",
        width: 1200,
        height: 630,
        alt: "Puzzle Platform — Premium Puzzle Games",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "Puzzle Platform — 50+ Premium Puzzle Games",
    description: "Challenge your brain with 50+ premium casual puzzle games.",
    images: ["/images/og-image.png"],
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      "max-video-preview": -1,
      "max-image-preview": "large",
      "max-snippet": -1,
    },
  },
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
  userScalable: false,
  themeColor: "#6366f1",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <link rel="icon" href="/icons/icon-192.png" sizes="192x192" />
        <link rel="apple-touch-icon" href="/icons/icon-192.png" />
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />
        <meta name="theme-color" content="#6366f1" />
      </head>
      <body className="bg-[var(--color-background,#f8fafc)] text-[var(--color-text,#0f172a)] antialiased min-h-screen">
        <ClientProviders>{children}</ClientProviders>
      </body>
    </html>
  );
}
