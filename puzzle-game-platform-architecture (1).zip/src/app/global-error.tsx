"use client";

import { useEffect } from "react";

/**
 * Global error boundary — catches errors in the root layout.
 * Must include its own <html> and <body> tags.
 */
export default function GlobalError({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  useEffect(() => {
    console.error("[Global Error]", error);
  }, [error]);

  return (
    <html lang="en">
      <body className="bg-[#0f172a] text-[#f1f5f9] antialiased min-h-screen flex items-center justify-center px-4">
        <div className="text-center max-w-md">
          <div className="text-6xl mb-6">⚠️</div>
          <h1 className="text-2xl font-bold mb-2">
            Critical Error
          </h1>
          <p className="text-[#94a3b8] mb-6">
            The application encountered a critical error and needs to reload.
            Your game progress has been saved.
          </p>
          <button
            onClick={reset}
            className="inline-flex items-center justify-center gap-2 px-6 py-3 rounded-xl bg-indigo-600 text-white font-semibold hover:bg-indigo-700 transition-colors"
          >
            🔄 Reload Application
          </button>
        </div>
      </body>
    </html>
  );
}
