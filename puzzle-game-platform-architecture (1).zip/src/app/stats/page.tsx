"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { Button, Card } from "@/components/ui";

interface Stats {
  gamesPlayed: number;
  gamesWon: number;
  winStreak: number;
  bestWinStreak: number;
  highestScore: number;
}

interface Achievement {
  id: string;
  name: string;
  description: string;
  icon: string;
  unlockedAt?: number;
}

export default function StatsPage() {
  const [stats, setStats] = useState<Stats>({
    gamesPlayed: 0,
    gamesWon: 0,
    winStreak: 0,
    bestWinStreak: 0,
    highestScore: 0,
  });
  const [achievements, setAchievements] = useState<Achievement[]>([]);

  useEffect(() => {
    // Load stats from localStorage
    try {
      const raw = localStorage.getItem("puzzle_platform_stats");
      if (raw) setStats(JSON.parse(raw));
    } catch { /* ignore */ }

    // Load achievements
    try {
      const raw = localStorage.getItem("puzzle_platform_achievements");
      if (raw) setAchievements(JSON.parse(raw));
    } catch { /* ignore */ }
  }, []);

  const winRate =
    stats.gamesPlayed > 0
      ? Math.round((stats.gamesWon / stats.gamesPlayed) * 100)
      : 0;

  const unlockedAchievements = achievements.filter((a) => a.unlockedAt);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-indigo-50 dark:from-slate-900 dark:via-slate-900 dark:to-indigo-950">
      <header className="sticky top-0 z-30 bg-white/80 dark:bg-slate-900/80 backdrop-blur-lg border-b border-slate-200 dark:border-slate-800">
        <div className="max-w-4xl mx-auto px-4 py-3 flex items-center gap-3">
          <Link href="/">
            <Button variant="ghost" size="sm">
              ← Back
            </Button>
          </Link>
          <h1 className="text-lg font-semibold text-slate-900 dark:text-white">
            📊 Statistics
          </h1>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-4 py-8">
        {/* Stats Cards */}
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 mb-8">
          <Card className="p-4 text-center">
            <p className="text-3xl font-bold text-indigo-600">{stats.gamesPlayed}</p>
            <p className="text-sm text-slate-500 mt-1">Games Played</p>
          </Card>
          <Card className="p-4 text-center">
            <p className="text-3xl font-bold text-green-600">{stats.gamesWon}</p>
            <p className="text-sm text-slate-500 mt-1">Games Won</p>
          </Card>
          <Card className="p-4 text-center">
            <p className="text-3xl font-bold text-amber-600">{winRate}%</p>
            <p className="text-sm text-slate-500 mt-1">Win Rate</p>
          </Card>
          <Card className="p-4 text-center">
            <p className="text-3xl font-bold text-orange-600">{stats.bestWinStreak}</p>
            <p className="text-sm text-slate-500 mt-1">Best Streak</p>
          </Card>
          <Card className="p-4 text-center">
            <p className="text-3xl font-bold text-purple-600">
              {stats.highestScore.toLocaleString()}
            </p>
            <p className="text-sm text-slate-500 mt-1">Highest Score</p>
          </Card>
          <Card className="p-4 text-center">
            <p className="text-3xl font-bold text-red-600">{stats.winStreak}</p>
            <p className="text-sm text-slate-500 mt-1">Current Streak</p>
          </Card>
        </div>

        {/* Achievements */}
        <div>
          <h2 className="text-xl font-semibold text-slate-900 dark:text-white mb-4">
            🏆 Achievements ({unlockedAchievements.length}/{achievements.length})
          </h2>
          {achievements.length === 0 ? (
            <Card className="p-8 text-center">
              <p className="text-4xl mb-2">🎮</p>
              <p className="text-slate-500">
                Play some games to earn achievements!
              </p>
            </Card>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {achievements.map((a) => (
                <Card
                  key={a.id}
                  className={`p-4 flex items-center gap-3 ${
                    !a.unlockedAt ? "opacity-50 grayscale" : ""
                  }`}
                >
                  <div className="text-3xl">{a.icon}</div>
                  <div className="flex-1 min-w-0">
                    <p className="font-semibold text-slate-900 dark:text-white">
                      {a.name}
                    </p>
                    <p className="text-sm text-slate-500">{a.description}</p>
                  </div>
                  {a.unlockedAt && (
                    <span className="text-xs text-green-600 font-medium whitespace-nowrap">
                      ✓ Unlocked
                    </span>
                  )}
                </Card>
              ))}
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
