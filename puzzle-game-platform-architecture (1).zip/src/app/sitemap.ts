import type { MetadataRoute } from "next";
import { gameRegistry } from "@/games";

const BASE_URL = "https://puzzle-platform.app";

export default function sitemap(): MetadataRoute.Sitemap {
  const staticPages = [
    {
      url: BASE_URL,
      lastModified: new Date(),
      changeFrequency: "weekly" as const,
      priority: 1,
    },
  ];

  const gamePages = gameRegistry.getIds().map((id) => ({
    url: `${BASE_URL}/play/${id}`,
    lastModified: new Date(),
    changeFrequency: "weekly" as const,
    priority: 0.9,
  }));

  return [...staticPages, ...gamePages];
}
