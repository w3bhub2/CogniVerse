import { describe, it, expect, vi } from "vitest";
import { Engine, EventSystem, Events } from "@/engine";
import type { GameModule, GameMeta, GameState, GameResult } from "@/engine";

function mockGame(overrides?: Partial<GameModule>): GameModule {
  const meta: GameMeta = {
    id: "mock",
    name: "Mock",
    description: "test",
    icon: "🎮",
    category: "puzzle",
    difficulty: 1,
    estimatedMinutes: 1,
    tags: [],
    version: "1.0.0",
  };
  let score = 0;
  let over = false;
  let won = false;
  return {
    meta,
    init: vi.fn(),
    start: vi.fn(),
    pause: vi.fn(),
    resume: vi.fn(),
    update: vi.fn(),
    save: vi.fn((): GameState => ({ score })),
    load: vi.fn(),
    destroy: vi.fn(),
    getScore: () => score,
    isGameOver: () => over,
    isWon: () => won,
    getResult: (): GameResult => ({ score, won, timeElapsed: 0, moves: 0 }),
    handleAction: vi.fn((action) => {
      if (action.type === "score") {
        score = action.value as number;
        return true;
      }
      if (action.type === "win") {
        won = true;
        over = true;
        return true;
      }
      if (action.type === "lose") {
        over = true;
        return true;
      }
      return false;
    }),
    capabilities: { actions: ["score", "win", "lose"], tickBased: false },
    ...overrides,
  };
}

describe("Engine v2", () => {
  it("subscribe delivers immediate snapshot and updates on mutation", async () => {
    const engine = new Engine(new EventSystem());
    const game = mockGame();
    await engine.loadGame(game);
    engine.startGame();

    const snapshots: number[] = [];
    engine.subscribe((s) => snapshots.push(s.version));

    expect(snapshots.length).toBe(1); // immediate
    engine.dispatch({ type: "score", value: 42 });
    expect(snapshots.length).toBe(2);
    expect(engine.getSnapshot().score).toBe(42);
  });

  it("dispatch returns false when the action changes nothing", async () => {
    const engine = new Engine(new EventSystem());
    const game = mockGame();
    await engine.loadGame(game);
    engine.startGame();
    expect(engine.dispatch({ type: "noop" })).toBe(false);
  });

  it("emits MOVE_MADE on a successful action", async () => {
    const events = new EventSystem();
    const engine = new Engine(events);
    const seen = vi.fn();
    events.on(Events.MOVE_MADE, seen);

    const game = mockGame();
    await engine.loadGame(game);
    engine.startGame();
    engine.dispatch({ type: "score", value: 10 });

    expect(seen).toHaveBeenCalledWith(
      expect.objectContaining({ gameId: "mock", action: "score" })
    );
  });

  it("emits LEVEL_COMPLETE and GAME_END on a win", async () => {
    const events = new EventSystem();
    const engine = new Engine(events);
    const complete = vi.fn();
    const end = vi.fn();
    events.on(Events.LEVEL_COMPLETE, complete);
    events.on(Events.GAME_END, end);

    const game = mockGame();
    await engine.loadGame(game);
    engine.startGame();
    engine.dispatch({ type: "win" });

    expect(engine.getState()).toBe("ended");
    expect(complete).toHaveBeenCalled();
    expect(end).toHaveBeenCalled();
  });

  it("emits LEVEL_FAIL on a loss", async () => {
    const events = new EventSystem();
    const engine = new Engine(events);
    const fail = vi.fn();
    events.on(Events.LEVEL_FAIL, fail);

    const game = mockGame();
    await engine.loadGame(game);
    engine.startGame();
    engine.dispatch({ type: "lose" });

    expect(fail).toHaveBeenCalled();
  });

  it("does not dispatch when paused", async () => {
    const engine = new Engine(new EventSystem());
    const game = mockGame();
    await engine.loadGame(game);
    engine.startGame();
    engine.pauseGame();
    expect(engine.dispatch({ type: "score", value: 5 })).toBe(false);
  });

  it("undo emits UNDO_USED and notifies", async () => {
    const events = new EventSystem();
    const engine = new Engine(events);
    const undoEvt = vi.fn();
    events.on(Events.UNDO_USED, undoEvt);

    const game = mockGame({
      undo: () => true,
      canUndo: () => true,
    });
    await engine.loadGame(game);
    engine.startGame();
    expect(engine.undo()).toBe(true);
    expect(undoEvt).toHaveBeenCalled();
  });

  it("skips the rAF loop for event-driven games", async () => {
    const engine = new Engine(new EventSystem());
    const game = mockGame(); // tickBased: false
    await engine.loadGame(game);
    engine.startGame();
    // update should never be called for non-tick games
    expect(game.update).not.toHaveBeenCalled();
  });
});
