import { describe, it, expect, vi } from "vitest";
import {
  EventMiddleware,
  loggerMiddleware,
  createRateLimiter,
  createValidator,
} from "@/engine";

describe("EventMiddleware", () => {
  it("should execute middleware in order", () => {
    const mw = new EventMiddleware();
    const order: number[] = [];

    mw.use((_ctx, next) => {
      order.push(1);
      next();
    });
    mw.use((_ctx, next) => {
      order.push(2);
      next();
    });

    const result = mw.execute({
      eventName: "test",
      payload: {},
      timestamp: Date.now(),
      cancelled: false,
      metadata: {},
    });

    expect(order).toEqual([1, 2]);
    expect(result).toBe(true);
  });

  it("should cancel event when middleware sets cancelled", () => {
    const mw = new EventMiddleware();

    mw.use((ctx, _next) => {
      ctx.cancelled = true;
    });

    const result = mw.execute({
      eventName: "test",
      payload: {},
      timestamp: Date.now(),
      cancelled: false,
      metadata: {},
    });

    expect(result).toBe(false);
  });

  it("should stop chain when cancelled", () => {
    const mw = new EventMiddleware();
    const handler = vi.fn();

    mw.use((ctx, _next) => {
      ctx.cancelled = true;
    });
    mw.use(handler);

    mw.execute({
      eventName: "test",
      payload: {},
      timestamp: Date.now(),
      cancelled: false,
      metadata: {},
    });

    expect(handler).not.toHaveBeenCalled();
  });

  it("should clear all middleware", () => {
    const mw = new EventMiddleware();
    const handler = vi.fn();

    mw.use(handler);
    mw.clear();

    mw.execute({
      eventName: "test",
      payload: {},
      timestamp: Date.now(),
      cancelled: false,
      metadata: {},
    });

    expect(handler).not.toHaveBeenCalled();
  });

  it("should remove specific middleware", () => {
    const mw = new EventMiddleware();
    const handler1 = vi.fn();
    const handler2 = vi.fn();

    mw.use(handler1);
    mw.use(handler2);
    mw.remove(handler1);

    mw.execute({
      eventName: "test",
      payload: {},
      timestamp: Date.now(),
      cancelled: false,
      metadata: {},
    });

    expect(handler1).not.toHaveBeenCalled();
    expect(handler2).toHaveBeenCalled();
  });
});

describe("createRateLimiter", () => {
  it("should allow requests under the limit", () => {
    const limiter = createRateLimiter(5);
    const ctx = {
      eventName: "test",
      payload: {},
      timestamp: Date.now(),
      cancelled: false,
      metadata: {},
    };

    for (let i = 0; i < 5; i++) {
      const result = limiter({ ...ctx }, () => {});
      expect(result).toBeUndefined(); // next() is called
    }
  });

  it("should cancel when over the limit", () => {
    const limiter = createRateLimiter(2);
    const ctx = {
      eventName: "test",
      payload: {},
      timestamp: Date.now(),
      cancelled: false,
      metadata: {},
    };

    limiter(ctx, () => {});
    limiter(ctx, () => {});
    limiter(ctx, () => {}); // This should cancel

    expect(ctx.cancelled).toBe(true);
  });
});

describe("createValidator", () => {
  it("should pass when required fields are present", () => {
    const validator = createValidator(["gameId", "score"]);
    const ctx = {
      eventName: "test",
      payload: { gameId: "2048", score: 100 },
      timestamp: Date.now(),
      cancelled: false,
      metadata: {},
    };

    const next = vi.fn();
    validator(ctx, next);

    expect(next).toHaveBeenCalled();
    expect(ctx.cancelled).toBe(false);
  });

  it("should cancel when required fields are missing", () => {
    const validator = createValidator(["gameId", "score"]);
    const ctx = {
      eventName: "test",
      payload: { gameId: "2048" },
      timestamp: Date.now(),
      cancelled: false,
      metadata: {},
    };

    const next = vi.fn();
    validator(ctx, next);

    expect(next).not.toHaveBeenCalled();
    expect(ctx.cancelled).toBe(true);
  });
});

describe("loggerMiddleware", () => {
  it("should call next", () => {
    const next = vi.fn();
    const ctx = {
      eventName: "test",
      payload: {},
      timestamp: Date.now(),
      cancelled: false,
      metadata: {},
    };

    loggerMiddleware(ctx, next);
    expect(next).toHaveBeenCalled();
  });
});
