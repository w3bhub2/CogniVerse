import { describe, it, expect, vi } from "vitest";
import { EventSystem, Events } from "@/engine";

describe("EventSystem", () => {
  it("should emit and receive events", () => {
    const bus = new EventSystem();
    const handler = vi.fn();

    bus.on("test", handler);
    bus.emit("test", { value: 42 });

    expect(handler).toHaveBeenCalledWith({ value: 42 });
    expect(handler).toHaveBeenCalledTimes(1);
  });

  it("should support multiple listeners", () => {
    const bus = new EventSystem();
    const handler1 = vi.fn();
    const handler2 = vi.fn();

    bus.on("test", handler1);
    bus.on("test", handler2);
    bus.emit("test", {});

    expect(handler1).toHaveBeenCalledTimes(1);
    expect(handler2).toHaveBeenCalledTimes(1);
  });

  it("should unsubscribe correctly", () => {
    const bus = new EventSystem();
    const handler = vi.fn();

    const unsub = bus.on("test", handler);
    bus.emit("test", {});
    expect(handler).toHaveBeenCalledTimes(1);

    unsub();
    bus.emit("test", {});
    expect(handler).toHaveBeenCalledTimes(1);
  });

  it("should support once listeners", () => {
    const bus = new EventSystem();
    const handler = vi.fn();

    bus.once("test", handler);
    bus.emit("test", {});
    bus.emit("test", {});
    bus.emit("test", {});

    expect(handler).toHaveBeenCalledTimes(1);
  });

  it("should support payload without data", () => {
    const bus = new EventSystem();
    const handler = vi.fn();

    bus.on("test", handler);
    bus.emit("test");

    expect(handler).toHaveBeenCalledWith({});
  });

  it("should clear all listeners for an event", () => {
    const bus = new EventSystem();
    const handler = vi.fn();

    bus.on("test", handler);
    bus.on("other", handler);
    bus.off("test");

    bus.emit("test", {});
    bus.emit("other", {});

    expect(handler).toHaveBeenCalledTimes(1);
  });

  it("should clear all listeners when no event specified", () => {
    const bus = new EventSystem();
    const handler = vi.fn();

    bus.on("test", handler);
    bus.on("other", handler);
    bus.off();

    bus.emit("test", {});
    bus.emit("other", {});

    expect(handler).toHaveBeenCalledTimes(0);
  });

  it("should count listeners correctly", () => {
    const bus = new EventSystem();
    const handler = vi.fn();

    expect(bus.listenerCount("test")).toBe(0);

    bus.on("test", handler);
    expect(bus.listenerCount("test")).toBe(1);

    bus.once("test", handler);
    expect(bus.listenerCount("test")).toBe(2);
  });

  it("should handle errors in listeners gracefully", () => {
    const bus = new EventSystem();
    const handler = vi.fn(() => {
      throw new Error("test error");
    });
    const handler2 = vi.fn();

    bus.on("test", handler);
    bus.on("test", handler2);

    // Should throw since no error boundary in event system
    expect(() => bus.emit("test", {})).toThrow("test error");
    // But handler2 should have been called if handler1 threw after it
  });

  it("should have all standard event names defined", () => {
    expect(Events.GAME_LOAD).toBeDefined();
    expect(Events.GAME_START).toBeDefined();
    expect(Events.GAME_PAUSE).toBeDefined();
    expect(Events.GAME_RESUME).toBeDefined();
    expect(Events.GAME_END).toBeDefined();
    expect(Events.SAVE_REQUEST).toBeDefined();
    expect(Events.ACHIEVEMENT_UNLOCKED).toBeDefined();
    expect(Events.THEME_CHANGE).toBeDefined();
  });
});
