import { describe, it, expect, beforeEach, vi } from "vitest";
import { Engine, EventSystem, Events } from "@/engine";
import type { GameModule, GameMeta, GameState, GameResult } from "@/engine";

/** Minimal mock game for testing the Engine lifecycle. */
function createMockGame(overrides?: Partial<GameModule>): GameModule {
  const meta: GameMeta = {
    id: "mock-game",
    name: "Mock Game",
    description: "A test game",
    icon: "🎮",
    category: "puzzle",
    difficulty: 1,
    estimatedMinutes: 1,
    tags: ["test"],
    version: "1.0.0",
  };

  let score = 0;
  let gameOver = false;

  return {
    meta,
    init: vi.fn(),
    start: vi.fn(() => { score = 0; gameOver = false; }),
    pause: vi.fn(),
    resume: vi.fn(),
    update: vi.fn(() => { /* noop */ }),
    save: vi.fn((): GameState => ({ score, gameOver })),
    load: vi.fn((state: GameState) => {
      const s = state as { score?: number; gameOver?: boolean };
      if (typeof s.score === "number") score = s.score;
      if (typeof s.gameOver === "boolean") gameOver = s.gameOver;
    }),
    destroy: vi.fn(),
    getScore: vi.fn(() => score),
    isGameOver: vi.fn(() => gameOver),
    isWon: vi.fn(() => false),
    getResult: vi.fn((): GameResult => ({
      score,
      won: false,
      timeElapsed: 0,
      moves: 0,
    })),
    ...overrides,
  };
}

describe("Engine", () => {
  let engine: Engine;
  let events: EventSystem;

  beforeEach(() => {
    events = new EventSystem();
    engine = new Engine(events);
  });

  describe("lifecycle", () => {
    it("should start in idle state", () => {
      expect(engine.getState()).toBe("idle");
    });

    it("should transition to loaded after loadGame", async () => {
      const game = createMockGame();
      await engine.loadGame(game);
      expect(engine.getState()).toBe("loaded");
      expect(game.init).toHaveBeenCalled();
    });

    it("should transition to running after startGame", async () => {
      const game = createMockGame();
      await engine.loadGame(game);
      engine.startGame();
      expect(engine.getState()).toBe("running");
      expect(game.start).toHaveBeenCalled();
    });

    it("should pause and resume", async () => {
      const game = createMockGame();
      await engine.loadGame(game);
      engine.startGame();

      engine.pauseGame();
      expect(engine.getState()).toBe("paused");
      expect(game.pause).toHaveBeenCalled();

      engine.resumeGame();
      expect(engine.getState()).toBe("running");
      expect(game.resume).toHaveBeenCalled();
    });

    it("should destroy and return to idle", async () => {
      const game = createMockGame();
      await engine.loadGame(game);
      engine.startGame();

      await engine.destroyGame();
      expect(engine.getState()).toBe("idle");
      expect(engine.getGame()).toBeNull();
    });
  });

  describe("save/load", () => {
    it("should save game state", async () => {
      const game = createMockGame();
      await engine.loadGame(game);

      const state = engine.saveGame();
      expect(state).not.toBeNull();
      expect(game.save).toHaveBeenCalled();
    });

    it("should load game state", async () => {
      const game = createMockGame();
      await engine.loadGame(game);

      engine.loadSave({ score: 100, gameOver: false });
      expect(game.load).toHaveBeenCalledWith({ score: 100, gameOver: false });
    });
  });

  describe("undo/redo", () => {
    it("should delegate to game module", async () => {
      const undoFn = vi.fn(() => true);
      const redoFn = vi.fn(() => true);
      const game = createMockGame({
        undo: undoFn,
        redo: redoFn,
        canUndo: () => true,
        canRedo: () => true,
      });

      await engine.loadGame(game);

      expect(engine.undo()).toBe(true);
      expect(undoFn).toHaveBeenCalled();

      expect(engine.redo()).toBe(true);
      expect(redoFn).toHaveBeenCalled();
    });

    it("should return false when game has no undo", async () => {
      const game = createMockGame();
      await engine.loadGame(game);
      expect(engine.undo()).toBe(false);
    });
  });

  describe("middleware", () => {
    it("should expose middleware chain", () => {
      const middleware = engine.getMiddleware();
      expect(middleware).toBeDefined();
      expect(typeof middleware.use).toBe("function");
      expect(typeof middleware.execute).toBe("function");
    });
  });

  describe("performance monitor", () => {
    it("should expose performance monitor", () => {
      const perf = engine.getPerformance();
      expect(perf).toBeDefined();
      expect(typeof perf.getFPS).toBe("function");
      expect(typeof perf.getStats).toBe("function");
    });
  });

  describe("events", () => {
    it("should emit GAME_LOAD on load", async () => {
      const handler = vi.fn();
      events.on(Events.GAME_LOAD, handler);

      const game = createMockGame();
      await engine.loadGame(game);

      expect(handler).toHaveBeenCalledWith(
        expect.objectContaining({ gameId: "mock-game" })
      );
    });

    it("should emit GAME_START on start", async () => {
      const handler = vi.fn();
      events.on(Events.GAME_START, handler);

      const game = createMockGame();
      await engine.loadGame(game);
      engine.startGame();

      expect(handler).toHaveBeenCalled();
    });

    it("should emit GAME_PAUSE on pause", async () => {
      const handler = vi.fn();
      events.on(Events.GAME_PAUSE, handler);

      const game = createMockGame();
      await engine.loadGame(game);
      engine.startGame();
      engine.pauseGame();

      expect(handler).toHaveBeenCalled();
    });
  });
});
