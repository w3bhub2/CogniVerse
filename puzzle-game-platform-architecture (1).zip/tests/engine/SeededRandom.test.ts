import { describe, it, expect } from "vitest";
import { SeededRandom } from "@/engine";

describe("SeededRandom", () => {
  it("should produce deterministic results with same seed", () => {
    const rng1 = new SeededRandom(12345);
    const rng2 = new SeededRandom(12345);

    for (let i = 0; i < 100; i++) {
      expect(rng1.next()).toBe(rng2.next());
    }
  });

  it("should produce different results with different seeds", () => {
    const rng1 = new SeededRandom(11111);
    const rng2 = new SeededRandom(22222);

    const vals1 = Array.from({ length: 10 }, () => rng1.next());
    const vals2 = Array.from({ length: 10 }, () => rng2.next());

    expect(vals1).not.toEqual(vals2);
  });

  it("should produce values in [0, 1)", () => {
    const rng = new SeededRandom(42);

    for (let i = 0; i < 1000; i++) {
      const val = rng.next();
      expect(val).toBeGreaterThanOrEqual(0);
      expect(val).toBeLessThan(1);
    }
  });

  it("nextInt should produce values in range", () => {
    const rng = new SeededRandom(42);

    for (let i = 0; i < 1000; i++) {
      const val = rng.nextInt(1, 6);
      expect(val).toBeGreaterThanOrEqual(1);
      expect(val).toBeLessThanOrEqual(6);
      expect(Number.isInteger(val)).toBe(true);
    }
  });

  it("nextFloat should produce values in range", () => {
    const rng = new SeededRandom(42);

    for (let i = 0; i < 100; i++) {
      const val = rng.nextFloat(2.5, 7.5);
      expect(val).toBeGreaterThanOrEqual(2.5);
      expect(val).toBeLessThan(7.5);
    }
  });

  it("pick should return elements from the array", () => {
    const rng = new SeededRandom(42);
    const arr = ["a", "b", "c", "d"];

    for (let i = 0; i < 100; i++) {
      const val = rng.pick(arr);
      expect(arr).toContain(val);
    }
  });

  it("shuffle should return all elements", () => {
    const rng = new SeededRandom(42);
    const arr = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];

    const shuffled = rng.shuffle(arr);

    expect(shuffled).toHaveLength(arr.length);
    // Should contain same elements (sorted comparison)
    expect([...shuffled].sort((a, b) => a - b)).toEqual([...arr].sort((a, b) => a - b));
  });

  it("shuffle should not mutate original array", () => {
    const rng = new SeededRandom(42);
    const arr = [1, 2, 3, 4, 5];
    const original = [...arr];

    rng.shuffle(arr);

    expect(arr).toEqual(original);
  });

  it("weightedPick should respect weights", () => {
    const rng = new SeededRandom(42);
    const items = ["a", "b"];
    const weights = [100, 0]; // Always pick "a"

    for (let i = 0; i < 100; i++) {
      expect(rng.weightedPick(items, weights)).toBe("a");
    }
  });

  it("fork should create independent RNG", () => {
    const rng = new SeededRandom(42);
    const forked = rng.fork();

    const parentVals = Array.from({ length: 10 }, () => rng.next());
    const forkVals = Array.from({ length: 10 }, () => forked.next());

    expect(parentVals).not.toEqual(forkVals);
  });

  it("getState/setState should work for serialization", () => {
    const rng = new SeededRandom(42);
    rng.next();
    rng.next();

    const state = rng.getState();

    const rng2 = new SeededRandom(999);
    rng2.setState(state);

    // Should continue from saved state
    expect(rng2.next()).toBe(rng.next());
  });

  it("should accept string seeds", () => {
    const rng1 = new SeededRandom("hello");
    const rng2 = new SeededRandom("hello");

    for (let i = 0; i < 10; i++) {
      expect(rng1.next()).toBe(rng2.next());
    }
  });

  it("randomSeed should return a number", () => {
    const seed = SeededRandom.randomSeed();
    expect(typeof seed).toBe("number");
    expect(seed).toBeGreaterThanOrEqual(0);
  });
});
