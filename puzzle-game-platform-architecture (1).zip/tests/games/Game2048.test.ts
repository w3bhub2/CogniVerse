import { describe, it, expect, beforeEach } from "vitest";
import { Game2048 } from "@/games/game2048/Game2048";
import { EventSystem } from "@/engine";

describe("Game2048", () => {
  let game: Game2048;
  let events: EventSystem;

  beforeEach(() => {
    game = new Game2048();
    events = new EventSystem();
    game.init(events);
    game.start();
  });

  describe("meta", () => {
    it("should have correct metadata", () => {
      expect(game.meta.id).toBe("2048");
      expect(game.meta.name).toBe("2048");
      expect(game.meta.category).toBe("number");
      expect(game.meta.version).toBe("2.0.0");
    });
  });

  describe("lifecycle", () => {
    it("should start with score 0", () => {
      expect(game.getScore()).toBe(0);
    });

    it("should not be game over at start", () => {
      expect(game.isGameOver()).toBe(false);
    });

    it("should not be won at start", () => {
      expect(game.isWon()).toBe(false);
    });

    it("should save and load state", () => {
      game.move("right");
      const state = game.save();

      const newGame = new Game2048();
      newGame.init(events);
      newGame.load(state);

      expect(newGame.getScore()).toBe(game.getScore());
    });
  });

  describe("movement", () => {
    it("should change board on valid move", () => {
      const before = JSON.stringify(
        (game.save() as { board: number[][] }).board
      );
      game.move("right");
      const after = JSON.stringify(
        (game.save() as { board: number[][] }).board
      );

      // Board should change (or move was invalid because no tiles can move)
      // At least score might change
      expect(typeof before).toBe("string");
      expect(typeof after).toBe("string");
    });

    it("should increment moves count", () => {
      const result = game.getResult();
      const movesBefore = result.moves;

      // Try all directions to ensure at least one works
      const dirs: ("left" | "right" | "up" | "down")[] = ["left", "right", "up", "down"];
      for (const dir of dirs) {
        game.move(dir);
      }

      const movesAfter = game.getResult().moves;
      expect(movesAfter).toBeGreaterThanOrEqual(movesBefore);
    });
  });

  describe("undo/redo", () => {
    it("should support undo after a move", () => {
      // Make several moves to guarantee at least one changes the board
      let moved = false;
      const dirs: ("left" | "right" | "up" | "down")[] = ["left", "right", "up", "down", "left", "right"];
      for (const dir of dirs) {
        if (game.move(dir)) {
          moved = true;
          break;
        }
      }

      if (moved) {
        expect(game.canUndo()).toBe(true);
        const scoreBefore = game.getScore();
        game.undo();
        // After undo, we should be able to redo
        expect(game.canRedo()).toBe(true);
      }
    });

    it("should not undo when no history", () => {
      expect(game.canUndo()).toBe(false);
      expect(game.undo()).toBe(false);
    });

    it("should not redo when no redo stack", () => {
      expect(game.canRedo()).toBe(false);
      expect(game.redo()).toBe(false);
    });
  });

  describe("hint", () => {
    it("should not throw when calling hint", () => {
      expect(() => game.hint()).not.toThrow();
    });
  });

  describe("getResult", () => {
    it("should return a valid GameResult", () => {
      const result = game.getResult();
      expect(typeof result.score).toBe("number");
      expect(typeof result.won).toBe("boolean");
      expect(typeof result.timeElapsed).toBe("number");
      expect(typeof result.moves).toBe("number");
    });
  });

  describe("serialization", () => {
    it("should produce a JSON-serializable state", () => {
      game.move("left");
      const state = game.save();
      expect(() => JSON.stringify(state)).not.toThrow();
    });

    it("should restore from serialized state", () => {
      game.move("left");
      const state = game.save();

      const newGame = new Game2048();
      newGame.init(events);
      newGame.load(state);

      const result1 = game.getResult();
      const result2 = newGame.getResult();
      expect(result1.score).toBe(result2.score);
      expect(result1.moves).toBe(result2.moves);
    });
  });
});
