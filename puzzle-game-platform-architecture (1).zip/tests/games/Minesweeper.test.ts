import { describe, it, expect, beforeEach } from "vitest";
import { MinesweeperGame } from "@/games/minesweeper/MinesweeperGame";
import { EventSystem } from "@/engine";

describe("MinesweeperGame", () => {
  let game: MinesweeperGame;
  let events: EventSystem;

  beforeEach(() => {
    game = new MinesweeperGame();
    events = new EventSystem();
    game.init(events);
    game.start();
  });

  describe("meta", () => {
    it("should have correct metadata", () => {
      expect(game.meta.id).toBe("minesweeper");
      expect(game.meta.category).toBe("logic");
    });
  });

  describe("board", () => {
    it("should have correct dimensions for easy mode", () => {
      expect(game.getRows()).toBe(9);
      expect(game.getCols()).toBe(9);
      expect(game.getTotalMines()).toBe(10);
    });

    it("should have board with all cells unrevealed at start", () => {
      const board = game.getBoard();
      for (const row of board) {
        for (const cell of row) {
          expect(cell.isRevealed).toBe(false);
          expect(cell.isFlagged).toBe(false);
        }
      }
    });

    it("should place mines on first reveal", () => {
      // Mines are placed on first click (safe zone protection)
      const boardBefore = game.getBoard();
      let minesBefore = 0;
      for (const row of boardBefore) {
        for (const cell of row) {
          if (cell.isMine) minesBefore++;
        }
      }
      expect(minesBefore).toBe(0);

      // After first reveal
      game.reveal(4, 4);

      const boardAfter = game.getBoard();
      let minesAfter = 0;
      for (const row of boardAfter) {
        for (const cell of row) {
          if (cell.isMine) minesAfter++;
        }
      }
      expect(minesAfter).toBe(10);
    });
  });

  describe("reveal", () => {
    it("should reveal a cell on first click", () => {
      game.reveal(0, 0);
      const board = game.getBoard();
      const cell = board[0][0];
      expect(cell.isRevealed).toBe(true);
    });

    it("should not reveal flagged cells", () => {
      // First reveal to place mines (required before flagging)
      game.reveal(4, 4);
      // Flag a cell
      game.toggleFlag(0, 0);
      // Try to reveal flagged cell
      game.reveal(0, 0);
      const board = game.getBoard();
      expect(board[0][0].isFlagged).toBe(true);
      // If it was flagged, it shouldn't have been revealed even if it's not a mine
      // (the flag protection prevents reveal)
    });

    it("should flood-fill when revealing empty cell", () => {
      // Reveal center to place mines away
      game.reveal(4, 4);

      // Count revealed cells
      const board = game.getBoard();
      let revealed = 0;
      for (const row of board) {
        for (const cell of row) {
          if (cell.isRevealed) revealed++;
        }
      }
      // Flood fill should reveal more than just 1 cell
      expect(revealed).toBeGreaterThan(1);
    });
  });

  describe("flagging", () => {
    it("should toggle flag on unrevealed cell after first reveal", () => {
      // Must reveal first to place mines, then flag
      game.reveal(4, 4);

      // Find an unrevealed, non-mine cell to flag
      const board = game.getBoard();
      let flagR = -1;
      let flagC = -1;
      for (let r = 0; r < game.getRows(); r++) {
        for (let c = 0; c < game.getCols(); c++) {
          if (!board[r][c].isRevealed && !board[r][c].isMine) {
            flagR = r;
            flagC = c;
            break;
          }
        }
        if (flagR >= 0) break;
      }

      if (flagR >= 0) {
        game.toggleFlag(flagR, flagC);
        expect(game.getBoard()[flagR][flagC].isFlagged).toBe(true);

        game.toggleFlag(flagR, flagC);
        expect(game.getBoard()[flagR][flagC].isFlagged).toBe(false);
      }
    });

    it("should track flag count", () => {
      game.reveal(4, 4); // Place mines

      // Find two unrevealed, non-mine cells
      const board = game.getBoard();
      const cells: [number, number][] = [];
      for (let r = 0; r < game.getRows() && cells.length < 2; r++) {
        for (let c = 0; c < game.getCols() && cells.length < 2; c++) {
          if (!board[r][c].isRevealed && !board[r][c].isMine) {
            cells.push([r, c]);
          }
        }
      }

      if (cells.length >= 2) {
        game.toggleFlag(cells[0][0], cells[0][1]);
        expect(game.getFlagsPlaced()).toBe(1);

        game.toggleFlag(cells[1][0], cells[1][1]);
        expect(game.getFlagsPlaced()).toBe(2);

        game.toggleFlag(cells[0][0], cells[0][1]);
        expect(game.getFlagsPlaced()).toBe(1);
      }
    });
  });

  describe("difficulty", () => {
    it("should change dimensions when difficulty changes", () => {
      game.setDifficulty("medium");
      expect(game.getRows()).toBe(16);
      expect(game.getCols()).toBe(16);
      expect(game.getTotalMines()).toBe(40);

      game.setDifficulty("hard");
      expect(game.getRows()).toBe(16);
      expect(game.getCols()).toBe(30);
      expect(game.getTotalMines()).toBe(99);
    });
  });

  describe("game state", () => {
    it("should return valid result", () => {
      const result = game.getResult();
      expect(typeof result.score).toBe("number");
      expect(typeof result.won).toBe("boolean");
      expect(typeof result.timeElapsed).toBe("number");
    });

    it("should save and load state", () => {
      game.reveal(4, 4);
      const state = game.save();

      const newGame = new MinesweeperGame();
      newGame.init(events);
      newGame.load(state);

      expect(newGame.getRows()).toBe(game.getRows());
      expect(newGame.getTotalMines()).toBe(game.getTotalMines());
    });

    it("should not reveal cells before first click (mine placement)", () => {
      const board = game.getBoard();
      let mines = 0;
      for (const row of board) {
        for (const cell of row) {
          if (cell.isMine) mines++;
        }
      }
      // Mines should be placed after start (during first reveal)
      // Actually mines are placed on first reveal, so count should be 0 at start
      // Wait — looking at the code, mines are placed on first click
      // Let's check: the board is initialized with isMine: false
      expect(mines).toBe(0);
    });
  });
});
