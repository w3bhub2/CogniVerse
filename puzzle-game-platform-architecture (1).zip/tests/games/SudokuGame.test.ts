import { describe, it, expect, beforeEach } from "vitest";
import { SudokuGame } from "@/games/sudoku/SudokuGame";
import { EventSystem } from "@/engine";

describe("SudokuGame", () => {
  let game: SudokuGame;
  let events: EventSystem;

  beforeEach(() => {
    game = new SudokuGame();
    events = new EventSystem();
    game.init(events);
    game.start();
  });

  describe("meta", () => {
    it("should have correct metadata", () => {
      expect(game.meta.id).toBe("sudoku");
      expect(game.meta.category).toBe("logic");
    });
  });

  describe("board", () => {
    it("should generate a valid 9x9 board", () => {
      const board = game.getBoard();
      expect(board).toHaveLength(9);
      for (const row of board) {
        expect(row).toHaveLength(9);
      }
    });

    it("should have given cells with correct values", () => {
      const board = game.getBoard();
      for (let r = 0; r < 9; r++) {
        for (let c = 0; c < 9; c++) {
          const cell = board[r][c];
          if (cell.given) {
            expect(cell.value).toBeGreaterThanOrEqual(1);
            expect(cell.value).toBeLessThanOrEqual(9);
          }
        }
      }
    });

    it("should have some empty cells", () => {
      const board = game.getBoard();
      let empty = 0;
      for (const row of board) {
        for (const cell of row) {
          if (!cell.given && cell.value === 0) empty++;
        }
      }
      expect(empty).toBeGreaterThan(0);
    });
  });

  describe("placement", () => {
    it("should allow placing number in empty cell", () => {
      const board = game.getBoard();
      // Find an empty cell
      for (let r = 0; r < 9; r++) {
        for (let c = 0; c < 9; c++) {
          if (!board[r][c].given && board[r][c].value === 0) {
            const result = game.placeNumber(r, c, 1);
            expect(result).toBe(true);
            return;
          }
        }
      }
    });

    it("should not allow placing number in given cell", () => {
      const board = game.getBoard();
      for (let r = 0; r < 9; r++) {
        for (let c = 0; c < 9; c++) {
          if (board[r][c].given) {
            const originalValue = board[r][c].value;
            game.placeNumber(r, c, originalValue === 9 ? 1 : 9);
            expect(game.getBoard()[r][c].value).toBe(originalValue);
            return;
          }
        }
      }
    });
  });

  describe("eraser", () => {
    it("should erase a non-given cell", () => {
      const board = game.getBoard();
      for (let r = 0; r < 9; r++) {
        for (let c = 0; c < 9; c++) {
          if (!board[r][c].given) {
            game.placeNumber(r, c, 5);
            game.erase(r, c);
            expect(game.getBoard()[r][c].value).toBe(0);
            return;
          }
        }
      }
    });
  });

  describe("hint", () => {
    it("should reveal one cell", () => {
      const boardBefore = game.getBoard();
      let emptyBefore = 0;
      for (const row of boardBefore) {
        for (const cell of row) {
          if (cell.value === 0) emptyBefore++;
        }
      }

      game.hint();

      const boardAfter = game.getBoard();
      let emptyAfter = 0;
      for (const row of boardAfter) {
        for (const cell of row) {
          if (cell.value === 0) emptyAfter++;
        }
      }

      expect(emptyAfter).toBeLessThan(emptyBefore);
    });
  });

  describe("difficulty", () => {
    it("should change difficulty and regenerate", () => {
      // setDifficulty changes the internal difficulty and calls start()
      game.setDifficulty("hard");
      expect(game.getDifficulty()).toBe("hard");

      // Verify board was regenerated
      const board = game.getBoard();
      expect(board).toHaveLength(9);
    });
  });

  describe("serialization", () => {
    it("should save and load state correctly", () => {
      game.placeNumber(0, 0, 5);
      const state = game.save();

      const newGame = new SudokuGame();
      newGame.init(events);
      newGame.load(state);

      expect(newGame.getScore()).toBe(game.getScore());
    });
  });
});
