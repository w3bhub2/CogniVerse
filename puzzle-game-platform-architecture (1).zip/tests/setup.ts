import "@testing-library/jest-dom";

// Mock localStorage
const localStorageMock = (() => {
  let store: Record<string, string> = {};
  return {
    getItem: (key: string) => store[key] ?? null,
    setItem: (key: string, value: string) => { store[key] = value; },
    removeItem: (key: string) => { delete store[key]; },
    clear: () => { store = {}; },
    get length() { return Object.keys(store).length; },
    key: (index: number) => Object.keys(store)[index] ?? null,
  };
})();

Object.defineProperty(globalThis, "localStorage", { value: localStorageMock });

// Mock performance.now
if (!globalThis.performance?.now) {
  Object.defineProperty(globalThis, "performance", {
    value: { now: () => Date.now() },
  });
}

// Mock requestAnimationFrame
if (!globalThis.requestAnimationFrame) {
  globalThis.requestAnimationFrame = (cb: FrameRequestCallback) =>
    setTimeout(cb, 16) as unknown as number;
}

// Mock cancelAnimationFrame
if (!globalThis.cancelAnimationFrame) {
  globalThis.cancelAnimationFrame = (id: number) => clearTimeout(id);
}

// Mock AudioContext
(globalThis as Record<string, unknown>).AudioContext = class MockAudioContext {
  createOscillator() {
    return {
      connect: () => {},
      start: () => {},
      stop: () => {},
      frequency: { value: 0 },
      type: "sine",
    };
  }
  createGain() {
    return {
      connect: () => {},
      gain: {
        value: 0,
        exponentialRampToValueAtTime: () => {},
      },
    };
  }
  get destination() { return {}; }
  get currentTime() { return 0; }
};

// Note: afterEach is provided by vitest globals
