import { describe, it, expect } from "vitest";
import {
  sanitizeString,
  sanitizeGameId,
  isSafeObject,
  isRateLimited,
  errorResponse,
  successResponse,
} from "@/lib/security";

describe("Security utilities", () => {
  describe("sanitizeString", () => {
    it("should escape HTML characters", () => {
      const result = sanitizeString('<script>alert("xss")</script>');
      expect(result).toContain("&lt;script&gt;");
      expect(result).toContain("&lt;&#x2F;script&gt;");
    });

    it("should limit string length", () => {
      const long = "a".repeat(2000);
      expect(sanitizeString(long).length).toBe(1000);
    });

    it("should pass through clean strings", () => {
      expect(sanitizeString("hello world 123")).toBe("hello world 123");
    });
  });

  describe("sanitizeGameId", () => {
    it("should only allow alphanumeric and hyphens", () => {
      expect(sanitizeGameId("2048")).toBe("2048");
      expect(sanitizeGameId("word-search")).toBe("word-search");
      expect(sanitizeGameId("my_game!@#")).toBe("mygame");
    });

    it("should limit length", () => {
      const long = "a".repeat(100);
      expect(sanitizeGameId(long).length).toBe(50);
    });
  });

  describe("isSafeObject", () => {
    it("should accept simple objects", () => {
      expect(isSafeObject({ a: 1, b: "hello" })).toBe(true);
    });

    it("should accept arrays under length limit", () => {
      expect(isSafeObject([1, 2, 3])).toBe(true);
      expect(isSafeObject({ 0: 1, 1: 2, 2: 3 })).toBe(true);
    });

    it("should accept safe primitives", () => {
      expect(isSafeObject("string")).toBe(true);
      expect(isSafeObject(42)).toBe(true);
      expect(isSafeObject(true)).toBe(true);
    });

    it("should reject objects with too many keys", () => {
      const big: Record<string, number> = {};
      for (let i = 0; i < 200; i++) big[`key${i}`] = i;
      expect(isSafeObject(big)).toBe(false);
    });
  });

  describe("rate limiting", () => {
    it("should not block first request", () => {
      expect(isRateLimited("test-key", 5, 60000)).toBe(false);
    });

    it("should block after max requests", () => {
      const key = "rate-limit-test-" + Date.now();
      for (let i = 0; i < 5; i++) {
        isRateLimited(key, 5, 60000);
      }
      expect(isRateLimited(key, 5, 60000)).toBe(true);
    });
  });

  describe("responses", () => {
    it("errorResponse should have correct status", async () => {
      const res = errorResponse("test error", 400);
      expect(res.status).toBe(400);
      const body = await res.json();
      expect(body.error).toBe("test error");
    });

    it("successResponse should return data", async () => {
      const res = successResponse({ ok: true, value: 42 });
      expect(res.status).toBe(200);
      const body = await res.json();
      expect(body.ok).toBe(true);
      expect(body.value).toBe(42);
    });
  });
});
