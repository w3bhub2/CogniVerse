/**
 * Capacitor Configuration
 *
 * This configuration wraps the Next.js web app into a native Android shell.
 * Used for building standalone APKs and the Puzzle Platform app.
 *
 * Build commands:
 *   npx cap add android       # First time only
 *   npx cap sync android      # Sync web assets to Android
 *   npx cap open android      # Open in Android Studio
 *   npx cap build android     # Build AAB/APK
 *
 * For standalone game apps, the build system copies only the selected
 * game module and rebuilds with a different app ID.
 */

import type { CapacitorConfig } from "@capacitor/cli";

const config: CapacitorConfig = {
  appId: "com.puzzleplatform.app",
  appName: "Puzzle Platform",
  webDir: ".next",
  server: {
    androidScheme: "https",
    // For development, point to local dev server
    // url: "http://10.0.2.2:3000",
    // cleartext: true,
  },
  plugins: {
    SplashScreen: {
      launchShowDuration: 1500,
      backgroundColor: "#6366f1",
      showSpinner: false,
      androidSplashResourceName: "splash",
      androidScaleType: "CENTER_CROP",
    },
    Haptics: {
      // Default vibration patterns
    },
    StatusBar: {
      style: "DARK",
      backgroundColor: "#6366f1",
    },
    Keyboard: {
      resize: "body",
      style: "DARK",
    },
  },
  android: {
    allowMixedContent: false,
    // Build type for Play Store
    buildOptions: {
      keystorePath: undefined, // Use Google Play App Signing
      keystoreAlias: undefined,
      releaseType: "APK",
    },
  },
};

export default config;
