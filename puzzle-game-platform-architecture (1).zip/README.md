# Puzzle Platform

One engine, one services layer, 50+ premium casual puzzle games.
Every game runs inside the platform **and** compiles to its own Play Store app.

## Status (honest)

| | |
|---|---|
| Engine & contract | Production ready |
| Shipped games | 2048 · Sudoku · Minesweeper |
| Launch lineup | 2 of 6 complete — see [Studio Review](docs/PRODUCT/STUDIO_REVIEW.md) |
| Tests | 111 passing (`npx vitest run`) |
| Overall readiness | 6.1 / 10 |

## Quick start

```bash
npm install
npm run dev            # local server
npx vitest run         # tests
npm run build          # production build
```

## Where things live

```
src/engine/     Engine v2 — lifecycle, events, replay, seeded RNG, perf monitor
src/platform/   Save, themes, audio, haptics, ads, IAP, streaks, XP, achievements
src/games/      Game modules implementing GameModule (logic only)
src/components/ Shared UI + per-game renderers (views only)
src/app/        Routes + API (saves, scores, analytics, health)
docs/           All documentation — start with MASTER_INDEX
```

## The one contract

Games implement `GameModule` (see [Platform Contract](docs/ARCHITECTURE/PLATFORM_CONTRACT.md)).
The engine drives; renderers subscribe and dispatch. Games never import platform code.

## Adding game #N

1. `src/games/<id>/<Game>.ts` — implement `GameModule` + `validate()`.
2. Register in `GameRegistry.ts`.
3. `src/components/game/<Game>Renderer.tsx` — subscribe to `Engine`, dispatch actions.
4. Add case in `GamePlayer.tsx`, write tests, add spec under `docs/GAMES/`.

## Android / standalone builds

```bash
npm run cap:sync                 # web → Capacitor
./scripts/build-standalone.sh sudoku   # one game = one AAB
```

## Documentation map

[MASTER_INDEX](docs/MASTER_INDEX.md) · [Architecture](docs/ARCHITECTURE/PLATFORM_ARCHITECTURE.md) ·
[Engine](docs/ENGINEERING/ENGINE.md) · [Testing](docs/ENGINEERING/TESTING_STANDARDS.md) ·
[Competitive Audit](docs/PRODUCT/COMPETITIVE_AUDIT.md) · [Studio Review](docs/PRODUCT/STUDIO_REVIEW.md)
