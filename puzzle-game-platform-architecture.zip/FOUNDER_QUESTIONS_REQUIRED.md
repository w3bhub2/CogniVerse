# FOUNDER DECISIONS REQUIRED (Master Consolidated List)
**Authoritative Directive:** This file contains ONLY the remaining founder/business decisions that cannot be inferred from the codebase, the technical architecture, or engineering judgment.
**Instruction:** Once you have reviewed and answered these items, you may delete this file from the repository root (`rm FOUNDER_QUESTIONS_REQUIRED.md`).

---

## 1. Business
### 1.1 Global Season Duration & LiveOps Cadence
* **Why it cannot be inferred:** Determining season turnover (Weekly vs 30-Day Monthly Seasons) requires balancing competitive turnover against player fatigue and server-side leaderboard archive storage costs.
* **What implementation it blocks:** Automated Season End cron trigger in `src/services/liveops.service.ts` and periodic PostgreSQL leaderboard archiving.
* **Recommendation:** **30-Day Monthly Seasons** with weekly mini-events. At midnight UTC on the last day of each month, automatically archive top-3 scores per game, award the "Monthly Master" badge, and grant a 500-coin bonus pool.

---

## 2. Branding
### 2.1 Authoritative Studio / Publisher Name & Domain
* **Why it cannot be inferred:** Public store branding, copyright notices, and custom support domains must match official legal registration.
* **What implementation it blocks:** Final copyright strings in `PLAYSTORE_RELEASE_GUIDE.md`, support email footer links, and Google Play Console developer profile naming.
* **Recommendation:** Use **Puzzle Platform Studio** (`puzzleplatform.com`) as the default canonical brand identity across all store listings and in-app headers.

---

## 3. Legal
### 3.1 GDPR/CCPA Regional Data Residency & Privacy Contact Email
* **Why it cannot be inferred:** EU GDPR and California CCPA require an official corporate privacy contact email and jurisdiction determination for anonymized cloud backups.
* **What implementation it blocks:** Privacy Policy legal contact clauses in `src/services/playstore-automation.service.ts` and infrastructure cloud region deployment.
* **Recommendation:** Multi-region or EU-first storage (`eu-west-1` or `us-east-1` with EU Standard Contractual Clauses) with default privacy contact `privacy@puzzleplatform.com` and an immediate in-app "Download My Data (JSON)" and "Right to be Forgotten (1-Click Erase)" control in the Player Profile modal.

---

## 4. Monetization
### 4.1 Standalone Game Ad-Free VIP vs Global Studio Pass Pricing Tiering
* **Why it cannot be inferred:** Pricing strategy between individual casual app buyers and multi-game platform power users is a commercial business decision.
* **What implementation it blocks:** Google Play Console IAP SKU configuration and `src/services/monetization.service.ts` product IDs.
* **Recommendation:** **$1.99** for permanent Ad-Free in any standalone game (`com.puzzleplatform.games.[id].adfree`); **$9.99** for the permanent Global Studio Pass (`com.puzzleplatform.app.studiopass`) unlocking Ad-Free + all VIP themes across the entire 50-game ecosystem.

---

## 5. Publishing
### 5.1 Cloud Authentication & Guest-First Account Link Timing
* **Why it cannot be inferred:** Determining when and how aggressively to prompt a guest user to link Google Play Games Services or Apple ID impacts Day-1 onboarding retention vs cross-device account recovery.
* **What implementation it blocks:** Cloud sync user identity promotion (`src/services/storage.service.ts`) and cross-device leaderboard verification.
* **Recommendation:** Silent Guest-First mode (`player-[random_id]`) for the first 3 game sessions. On completion of Story Chapter 1 or upon achieving a top-100 high score, present an optional, non-blocking 1-click "Link Google Play Games / Cloud Backup" banner.

---

## 6. Credentials
### 6.1 Google Play Console, Firebase Project & AdMob Unit IDs
* **Why it cannot be inferred:** Production API keys, AdMob publisher unit IDs, and Google Play App Signing upload keystore certificates belong to your developer accounts.
* **What implementation it blocks:** Final production release signing in Android Studio (`studio-upload-keystore.jks`) and production ad serving.
* **Recommendation:** Use our provided test IDs (`ca-app-pub-3940256099942544~3347511713`) in development/staging. Populate `KEYSTORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD`, and `NEXT_PUBLIC_ADMOB_REWARDED_ID` in CI/CD environment secrets before Play Store submission.
