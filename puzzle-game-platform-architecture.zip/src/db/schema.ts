import {
  pgTable,
  serial,
  text,
  integer,
  jsonb,
  timestamp,
  boolean,
  uniqueIndex,
} from "drizzle-orm/pg-core";

export const profiles = pgTable("profiles", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull().unique(),
  displayName: text("display_name").notNull().default("Studio Player"),
  avatarUrl: text("avatar_url").default("https://api.dicebear.com/7.x/bottts/svg?seed=StudioPlayer"),
  level: integer("level").notNull().default(1),
  totalStars: integer("total_stars").notNull().default(0),
  coins: integer("coins").notNull().default(500),
  adFree: boolean("ad_free").notNull().default(false),
  activeTheme: text("active_theme").notNull().default("midnight-slate"),
  locale: text("locale").notNull().default("en-US"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const gameSaves = pgTable(
  "game_saves",
  {
    id: serial("id").primaryKey(),
    userId: text("user_id").notNull(),
    gameId: text("game_id").notNull(),
    saveData: jsonb("save_data").notNull(),
    highScore: integer("high_score").notNull().default(0),
    bestTimeMs: integer("best_time_ms"),
    totalGamesPlayed: integer("total_games_played").notNull().default(0),
    totalGamesWon: integer("total_games_won").notNull().default(0),
    lastPlayedAt: timestamp("last_played_at").defaultNow().notNull(),
  },
  (table) => ({
    userGameIdx: uniqueIndex("user_game_idx").on(table.userId, table.gameId),
  })
);

export const userAchievements = pgTable(
  "user_achievements",
  {
    id: serial("id").primaryKey(),
    userId: text("user_id").notNull(),
    achievementId: text("achievement_id").notNull(),
    gameId: text("game_id").default("platform"),
    unlockedAt: timestamp("unlocked_at").defaultNow().notNull(),
  },
  (table) => ({
    userAchIdx: uniqueIndex("user_ach_idx").on(table.userId, table.achievementId),
  })
);

export const analyticsEvents = pgTable("analytics_events", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  eventName: text("event_name").notNull(),
  gameId: text("game_id"),
  properties: jsonb("properties"),
  clientTimestamp: timestamp("client_timestamp").defaultNow().notNull(),
  serverTimestamp: timestamp("server_timestamp").defaultNow().notNull(),
});

export const buildManifestLogs = pgTable("build_manifest_logs", {
  id: serial("id").primaryKey(),
  targetType: text("target_type").notNull(), // 'platform' or 'standalone_game'
  gameId: text("game_id"), // null if platform
  versionName: text("version_name").notNull(),
  packageId: text("package_id").notNull(),
  manifestJson: jsonb("manifest_json").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const campaignProgress = pgTable(
  "campaign_progress",
  {
    id: serial("id").primaryKey(),
    userId: text("user_id").notNull(),
    chapterId: text("chapter_id").notNull(),
    starsEarned: integer("stars_earned").notNull().default(0), // 0 to 3
    isCompleted: boolean("is_completed").notNull().default(false),
    bestScore: integer("best_score").notNull().default(0),
    bestTimeSeconds: integer("best_time_seconds"),
    unlockedRelic: boolean("unlocked_relic").notNull().default(false),
    updatedAt: timestamp("updated_at").defaultNow().notNull(),
  },
  (table) => ({
    userChapterIdx: uniqueIndex("user_chapter_idx").on(table.userId, table.chapterId),
  })
);

export const dailyChallenges = pgTable(
  "daily_challenges",
  {
    id: serial("id").primaryKey(),
    userId: text("user_id").notNull(),
    dateKey: text("date_key").notNull(), // YYYY-MM-DD
    gameId: text("game_id").notNull(),
    score: integer("score").notNull().default(0),
    isSolved: boolean("is_solved").notNull().default(false),
    streakCount: integer("streak_count").notNull().default(1),
    solvedAt: timestamp("solved_at").defaultNow().notNull(),
  },
  (table) => ({
    userDateIdx: uniqueIndex("user_date_idx").on(table.userId, table.dateKey),
  })
);
