export type SoundEffectType =
  | "click"
  | "move"
  | "merge"
  | "victory"
  | "gameover"
  | "hint"
  | "undo"
  | "error";

export type HapticPattern = "light" | "medium" | "heavy" | "success" | "error";

export interface AchievementItem {
  id: string;
  title: string;
  description: string;
  iconName: string;
  category: "General" | "2048" | "Sudoku" | "Crossword" | "Word Search" | "Jigsaw" | "Sliding";
  xpValue: number;
  unlockedAt?: number;
}

export interface StudioTheme {
  id: string;
  name: string;
  description: string;
  bgClass: string;
  cardClass: string;
  accentHex: string;
  isHighContrast?: boolean;
}

export interface BuildTargetConfig {
  targetType: "platform" | "standalone_game";
  gameId?: string; // e.g. '2048' when targetType is 'standalone_game'
  versionName: string;
  versionCode: number;
  packageId: string;
  appName: string;
  minSdk: number; // Default 26
  targetSdk: number; // Default 35 (Android 15 API Level 35)
  exportFormat: "aab" | "apk"; // Android App Bundle (AAB) default for Play Store
  includeAds: boolean;
  includeCloudSync: boolean;
  enableGoogleUmp: boolean;
  enablePlayAppSigning: boolean;
}

export interface BuildExportManifest {
  config: BuildTargetConfig;
  androidManifestXml: string;
  buildGradleKts: string;
  capacitorConfigTs: string;
  pwaManifestJson: string;
  bundleSizeEstimateKb: number;
  treeShakingReport: string[];
  proguardRulesPro: string;
  createdAt: string;
}
