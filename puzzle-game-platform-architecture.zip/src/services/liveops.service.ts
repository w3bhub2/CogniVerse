export type IncidentSeverity = "P0" | "P1" | "P2" | "P3" | "P4";

export interface IncidentStatus {
  id: string;
  severity: IncidentSeverity;
  title: string;
  description: string;
  isActive: boolean;
  resolvedAt?: string;
}

export interface SeasonInfo {
  seasonNumber: number;
  seasonName: string;
  startDate: string;
  endDate: string;
  daysRemaining: number;
  rewardPoolCoins: number;
  topBadgeName: string;
}

class LiveOpsService {
  private activeIncidents: IncidentStatus[] = [];
  private currentSeason: SeasonInfo = {
    seasonNumber: 1,
    seasonName: "Season 1: Genesis of the Studio",
    startDate: new Date().toISOString().slice(0, 10),
    endDate: new Date(Date.now() + 30 * 86400000).toISOString().slice(0, 10),
    daysRemaining: 24,
    rewardPoolCoins: 500,
    topBadgeName: "Monthly Master Trophy",
  };

  public getActiveIncidents(): IncidentStatus[] {
    return this.activeIncidents;
  }

  public getCurrentSeason(): SeasonInfo {
    return this.currentSeason;
  }

  public createIncident(
    severity: IncidentSeverity,
    title: string,
    description: string
  ): IncidentStatus {
    const item: IncidentStatus = {
      id: `inc_${Math.random().toString(36).substring(2, 8)}`,
      severity,
      title,
      description,
      isActive: true,
    };
    this.activeIncidents.unshift(item);
    return item;
  }

  public resolveIncident(id: string): void {
    const found = this.activeIncidents.find((i) => i.id === id);
    if (found) {
      found.isActive = false;
      found.resolvedAt = new Date().toLocaleTimeString();
    }
  }
}

export const liveOpsService = new LiveOpsService();
