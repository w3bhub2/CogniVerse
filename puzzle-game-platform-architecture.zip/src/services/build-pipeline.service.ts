import { BuildTargetConfig, BuildExportManifest } from "./types";
import { getGameModuleById, PHASE_1_MODULES } from "@/engine/registry";

export class BuildPipelineService {
  public generateManifest(config: BuildTargetConfig): BuildExportManifest {
    const isPlatform = config.targetType === "platform";
    const gameId = config.gameId;
    const selectedModule = gameId ? getGameModuleById(gameId) : undefined;

    const appName = isPlatform
      ? "Puzzle Platform"
      : selectedModule?.name || config.appName || "Puzzle Game";

    const packageId = isPlatform
      ? "com.puzzleplatform.app"
      : selectedModule?.packageId || config.packageId || "com.puzzleplatform.games.puzzle";

    const targetSdk = config.targetSdk || 35; // Default API Level 35 Target
    const minSdk = config.minSdk || 26; // Default Android 8.0 Min SDK
    const exportFormat = config.exportFormat || "aab"; // Default Android App Bundle (AAB)

    // Generate AndroidManifest.xml with Google UMP and AdMob metadata
    const androidManifestXml = `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="${packageId}">

    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.VIBRATE" />
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />

    <application
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:label="${appName}"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:supportsRtl="true"
        android:theme="@style/Theme.AppCompat.NoActionBar">

        <meta-data
            android:name="com.google.android.gms.ads.APPLICATION_ID"
            android:value="ca-app-pub-3940256099942544~3347511713"/>
        <meta-data
            android:name="com.google.android.gms.ads.flag.OPTIMIZE_INITIALIZATION"
            android:value="true"/>

        <activity
            android:name=".MainActivity"
            android:configChanges="orientation|keyboardHidden|keyboard|screenSize|locale|smallestScreenSize|screenLayout|uiMode"
            android:exported="true"
            android:launchMode="singleTask"
            android:screenOrientation="portrait">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>
</manifest>`;

    // Generate build.gradle.kts supporting API Level 35, AAB bundleRelease, and Google Play App Signing
    const buildGradleKts = `plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("com.google.gms.google-services")
    id("com.google.firebase.crashlytics")
}

android {
    namespace = "${packageId}"
    compileSdk = ${targetSdk}

    defaultConfig {
        applicationId = "${packageId}"
        minSdk = ${minSdk}
        targetSdk = ${targetSdk}
        versionCode = ${config.versionCode || 1}
        versionName = "${config.versionName || "1.0.0"}"
        
        buildConfigField("String", "TARGET_MODULE_ID", "\"${isPlatform ? "ALL_GAMES" : gameId}\"")
        buildConfigField("Boolean", "IS_STANDALONE", "${!isPlatform}")
        buildConfigField("String", "EXPORT_FORMAT", "\"${exportFormat.toUpperCase()}\"")
    }

    signingConfigs {
        create("release") {
            // Configured for Google Play App Signing (upload key -> app signing key)
            storeFile = file("studio-upload-keystore.jks")
            storePassword = System.getenv("KEYSTORE_PASSWORD") ?: "android"
            keyAlias = System.getenv("KEY_ALIAS") ?: "upload"
            keyPassword = System.getenv("KEY_PASSWORD") ?: "android"
        }
    }

    buildTypes {
        release {
            signingConfig = signingConfigs.getByName("release")
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    bundle {
        language {
            enableSplit = true
        }
        density {
            enableSplit = true
        }
        abi {
            enableSplit = true
        }
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("com.google.android.ump:user-messaging-platform:2.2.0")
    implementation(platform("com.google.firebase:firebase-bom:33.1.2"))
    implementation("com.google.firebase:firebase-analytics")
    implementation("com.google.firebase:firebase-crashlytics")
    implementation("com.google.firebase:firebase-config")
}`;

    // Generate capacitor.config.ts
    const capacitorConfigTs = `import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: '${packageId}',
  appName: '${appName}',
  webDir: 'out',
  server: {
    androidScheme: 'https'
  },
  plugins: {
    SplashScreen: {
      launchShowDuration: 1500,
      backgroundColor: '#0F172A',
      showSpinner: false
    }
  }
};

export default config;`;

    // Generate PWA manifest.webmanifest
    const pwaManifestJson = JSON.stringify(
      {
        name: appName,
        short_name: appName,
        start_url: isPlatform ? "/" : `/?game=${gameId}`,
        display: "standalone",
        background_color: "#0F172A",
        theme_color: "#0F172A",
        icons: [
          {
            src: "/icons/icon-192.png",
            sizes: "192x192",
            type: "image/png",
          },
          {
            src: "/icons/icon-512.png",
            sizes: "512x512",
            type: "image/png",
          },
        ],
      },
      null,
      2
    );

    const proguardRulesPro = `# Studio Proguard & R8 Optimization Rules for ${config.packageId}
-keep class com.puzzleplatform.** { *; }
-keepattributes *Annotation*,Signature,InnerClasses,EnclosingMethod
-dontwarn javax.annotation.**
-keepclassmembers class * {
    @androidx.annotation.Keep *;
}
-assumenosideeffects class android.util.Log {
    public static boolean isLoggable(java.lang.String, int);
    public static int v(...);
    public static int d(...);
}`;

    // Tree-shaking and bundle size estimation
    const treeShakingReport: string[] = [];
    let bundleSizeEstimateKb = 1850; // Core Next.js + Engine + Tailwind base

    if (isPlatform) {
      treeShakingReport.push("• Reusable Core Engine (src/engine/*): INCLUDED");
      treeShakingReport.push("• Platform Services (src/services/*): INCLUDED");
      treeShakingReport.push("• All 6 Active Phase 1 Game Modules: INCLUDED");
      treeShakingReport.push("• Full Studio 50-Game Roadmap Explorer: INCLUDED");
      treeShakingReport.push("• Target API Level 35 (Android 15) + AAB bundleRelease: ENABLED");
      bundleSizeEstimateKb += 650;
    } else if (selectedModule) {
      treeShakingReport.push("• Reusable Core Engine (src/engine/*): INCLUDED");
      treeShakingReport.push("• Platform Services (src/services/*): INCLUDED");
      treeShakingReport.push(
        `• Target Game Module [${selectedModule.name}] (src/games/${selectedModule.id}/*): INCLUDED`
      );

      const excludedGames = Object.keys(PHASE_1_MODULES).filter(
        (id) => id !== selectedModule.id
      );
      treeShakingReport.push(
        `• Tree-Shaking Excluded Modules: ${excludedGames.join(", ")} (-480 KB)`
      );
      treeShakingReport.push("• Target API Level 35 (Android 15) + AAB bundleRelease: ENABLED");
      bundleSizeEstimateKb += 120;
    }

    return {
      config,
      androidManifestXml,
      buildGradleKts,
      capacitorConfigTs,
      pwaManifestJson,
      bundleSizeEstimateKb,
      treeShakingReport,
      proguardRulesPro,
      createdAt: new Date().toISOString(),
    };
  }

  public async logBuildManifestToDb(manifest: BuildExportManifest): Promise<void> {
    if (typeof window === "undefined") return;
    try {
      await fetch("/api/build-export", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(manifest),
      });
    } catch (e) {
      console.warn("Failed to log build manifest to backend:", e);
    }
  }
}

export const buildPipelineService = new BuildPipelineService();
