import { EngineSnapshot } from "@/engine/types";
import { eventBus } from "@/engine/events";

const STORAGE_PREFIX = "puzzle_platform_v1_";
const USER_ID_KEY = `${STORAGE_PREFIX}user_id`;

export interface SaveConflictData<T = any> {
  gameId: string;
  localSnapshot: EngineSnapshot<T>;
  cloudSnapshot: EngineSnapshot<T>;
  localTimestamp: number;
  cloudTimestamp: number;
}

export class StorageService {
  private userId: string = "local-player";
  private onConflictCallback?: (conflict: SaveConflictData) => void;

  constructor() {
    if (typeof window !== "undefined") {
      const stored = localStorage.getItem(USER_ID_KEY);
      if (stored) {
        this.userId = stored;
      } else {
        const generated = `player-${Math.random().toString(36).substring(2, 10)}`;
        localStorage.setItem(USER_ID_KEY, generated);
        this.userId = generated;
      }

      eventBus.subscribe("GAME_WON", (payload) => {
        this.syncCloudScore(payload.gameId, payload.data?.score || 0);
      });
      eventBus.subscribe("GAME_OVER", (payload) => {
        this.syncCloudScore(payload.gameId, payload.data?.score || 0);
      });
    }
  }

  public setConflictCallback(cb: (conflict: SaveConflictData) => void): void {
    this.onConflictCallback = cb;
  }

  public getUserId(): string {
    return this.userId;
  }

  public saveGameSnapshot<T = any>(gameId: string, snapshot: EngineSnapshot<T>): void {
    if (typeof window === "undefined") return;
    const key = `${STORAGE_PREFIX}save_${gameId}`;
    try {
      const payload = {
        snapshot,
        timestamp: Date.now(),
        checksum: this.computeChecksum(snapshot),
      };
      localStorage.setItem(key, JSON.stringify(payload));
    } catch (e) {
      console.warn("Failed to save snapshot locally:", e);
    }
  }

  public loadGameSnapshot<T = any>(gameId: string): EngineSnapshot<T> | null {
    if (typeof window === "undefined") return null;
    const key = `${STORAGE_PREFIX}save_${gameId}`;
    try {
      const item = localStorage.getItem(key);
      if (!item) return null;
      const parsed = JSON.parse(item);
      if (!parsed || !parsed.snapshot) return null;

      // Verify checksum
      const expectedChecksum = this.computeChecksum(parsed.snapshot);
      if (parsed.checksum !== expectedChecksum) {
        console.warn(`Save checksum mismatch for game ${gameId}. Resetting.`);
        return null;
      }
      return parsed.snapshot as EngineSnapshot<T>;
    } catch (e) {
      console.warn("Failed to load local snapshot:", e);
      return null;
    }
  }

  public async syncCloudScore(gameId: string, score: number): Promise<void> {
    if (typeof window === "undefined") return;
    try {
      const res = await fetch("/api/saves", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-Studio-API-Version": "1.0.0",
        },
        body: JSON.stringify({
          userId: this.userId,
          gameId,
          score,
          timestamp: Date.now(),
        }),
      });
      if (res.ok) {
        // Cloud sync successful
      }
    } catch (e) {
      console.warn("Cloud save sync failed:", e);
    }
  }

  public triggerConflictResolution<T = any>(conflict: SaveConflictData<T>): void {
    if (this.onConflictCallback) {
      this.onConflictCallback(conflict);
    }
  }

  public resolveSaveConflict<T = any>(
    gameId: string,
    chosenSnapshot: EngineSnapshot<T>
  ): void {
    this.saveGameSnapshot(gameId, chosenSnapshot);
    this.syncCloudScore(gameId, chosenSnapshot.score);
  }

  private computeChecksum(data: any): string {
    const str = JSON.stringify(data || {});
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      const char = str.charCodeAt(i);
      hash = (hash << 5) - hash + char;
      hash |= 0;
    }
    return `chk_${Math.abs(hash)}`;
  }
}

export const storageService = new StorageService();
