export interface RemoteConfigDefaults {
  enable_rewarded_hint_bonus: boolean;
  daily_challenge_coin_reward: number;
  season_duration_days: number;
  ad_free_iap_price_usd: number;
  min_supported_app_version: string;
  enable_ump_gdpr_dialog: boolean;
}

export type UmpConsentStatus = "UNKNOWN" | "REQUIRED" | "NOT_REQUIRED" | "OBTAINED" | "DENIED";

const DEFAULT_REMOTE_CONFIG: RemoteConfigDefaults = {
  enable_rewarded_hint_bonus: true,
  daily_challenge_coin_reward: 150,
  season_duration_days: 30,
  ad_free_iap_price_usd: 1.99,
  min_supported_app_version: "1.0.0",
  enable_ump_gdpr_dialog: true,
};

class FirebaseUmpService {
  private remoteConfig: RemoteConfigDefaults = { ...DEFAULT_REMOTE_CONFIG };
  private consentStatus: UmpConsentStatus = "UNKNOWN";
  private listeners: Set<() => void> = new Set();

  constructor() {
    if (typeof window !== "undefined") {
      this.loadLocalConsent();
      this.fetchRemoteConfigOfflineFirst();
    }
  }

  // Google UMP Consent Protocol
  public getConsentStatus(): UmpConsentStatus {
    return this.consentStatus;
  }

  public async requestUmpConsentDialog(): Promise<UmpConsentStatus> {
    // In Capacitor Android/iOS, this bridges to User Messaging Platform SDK
    // In web PWA, simulates GDPR/CCPA consent dialog
    return new Promise((resolve) => {
      setTimeout(() => {
        this.consentStatus = "OBTAINED";
        if (typeof window !== "undefined") {
          localStorage.setItem("studio_ump_consent_status", "OBTAINED");
        }
        this.notify();
        resolve("OBTAINED");
      }, 500);
    });
  }

  // Firebase Remote Config (Offline-First with fallback)
  public getRemoteConfig(): RemoteConfigDefaults {
    return this.remoteConfig;
  }

  public getParam<K extends keyof RemoteConfigDefaults>(key: K): RemoteConfigDefaults[K] {
    return this.remoteConfig[key] ?? DEFAULT_REMOTE_CONFIG[key];
  }

  // Firebase Analytics / Crashlytics Telemetry Bridge
  public logCrashlyticsException(error: Error, context?: Record<string, any>): void {
    console.error("[Firebase Crashlytics Bridge] Exception logged:", error.message, context);
  }

  public subscribe(cb: () => void): () => void {
    this.listeners.add(cb);
    return () => this.listeners.delete(cb);
  }

  private loadLocalConsent(): void {
    try {
      const stored = localStorage.getItem("studio_ump_consent_status");
      if (stored && ["OBTAINED", "DENIED", "NOT_REQUIRED"].includes(stored)) {
        this.consentStatus = stored as UmpConsentStatus;
      }
    } catch (e) {
      // Ignore
    }
  }

  private async fetchRemoteConfigOfflineFirst(): Promise<void> {
    try {
      // In mobile Capacitor app, fetch from Firebase Remote Config SDK
      // Offline fallback defaults are immediately available from DEFAULT_REMOTE_CONFIG
      const stored = localStorage.getItem("studio_remote_config_cache");
      if (stored) {
        this.remoteConfig = { ...DEFAULT_REMOTE_CONFIG, ...JSON.parse(stored) };
      }
    } catch (e) {
      // Offline fallback active
    }
  }

  private notify(): void {
    this.listeners.forEach((cb) => cb());
  }
}

export const firebaseUmpService = new FirebaseUmpService();
