import { eventBus } from "@/engine/events";

const AD_FREE_KEY = "puzzle_platform_ad_free_iap";
const COINS_KEY = "puzzle_platform_coins";

class MonetizationService {
  private adFree: boolean = false;
  private coins: number = 500;
  private listeners: Set<() => void> = new Set();

  constructor() {
    if (typeof window !== "undefined") {
      this.adFree = localStorage.getItem(AD_FREE_KEY) === "true";
      const storedCoins = localStorage.getItem(COINS_KEY);
      if (storedCoins) {
        this.coins = parseInt(storedCoins, 10) || 500;
      }
    }
  }

  public isAdFree(): boolean {
    return this.adFree;
  }

  public getCoins(): number {
    return this.coins;
  }

  public subscribe(cb: () => void): () => void {
    this.listeners.add(cb);
    return () => this.listeners.delete(cb);
  }

  public setAdFree(adFree: boolean): void {
    this.adFree = adFree;
    if (typeof window !== "undefined") {
      localStorage.setItem(AD_FREE_KEY, adFree ? "true" : "false");
    }
    this.notify();
  }

  public addCoins(amount: number): void {
    this.coins = Math.max(0, this.coins + amount);
    if (typeof window !== "undefined") {
      localStorage.setItem(COINS_KEY, String(this.coins));
    }
    this.notify();
  }

  public async simulateRewardedAd(onReward: () => void): Promise<boolean> {
    // Return true when user watches simulated short ad
    return new Promise((resolve) => {
      setTimeout(() => {
        this.addCoins(50);
        onReward();
        resolve(true);
      }, 800);
    });
  }

  private notify(): void {
    this.listeners.forEach((cb) => cb());
  }
}

export const monetizationService = new MonetizationService();
