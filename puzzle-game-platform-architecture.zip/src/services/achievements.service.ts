import { AchievementItem } from "./types";
import { eventBus } from "@/engine/events";
import { storageService } from "./storage.service";

const ACHIEVEMENTS_KEY = "puzzle_platform_achievements";

export const STUDIO_ACHIEVEMENTS: AchievementItem[] = [
  {
    id: "first-victory",
    title: "First Victory",
    description: "Win your very first puzzle game on the Studio Platform.",
    iconName: "Trophy",
    category: "General",
    xpValue: 100,
  },
  {
    id: "no-hints-needed",
    title: "Pure Intellect",
    description: "Win any puzzle without requesting a single hint.",
    iconName: "Sparkles",
    category: "General",
    xpValue: 250,
  },
  {
    id: "master-2048",
    title: "2048 Ascendant",
    description: "Reach the legendary 2048 tile in the 2048 puzzle.",
    iconName: "Grid3x3",
    category: "2048",
    xpValue: 300,
  },
  {
    id: "sudoku-perfection",
    title: "Sudoku Perfectionist",
    description: "Complete a Sudoku grid with zero mistakes recorded.",
    iconName: "Hash",
    category: "Sudoku",
    xpValue: 250,
  },
  {
    id: "crossword-linguist",
    title: "Word Laureate",
    description: "Solve a Mini Crossword puzzle in under 90 seconds.",
    iconName: "BookOpen",
    category: "Crossword",
    xpValue: 200,
  },
  {
    id: "word-sleuth",
    title: "Eagle Eye",
    description: "Find all hidden words in a Word Search grid.",
    iconName: "Search",
    category: "Word Search",
    xpValue: 150,
  },
  {
    id: "jigsaw-artisan",
    title: "Restoration Artisan",
    description: "Assemble a Jigsaw puzzle with every tile in perfect order.",
    iconName: "Puzzle",
    category: "Jigsaw",
    xpValue: 200,
  },
  {
    id: "sliding-virtuoso",
    title: "Sliding Virtuoso",
    description: "Solve the 15-Puzzle sliding grid without resetting.",
    iconName: "LayoutGrid",
    category: "Sliding",
    xpValue: 200,
  },
];

class AchievementsService {
  private unlockedIds: Set<string> = new Set();
  private onUnlockCallback?: (achievement: AchievementItem) => void;

  constructor() {
    if (typeof window !== "undefined") {
      this.loadLocal();
      this.bindEventListeners();
    }
  }

  public setUnlockCallback(cb: (achievement: AchievementItem) => void): void {
    this.onUnlockCallback = cb;
  }

  public getAchievements(): Array<AchievementItem & { isUnlocked: boolean }> {
    return STUDIO_ACHIEVEMENTS.map((a) => ({
      ...a,
      isUnlocked: this.unlockedIds.has(a.id),
    }));
  }

  public isUnlocked(id: string): boolean {
    return this.unlockedIds.has(id);
  }

  public unlock(id: string): void {
    if (this.unlockedIds.has(id)) return;
    const item = STUDIO_ACHIEVEMENTS.find((a) => a.id === id);
    if (!item) return;

    this.unlockedIds.add(id);
    this.saveLocal();

    eventBus.emit("ACHIEVEMENT_UNLOCKED", item.category, {
      id: item.id,
      title: item.title,
      xpValue: item.xpValue,
    });

    if (this.onUnlockCallback) {
      this.onUnlockCallback(item);
    }

    this.syncCloudAchievement(id);
  }

  private bindEventListeners(): void {
    eventBus.subscribe("GAME_WON", (payload) => {
      this.unlock("first-victory");

      if (payload.gameId === "2048") {
        this.unlock("master-2048");
      } else if (payload.gameId === "sudoku") {
        this.unlock("sudoku-perfection");
      } else if (payload.gameId === "crossword") {
        this.unlock("crossword-linguist");
      } else if (payload.gameId === "word-search") {
        this.unlock("word-sleuth");
      } else if (payload.gameId === "jigsaw") {
        this.unlock("jigsaw-artisan");
      } else if (payload.gameId === "sliding-puzzle") {
        this.unlock("sliding-virtuoso");
      }
    });
  }

  private loadLocal(): void {
    try {
      const stored = localStorage.getItem(ACHIEVEMENTS_KEY);
      if (stored) {
        const arr = JSON.parse(stored);
        if (Array.isArray(arr)) {
          arr.forEach((id) => this.unlockedIds.add(id));
        }
      }
    } catch (e) {
      // Ignore
    }
  }

  private saveLocal(): void {
    try {
      localStorage.setItem(
        ACHIEVEMENTS_KEY,
        JSON.stringify(Array.from(this.unlockedIds))
      );
    } catch (e) {
      // Ignore
    }
  }

  private async syncCloudAchievement(achievementId: string): Promise<void> {
    try {
      await fetch("/api/achievements", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          userId: storageService.getUserId(),
          achievementId,
        }),
      });
    } catch (e) {
      console.warn("Cloud achievement sync failed:", e);
    }
  }
}

export const achievementsService = new AchievementsService();
