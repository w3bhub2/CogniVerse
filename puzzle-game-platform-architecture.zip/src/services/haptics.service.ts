import { HapticPattern } from "./types";
import { eventBus } from "@/engine/events";

class HapticsService {
  private enabled: boolean = true;
  private lastPulse: number = 0;

  constructor() {
    if (typeof window !== "undefined") {
      eventBus.subscribe("HAPTIC_PULSE", (payload) => {
        const pattern = payload.data?.pattern as HapticPattern;
        if (pattern) {
          this.vibrate(pattern);
        }
      });
    }
  }

  public setEnabled(enabled: boolean): void {
    this.enabled = enabled;
  }

  public isEnabled(): boolean {
    return this.enabled;
  }

  public vibrate(pattern: HapticPattern): void {
    if (!this.enabled || typeof window === "undefined") return;
    const now = Date.now();
    if (now - this.lastPulse < 40) return; // Debounce fast pulses
    this.lastPulse = now;

    if ("vibrate" in navigator && typeof navigator.vibrate === "function") {
      try {
        switch (pattern) {
          case "light":
            navigator.vibrate(10);
            break;
          case "medium":
            navigator.vibrate(25);
            break;
          case "heavy":
            navigator.vibrate(40);
            break;
          case "success":
            navigator.vibrate([20, 40, 30]);
            break;
          case "error":
            navigator.vibrate([40, 50, 40]);
            break;
        }
      } catch (err) {
        // Ignore unsupported devices
      }
    }
  }
}

export const hapticsService = new HapticsService();
