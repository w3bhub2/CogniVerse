import { StudioTheme } from "./types";

const THEME_STORAGE_KEY = "puzzle_platform_active_theme";

export const STUDIO_THEMES: StudioTheme[] = [
  {
    id: "midnight-slate",
    name: "Midnight Slate",
    description: "Sleek dark mode with slate grays and sapphire blue accents.",
    bgClass: "bg-slate-950 text-slate-100",
    cardClass: "bg-slate-900 border-slate-800 text-slate-100",
    accentHex: "#3B82F6",
  },
  {
    id: "cyberpunk-neon",
    name: "Cyberpunk Neon",
    description: "High-octane dark theme with neon magenta and cyan borders.",
    bgClass: "bg-zinc-950 text-zinc-100",
    cardClass: "bg-zinc-900 border-pink-500/40 text-zinc-100 shadow-[0_0_15px_rgba(236,72,153,0.15)]",
    accentHex: "#EC4899",
  },
  {
    id: "emerald-studio",
    name: "Emerald Studio",
    description: "Professional gaming studio aesthetic with deep forest tones and gold highlights.",
    bgClass: "bg-emerald-950 text-emerald-50",
    cardClass: "bg-emerald-900/80 border-emerald-700/60 text-emerald-50",
    accentHex: "#10B981",
  },
  {
    id: "classic-wood",
    name: "Classic Wood",
    description: "Warm, traditional table puzzle feel with amber and walnut palettes.",
    bgClass: "bg-amber-950 text-amber-50",
    cardClass: "bg-amber-900/70 border-amber-800 text-amber-50",
    accentHex: "#F59E0B",
  },
  {
    id: "high-contrast",
    name: "High Contrast (a11y)",
    description: "Maximum contrast accessibility mode with pure black, pure white, and yellow focus rings.",
    bgClass: "bg-black text-white",
    cardClass: "bg-zinc-900 border-2 border-yellow-400 text-white",
    accentHex: "#FACC15",
    isHighContrast: true,
  },
];

class ThemesService {
  private activeThemeId: string = "midnight-slate";
  private listeners: Set<(theme: StudioTheme) => void> = new Set();

  constructor() {
    if (typeof window !== "undefined") {
      const saved = localStorage.getItem(THEME_STORAGE_KEY);
      if (saved && STUDIO_THEMES.some((t) => t.id === saved)) {
        this.activeThemeId = saved;
      }
    }
  }

  public getActiveTheme(): StudioTheme {
    return (
      STUDIO_THEMES.find((t) => t.id === this.activeThemeId) || STUDIO_THEMES[0]
    );
  }

  public getAllThemes(): StudioTheme[] {
    return STUDIO_THEMES;
  }

  public setTheme(themeId: string): void {
    const found = STUDIO_THEMES.find((t) => t.id === themeId);
    if (!found) return;
    this.activeThemeId = themeId;
    if (typeof window !== "undefined") {
      localStorage.setItem(THEME_STORAGE_KEY, themeId);
    }
    this.listeners.forEach((cb) => cb(found));
  }

  public subscribe(cb: (theme: StudioTheme) => void): () => void {
    this.listeners.add(cb);
    return () => this.listeners.delete(cb);
  }
}

export const themesService = new ThemesService();
