import { EngineSnapshot } from "@/engine/types";

export interface SecurityAuditResult {
  isValid: boolean;
  reason?: string;
  signature: string;
  riskScore: number; // 0 (clean) to 100 (high risk cheater)
}

class SecurityService {
  private secretSalt: string = "studio_puzzle_hmac_v1_9921_secret";

  public validateScoreSubmission(
    gameId: string,
    score: number,
    timeSeconds: number,
    moves: number
  ): SecurityAuditResult {
    let riskScore = 0;
    const reasons: string[] = [];

    // 1. Check impossible speedruns (e.g. 2048 won in 1 second with 50 moves)
    if (timeSeconds < 3 && moves > 10) {
      riskScore += 60;
      reasons.push("Impossible move speed detected (bot/macro threshold exceeded).");
    }

    // 2. Check negative values
    if (score < 0 || timeSeconds < 0 || moves < 0) {
      riskScore += 90;
      reasons.push("Invalid negative metric detected in payload.");
    }

    // 3. Check game specific bounds
    if (gameId === "sudoku" && score > 15000) {
      riskScore += 50;
      reasons.push("Sudoku score exceeds mathematical theoretical maximum.");
    } else if (gameId === "2048" && moves === 0 && score > 0) {
      riskScore += 80;
      reasons.push("Score recorded without any moves registered.");
    }

    const isValid = riskScore < 70;
    const signature = this.generateHmacSignature(gameId, score, timeSeconds, moves);

    return {
      isValid,
      reason: reasons.length > 0 ? reasons.join(" ") : "Clean score submission validated.",
      signature,
      riskScore,
    };
  }

  public generateHmacSignature(
    gameId: string,
    score: number,
    timeSeconds: number,
    moves: number
  ): string {
    const raw = `${gameId}:${score}:${timeSeconds}:${moves}:${this.secretSalt}`;
    let hash = 5381;
    for (let i = 0; i < raw.length; i++) {
      hash = (hash * 33) ^ raw.charCodeAt(i);
    }
    return `sec_hmac_${Math.abs(hash).toString(16)}`;
  }

  public verifySnapshotIntegrity<T>(snapshot: EngineSnapshot<T>, expectedSignature?: string): boolean {
    if (!snapshot || !snapshot.gameId) return false;
    if (!expectedSignature) return true;
    const computed = this.generateHmacSignature(
      snapshot.gameId,
      snapshot.score,
      snapshot.elapsedSeconds,
      snapshot.movesCount
    );
    return computed === expectedSignature;
  }
}

export const securityService = new SecurityService();
