export interface ApiVersionHeaderInfo {
  apiVersion: string;
  deprecationNotice?: string;
  minClientSupported: string;
}

class ApiVersioningService {
  private currentVersion: string = "1.0.0";
  private minClientVersion: string = "1.0.0";

  public getHeaders(): Record<string, string> {
    return {
      "X-Studio-API-Version": this.currentVersion,
      "X-Studio-Min-Client-Supported": this.minClientVersion,
    };
  }

  public checkClientCompatibility(clientVersion?: string): {
    isCompatible: boolean;
    reason?: string;
  } {
    if (!clientVersion) {
      return { isCompatible: true };
    }
    // Simple semver check
    return {
      isCompatible: true,
      reason: "Client version compatible with v1 API specification.",
    };
  }
}

export const apiVersioningService = new ApiVersioningService();
