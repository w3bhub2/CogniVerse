export type StudioFeatureFlagKey =
  | "KILL_SWITCH_ALL_IAP"
  | "KILL_SWITCH_LIVEOPS"
  | "KILL_SWITCH_GAME_2048"
  | "KILL_SWITCH_GAME_SUDOKU"
  | "KILL_SWITCH_GAME_CROSSWORD"
  | "KILL_SWITCH_GAME_WORD_SEARCH"
  | "KILL_SWITCH_GAME_JIGSAW"
  | "KILL_SWITCH_GAME_SLIDING"
  | "ENABLE_V2_API_HEADERS"
  | "ENABLE_HIGH_FPS_MODE";

export interface FeatureFlagItem {
  key: StudioFeatureFlagKey;
  label: string;
  description: string;
  isEnabled: boolean;
  isKillSwitch?: boolean;
}

const STORAGE_KEY = "studio_feature_flags_v1";

const DEFAULT_FLAGS: FeatureFlagItem[] = [
  {
    key: "KILL_SWITCH_ALL_IAP",
    label: "Emergency Kill Switch: All In-App Purchases",
    description: "Disables all IAP checkout flows globally if an exploit or billing outage occurs.",
    isEnabled: false,
    isKillSwitch: true,
  },
  {
    key: "KILL_SWITCH_LIVEOPS",
    label: "Emergency Kill Switch: LiveOps & Daily Seeds",
    description: "Temporarily disables Daily Challenges during server maintenance.",
    isEnabled: false,
    isKillSwitch: true,
  },
  {
    key: "KILL_SWITCH_GAME_2048",
    label: "Kill Switch: 2048 Module",
    description: "Disables launch of 2048 puzzle if a critical solver vulnerability is found.",
    isEnabled: false,
    isKillSwitch: true,
  },
  {
    key: "ENABLE_V2_API_HEADERS",
    label: "API Versioning v2 Header Migration",
    description: "Broadcasts v2 deprecation headers to older clients while maintaining v1 compatibility.",
    isEnabled: true,
  },
  {
    key: "ENABLE_HIGH_FPS_MODE",
    label: "60 FPS Performance Budget Mode",
    description: "Forces CSS GPU hardware acceleration and caps confetti particles on low-end devices.",
    isEnabled: true,
  },
];

class FeatureFlagsService {
  private flags: Map<StudioFeatureFlagKey, FeatureFlagItem> = new Map();
  private listeners: Set<() => void> = new Set();

  constructor() {
    DEFAULT_FLAGS.forEach((f) => this.flags.set(f.key, { ...f }));
    if (typeof window !== "undefined") {
      this.loadFromStorage();
    }
  }

  public getFlag(key: StudioFeatureFlagKey): boolean {
    return Boolean(this.flags.get(key)?.isEnabled);
  }

  public getAllFlags(): FeatureFlagItem[] {
    return Array.from(this.flags.values());
  }

  public setFlag(key: StudioFeatureFlagKey, enabled: boolean): void {
    const item = this.flags.get(key);
    if (item) {
      item.isEnabled = enabled;
      this.saveToStorage();
      this.notify();
    }
  }

  public subscribe(cb: () => void): () => void {
    this.listeners.add(cb);
    return () => this.listeners.delete(cb);
  }

  private loadFromStorage(): void {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        const parsed: Record<string, boolean> = JSON.parse(stored);
        Object.entries(parsed).forEach(([k, val]) => {
          const item = this.flags.get(k as StudioFeatureFlagKey);
          if (item) {
            item.isEnabled = Boolean(val);
          }
        });
      }
    } catch (e) {
      // Ignore
    }
  }

  private saveToStorage(): void {
    try {
      const mapObj: Record<string, boolean> = {};
      this.flags.forEach((v, k) => {
        mapObj[k] = v.isEnabled;
      });
      localStorage.getItem(STORAGE_KEY);
      localStorage.setItem(STORAGE_KEY, JSON.stringify(mapObj));
    } catch (e) {
      // Ignore
    }
  }

  private notify(): void {
    this.listeners.forEach((cb) => cb());
  }
}

export const featureFlagsService = new FeatureFlagsService();
