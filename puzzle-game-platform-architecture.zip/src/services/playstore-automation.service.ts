import { BuildTargetConfig } from "./types";
import { getGameModuleById } from "@/engine/registry";

export interface GooglePlayStoreListing {
  packageId: string;
  appName: string;
  shortDescription: string;
  fullDescription: string;
  category: string;
  contentRatingDefaults: {
    violence: boolean;
    blood: boolean;
    gambling: boolean;
    userInteraction: boolean;
    inAppPurchases: boolean;
  };
  dataSafetyManifestJson: string;
  privacyPolicyMarkdown: string;
  proguardRulesPro: string;
  automatedScreenshotSpecs: Array<{
    title: string;
    caption: string;
    deviceType: "phone_6_5" | "tablet_10";
    sceneName: string;
  }>;
}

class PlayStoreAutomationService {
  public generatePlayStoreListing(config: BuildTargetConfig): GooglePlayStoreListing {
    const isPlatform = config.targetType === "platform";
    const module = config.gameId ? getGameModuleById(config.gameId) : undefined;

    const appName = isPlatform
      ? "Puzzle Platform: 50+ Games"
      : `${module?.name || config.appName} - Brain Puzzle`;

    const shortDescription = isPlatform
      ? "Play 50+ casual brain puzzle games in one app or offline anytime!"
      : `${module?.description || "Classic logic puzzle challenge with daily brain exercises and hints!"}`;

    const fullDescription = isPlatform
      ? `Welcome to Puzzle Platform — the ultimate casual puzzle game studio ecosystem!

Why download 50 different apps when you can carry the entire studio in one lightweight package?
• Phase 1 Playable Games: 2048, Sudoku, Mini Crossword, Word Search, Jigsaw Puzzle, and 15-Puzzle Sliding Tiles!
• Offline Capable: Every game works 100% offline without needing Wi-Fi.
• Cross-Game Achievements & Story Mode: Progress through 5 Saga Chapters to unlock relics and earn daily challenge badges.
• Visual Studio Themes: Choose between Midnight Slate, Cyberpunk Neon, Classic Wood, Emerald Studio, or High Contrast Accessible mode.
• Zero Fluff & Pure Logic: Built with a deterministic studio engine, smart hint pathfinding, and zero unfair randomness.

Download today and challenge your intellect!`
      : `Master the legendary ${module?.name || "Puzzle"} game with studio-quality graphics, smooth swipe controls, and smart logical hints!

FEATURES:
• Classic & Daily Modes: Test your logic across Easy, Medium, and Hard difficulty tiers.
• Smart Hint & Undo Engine: Never get unfairly stuck — our intelligent solver shows you exact next-step guidance.
• Offline Play: Works anywhere without internet.
• Eye-Friendly Themes: Dark Mode, Cyberpunk Neon, Classic Wood, and High-Contrast modes included.
• Play Store Leaderboards & Badges: Track your high scores and earn exclusive trophies!`;

    const dataSafetyManifestJson = JSON.stringify(
      {
        schemaVersion: "2.1",
        appPackageId: config.packageId,
        dataCollection: {
          collectsPersonalData: false,
          collectsAnalytics: true,
          purposes: ["APP_FUNCTIONALITY", "ANALYTICS"],
          dataTypes: ["DEVICE_OR_OTHER_IDS", "APP_INTERACTIONS"],
          isEncryptedInTransit: true,
          canRequestDeletion: true,
        },
      },
      null,
      2
    );

    const privacyPolicyMarkdown = `# Privacy Policy for ${appName}

**Effective Date:** ${new Date().toISOString().slice(0, 10)}
**Package ID:** \`${config.packageId}\`

## 1. Overview
We respect your privacy. This application does **not** collect personally identifiable information (PII), names, email addresses, or location data.

## 2. Telemetry & Analytics
We collect anonymized gameplay statistics (such as puzzle completion times, hint usage, and score leaderboards) to improve puzzle difficulty calibration.

## 3. Offline Capabilities
All game state snapshots and progression data are stored locally on your device and optional cloud backups are encrypted in transit via standard HTTPS.

## 4. Contact Us
For support or deletion requests, contact \`studio-support@puzzleplatform.com\`.`;

    const proguardRulesPro = `# Studio Proguard & R8 Optimization Rules for ${config.packageId}
-keep class com.puzzleplatform.** { *; }
-keepattributes *Annotation*,Signature,InnerClasses,EnclosingMethod
-dontwarn javax.annotation.**
-keepclassmembers class * {
    @androidx.annotation.Keep *;
}
-assumenosideeffects class android.util.Log {
    public static boolean isLoggable(java.lang.String, int);
    public static int v(...);
    public static int d(...);
}`;

    const automatedScreenshotSpecs = [
      {
        title: "50+ Studio Puzzles in 1 App",
        caption: "Switch instantly between 2048, Sudoku, Crosswords, Jigsaw & more",
        deviceType: "phone_6_5" as const,
        sceneName: "studio_hub_grid",
      },
      {
        title: "Story Saga & Relics Mode",
        caption: "Progress through 5 chapters to unlock mystical golden trophies",
        deviceType: "phone_6_5" as const,
        sceneName: "campaign_saga_map",
      },
      {
        title: "Smart Logical Hints & Undo",
        caption: "Intelligent AI pathfinding explains exact next moves",
        deviceType: "phone_6_5" as const,
        sceneName: "game_active_hint",
      },
      {
        title: "6 Stunning Visual Themes",
        caption: "Midnight Slate, Cyberpunk Neon, Wood & Accessible High Contrast",
        deviceType: "phone_6_5" as const,
        sceneName: "theme_switcher",
      },
    ];

    return {
      packageId: config.packageId,
      appName,
      shortDescription,
      fullDescription,
      category: "GAME_PUZZLE",
      contentRatingDefaults: {
        violence: false,
        blood: false,
        gambling: false,
        userInteraction: false,
        inAppPurchases: config.includeAds,
      },
      dataSafetyManifestJson,
      privacyPolicyMarkdown,
      proguardRulesPro,
      automatedScreenshotSpecs,
    };
  }
}

export const playStoreAutomationService = new PlayStoreAutomationService();
