import { EngineEventName } from "@/engine/types";
import { eventBus } from "@/engine/events";
import { storageService } from "./storage.service";

export interface TelemetryLogEntry {
  id: string;
  eventName: string;
  gameId: string;
  timestamp: string;
  properties?: Record<string, any>;
}

class AnalyticsService {
  private localLogs: TelemetryLogEntry[] = [];
  private sessionStartTime: number = Date.now();

  constructor() {
    if (typeof window !== "undefined") {
      // Listen to all events on eventBus
      eventBus.subscribe("*", (payload) => {
        this.logEvent(
          payload.eventName,
          payload.gameId,
          payload.data
        );
      });
    }
  }

  public logEvent(
    eventName: string,
    gameId: string,
    properties?: Record<string, any>
  ): void {
    const entry: TelemetryLogEntry = {
      id: `tel_${Math.random().toString(36).substring(2, 9)}`,
      eventName,
      gameId,
      timestamp: new Date().toLocaleTimeString(),
      properties,
    };

    this.localLogs.unshift(entry);
    if (this.localLogs.length > 80) {
      this.localLogs.pop();
    }

    // Automatically send significant events to /api/analytics
    const importantEvents: EngineEventName[] = [
      "GAME_STARTED",
      "GAME_WON",
      "GAME_OVER",
      "HINT_USED",
      "ACHIEVEMENT_UNLOCKED",
    ];

    if (importantEvents.includes(eventName as EngineEventName)) {
      this.syncCloudAnalytics(entry);
    }
  }

  public getRecentLogs(limit: number = 25): TelemetryLogEntry[] {
    return this.localLogs.slice(0, limit);
  }

  public getSessionDurationSeconds(): number {
    return Math.floor((Date.now() - this.sessionStartTime) / 1000);
  }

  public getSessionSummary(): {
    totalEvents: number;
    durationSeconds: number;
    mostPlayedGame: string;
  } {
    const counts: Record<string, number> = {};
    this.localLogs.forEach((log) => {
      counts[log.gameId] = (counts[log.gameId] || 0) + 1;
    });

    let topGame = "None";
    let maxCount = 0;
    Object.entries(counts).forEach(([gameId, cnt]) => {
      if (cnt > maxCount) {
        maxCount = cnt;
        topGame = gameId;
      }
    });

    return {
      totalEvents: this.localLogs.length,
      durationSeconds: this.getSessionDurationSeconds(),
      mostPlayedGame: topGame,
    };
  }

  public clearLogs(): void {
    this.localLogs = [];
  }

  private async syncCloudAnalytics(entry: TelemetryLogEntry): Promise<void> {
    try {
      await fetch("/api/analytics", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          userId: storageService.getUserId(),
          eventName: entry.eventName,
          gameId: entry.gameId,
          properties: entry.properties,
        }),
      });
    } catch (e) {
      // Ignore network errors in offline mode
    }
  }
}

export const analyticsService = new AnalyticsService();
