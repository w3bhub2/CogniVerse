import { SoundEffectType } from "./types";
import { eventBus } from "@/engine/events";

class AudioService {
  private audioCtx: AudioContext | null = null;
  private muted: boolean = false;
  private volume: number = 0.4;

  constructor() {
    if (typeof window !== "undefined") {
      eventBus.subscribe("SOUND_EFFECT", (payload) => {
        const sound = payload.data?.sound as SoundEffectType;
        if (sound) {
          this.play(sound);
        }
      });

      const storedMute = localStorage.getItem("studio_audio_muted");
      if (storedMute === "true") {
        this.muted = true;
      }
      const storedVol = localStorage.getItem("studio_audio_volume");
      if (storedVol) {
        this.volume = Math.min(1, Math.max(0, parseFloat(storedVol)));
      }
    }
  }

  private initCtx(): AudioContext | null {
    if (typeof window === "undefined") return null;
    if (!this.audioCtx) {
      const AudioContextClass =
        window.AudioContext || (window as any).webkitAudioContext;
      if (AudioContextClass) {
        this.audioCtx = new AudioContextClass();
      }
    }
    if (this.audioCtx && this.audioCtx.state === "suspended") {
      this.audioCtx.resume().catch(() => {});
    }
    return this.audioCtx;
  }

  public setMuted(muted: boolean): void {
    this.muted = muted;
    if (typeof window !== "undefined") {
      localStorage.setItem("studio_audio_muted", muted ? "true" : "false");
    }
  }

  public isMuted(): boolean {
    return this.muted;
  }

  public setVolume(val: number): void {
    this.volume = Math.min(1, Math.max(0, val));
    if (typeof window !== "undefined") {
      localStorage.setItem("studio_audio_volume", String(this.volume));
    }
  }

  public getVolume(): number {
    return this.volume;
  }

  public play(type: SoundEffectType): void {
    if (this.muted || this.volume <= 0) return;
    const ctx = this.initCtx();
    if (!ctx) return;

    try {
      const now = ctx.currentTime;
      const masterGain = ctx.createGain();
      masterGain.gain.setValueAtTime(this.volume, now);
      masterGain.connect(ctx.destination);

      if (type === "click") {
        // Soft wooden tactile click
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = "triangle";
        osc.frequency.setValueAtTime(420, now);
        osc.frequency.exponentialRampToValueAtTime(140, now + 0.04);
        gain.gain.setValueAtTime(0.25, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.04);
        osc.connect(gain);
        gain.connect(masterGain);
        osc.start(now);
        osc.stop(now + 0.04);
      } else if (type === "move") {
        // Crisp sliding tile swoosh/click
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = "sine";
        osc.frequency.setValueAtTime(320, now);
        osc.frequency.exponentialRampToValueAtTime(210, now + 0.06);
        gain.gain.setValueAtTime(0.2, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.06);
        osc.connect(gain);
        gain.connect(masterGain);
        osc.start(now);
        osc.stop(now + 0.06);
      } else if (type === "merge") {
        // Pentatonic major second chime (C5 -> G5)
        const notes = [523.25, 783.99];
        notes.forEach((freq, idx) => {
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();
          osc.type = "sine";
          osc.frequency.setValueAtTime(freq, now + idx * 0.05);
          gain.gain.setValueAtTime(0.3, now + idx * 0.05);
          gain.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.05 + 0.15);
          osc.connect(gain);
          gain.connect(masterGain);
          osc.start(now + idx * 0.05);
          osc.stop(now + idx * 0.05 + 0.15);
        });
      } else if (type === "victory") {
        // Harp-like pentatonic victory chord arpeggio (C5, E5, G5, A5, C6)
        const notes = [523.25, 659.25, 783.99, 880.0, 1046.5];
        notes.forEach((freq, idx) => {
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();
          osc.type = "sine";
          const start = now + idx * 0.08;
          const dur = 0.35;
          osc.frequency.setValueAtTime(freq, start);
          gain.gain.setValueAtTime(0.35, start);
          gain.gain.exponentialRampToValueAtTime(0.001, start + dur);
          osc.connect(gain);
          gain.connect(masterGain);
          osc.start(start);
          osc.stop(start + dur);
        });
      } else if (type === "gameover") {
        // Melancholy downward chord
        const notes = [329.63, 293.66, 261.63]; // E4, D4, C4
        notes.forEach((freq, idx) => {
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();
          osc.type = "triangle";
          const start = now + idx * 0.12;
          const dur = 0.3;
          osc.frequency.setValueAtTime(freq, start);
          gain.gain.setValueAtTime(0.25, start);
          gain.gain.exponentialRampToValueAtTime(0.001, start + dur);
          osc.connect(gain);
          gain.connect(masterGain);
          osc.start(start);
          osc.stop(start + dur);
        });
      } else if (type === "hint") {
        // Magical shimmering chime
        const notes = [880.0, 1174.66]; // A5, D6
        notes.forEach((freq, idx) => {
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();
          osc.type = "sine";
          const start = now + idx * 0.06;
          osc.frequency.setValueAtTime(freq, start);
          gain.gain.setValueAtTime(0.2, start);
          gain.gain.exponentialRampToValueAtTime(0.001, start + 0.18);
          osc.connect(gain);
          gain.connect(masterGain);
          osc.start(start);
          osc.stop(start + 0.18);
        });
      } else if (type === "undo") {
        // Soft reverse slide
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = "sine";
        osc.frequency.setValueAtTime(240, now);
        osc.frequency.linearRampToValueAtTime(360, now + 0.08);
        gain.gain.setValueAtTime(0.2, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.08);
        osc.connect(gain);
        gain.connect(masterGain);
        osc.start(now);
        osc.stop(now + 0.08);
      } else if (type === "error") {
        // Subtle tactile error thud (non-harsh)
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = "sine";
        osc.frequency.setValueAtTime(160, now);
        osc.frequency.linearRampToValueAtTime(110, now + 0.12);
        gain.gain.setValueAtTime(0.3, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.12);
        osc.connect(gain);
        gain.connect(masterGain);
        osc.start(now);
        osc.stop(now + 0.12);
      }
    } catch (e) {
      console.warn("Audio playback failed:", e);
    }
  }
}

export const audioService = new AudioService();
