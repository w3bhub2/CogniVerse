import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "Puzzle Platform Studio • 50+ Casual Puzzle Games Ecosystem",
  description:
    "Commercial studio-quality Android puzzle game ecosystem. One reusable engine powering 50+ independent Play Store applications and the unified Puzzle Platform app.",
  keywords: [
    "Puzzle Platform",
    "2048",
    "Sudoku",
    "Crossword",
    "Word Search",
    "Jigsaw Puzzle",
    "Sliding Puzzle",
    "Android Game Engine",
    "Next.js",
    "PostgreSQL",
  ],
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" className="dark">
      <body className="bg-slate-950 text-slate-100 antialiased selection:bg-indigo-500 selection:text-white">
        {children}
      </body>
    </html>
  );
}
