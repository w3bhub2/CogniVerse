import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { buildManifestLogs } from "@/db/schema";
import { desc } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const rows = await db
      .select()
      .from(buildManifestLogs)
      .orderBy(desc(buildManifestLogs.createdAt))
      .limit(25);
    return NextResponse.json({ success: true, manifests: rows });
  } catch (error) {
    console.error("GET /api/build-export error:", error);
    return NextResponse.json(
      { success: false, error: "Failed to load build export history" },
      { status: 500 }
    );
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { config, androidManifestXml, buildGradleKts, capacitorConfigTs, pwaManifestJson } = body;

    if (!config) {
      return NextResponse.json(
        { success: false, error: "Build config is required" },
        { status: 400 }
      );
    }

    await db.insert(buildManifestLogs).values({
      targetType: config.targetType,
      gameId: config.gameId || null,
      versionName: config.versionName || "1.0.0",
      packageId: config.packageId,
      manifestJson: {
        config,
        androidManifestXml,
        buildGradleKts,
        capacitorConfigTs,
        pwaManifestJson,
      },
      createdAt: new Date(),
    });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("POST /api/build-export error:", error);
    return NextResponse.json(
      { success: false, error: "Failed to record build export manifest" },
      { status: 500 }
    );
  }
}
