import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { gameSaves } from "@/db/schema";
import { eq, and } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const userId = searchParams.get("userId") || "local-player";
    const gameId = searchParams.get("gameId");

    if (gameId) {
      const rows = await db
        .select()
        .from(gameSaves)
        .where(
          and(eq(gameSaves.userId, userId), eq(gameSaves.gameId, gameId))
        );
      return NextResponse.json({ success: true, save: rows[0] || null });
    } else {
      const rows = await db
        .select()
        .from(gameSaves)
        .where(eq(gameSaves.userId, userId));
      return NextResponse.json({ success: true, saves: rows });
    }
  } catch (error) {
    console.error("GET /api/saves error:", error);
    return NextResponse.json(
      { success: false, error: "Failed to fetch save data" },
      { status: 500 }
    );
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { userId, gameId, score, saveData } = body;

    if (!userId || !gameId) {
      return NextResponse.json(
        { success: false, error: "userId and gameId are required" },
        { status: 400 }
      );
    }

    const existing = await db
      .select()
      .from(gameSaves)
      .where(and(eq(gameSaves.userId, userId), eq(gameSaves.gameId, gameId)));

    if (existing.length > 0) {
      const prevScore = existing[0].highScore || 0;
      const newHighScore = Math.max(prevScore, score || 0);

      await db
        .update(gameSaves)
        .set({
          highScore: newHighScore,
          saveData: saveData || existing[0].saveData || {},
          totalGamesPlayed: (existing[0].totalGamesPlayed || 0) + 1,
          lastPlayedAt: new Date(),
        })
        .where(eq(gameSaves.id, existing[0].id));
    } else {
      await db.insert(gameSaves).values({
        userId,
        gameId,
        saveData: saveData || {},
        highScore: score || 0,
        totalGamesPlayed: 1,
        lastPlayedAt: new Date(),
      });
    }

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("POST /api/saves error:", error);
    return NextResponse.json(
      { success: false, error: "Failed to save game data" },
      { status: 500 }
    );
  }
}
