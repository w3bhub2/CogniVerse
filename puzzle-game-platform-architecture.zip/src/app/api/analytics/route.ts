import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { analyticsEvents } from "@/db/schema";
import { desc } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const rows = await db
      .select()
      .from(analyticsEvents)
      .orderBy(desc(analyticsEvents.serverTimestamp))
      .limit(50);

    return NextResponse.json({ success: true, events: rows });
  } catch (error) {
    console.error("GET /api/analytics error:", error);
    return NextResponse.json(
      { success: false, error: "Failed to fetch analytics" },
      { status: 500 }
    );
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { userId, eventName, gameId, properties } = body;

    if (!eventName) {
      return NextResponse.json(
        { success: false, error: "eventName is required" },
        { status: 400 }
      );
    }

    await db.insert(analyticsEvents).values({
      userId: userId || "anonymous",
      eventName,
      gameId: gameId || null,
      properties: properties || {},
      clientTimestamp: new Date(),
      serverTimestamp: new Date(),
    });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("POST /api/analytics error:", error);
    return NextResponse.json(
      { success: false, error: "Failed to store analytics event" },
      { status: 500 }
    );
  }
}
