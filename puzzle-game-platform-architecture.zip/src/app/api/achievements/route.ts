import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { userAchievements } from "@/db/schema";
import { eq, and } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const userId = searchParams.get("userId") || "local-player";

    const rows = await db
      .select()
      .from(userAchievements)
      .where(eq(userAchievements.userId, userId));

    return NextResponse.json({ success: true, achievements: rows });
  } catch (error) {
    console.error("GET /api/achievements error:", error);
    return NextResponse.json(
      { success: false, error: "Failed to fetch achievements" },
      { status: 500 }
    );
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { userId, achievementId, gameId } = body;

    if (!userId || !achievementId) {
      return NextResponse.json(
        { success: false, error: "userId and achievementId are required" },
        { status: 400 }
      );
    }

    const existing = await db
      .select()
      .from(userAchievements)
      .where(
        and(
          eq(userAchievements.userId, userId),
          eq(userAchievements.achievementId, achievementId)
        )
      );

    if (existing.length === 0) {
      await db.insert(userAchievements).values({
        userId,
        achievementId,
        gameId: gameId || "platform",
        unlockedAt: new Date(),
      });
    }

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("POST /api/achievements error:", error);
    return NextResponse.json(
      { success: false, error: "Failed to unlock achievement" },
      { status: 500 }
    );
  }
}
