import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { campaignProgress } from "@/db/schema";
import { eq, and } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const userId = searchParams.get("userId") || "local-player";

    const rows = await db
      .select()
      .from(campaignProgress)
      .where(eq(campaignProgress.userId, userId));

    return NextResponse.json({ success: true, chapters: rows });
  } catch (error) {
    console.error("GET /api/campaign error:", error);
    return NextResponse.json(
      { success: false, error: "Failed to fetch campaign progress" },
      { status: 500 }
    );
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { userId, chapterId, score, timeSeconds, starsEarned } = body;

    if (!userId || !chapterId) {
      return NextResponse.json(
        { success: false, error: "userId and chapterId are required" },
        { status: 400 }
      );
    }

    const existing = await db
      .select()
      .from(campaignProgress)
      .where(
        and(
          eq(campaignProgress.userId, userId),
          eq(campaignProgress.chapterId, chapterId)
        )
      );

    if (existing.length > 0) {
      const prevStars = existing[0].starsEarned || 0;
      const newStars = Math.max(prevStars, starsEarned || 0);
      const prevScore = existing[0].bestScore || 0;
      const newScore = Math.max(prevScore, score || 0);

      await db
        .update(campaignProgress)
        .set({
          starsEarned: newStars,
          bestScore: newScore,
          bestTimeSeconds: timeSeconds || existing[0].bestTimeSeconds,
          isCompleted: newStars > 0 || existing[0].isCompleted,
          unlockedRelic: newStars >= 2 || existing[0].unlockedRelic,
          updatedAt: new Date(),
        })
        .where(eq(campaignProgress.id, existing[0].id));
    } else {
      await db.insert(campaignProgress).values({
        userId,
        chapterId,
        starsEarned: starsEarned || 0,
        bestScore: score || 0,
        bestTimeSeconds: timeSeconds || null,
        isCompleted: (starsEarned || 0) > 0,
        unlockedRelic: (starsEarned || 0) >= 2,
        updatedAt: new Date(),
      });
    }

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("POST /api/campaign error:", error);
    return NextResponse.json(
      { success: false, error: "Failed to update campaign progress" },
      { status: 500 }
    );
  }
}
