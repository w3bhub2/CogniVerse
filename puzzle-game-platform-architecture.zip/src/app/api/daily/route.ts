import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { dailyChallenges } from "@/db/schema";
import { eq, and } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const userId = searchParams.get("userId") || "local-player";
    const dateKey =
      searchParams.get("dateKey") || new Date().toISOString().slice(0, 10);

    const rows = await db
      .select()
      .from(dailyChallenges)
      .where(
        and(
          eq(dailyChallenges.userId, userId),
          eq(dailyChallenges.dateKey, dateKey)
        )
      );

    return NextResponse.json({ success: true, challenge: rows[0] || null });
  } catch (error) {
    console.error("GET /api/daily error:", error);
    return NextResponse.json(
      { success: false, error: "Failed to fetch daily challenge" },
      { status: 500 }
    );
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { userId, dateKey, gameId, score, isSolved } = body;

    if (!userId || !dateKey || !gameId) {
      return NextResponse.json(
        { success: false, error: "userId, dateKey, and gameId are required" },
        { status: 400 }
      );
    }

    const existing = await db
      .select()
      .from(dailyChallenges)
      .where(
        and(
          eq(dailyChallenges.userId, userId),
          eq(dailyChallenges.dateKey, dateKey)
        )
      );

    if (existing.length > 0) {
      const prevScore = existing[0].score || 0;
      await db
        .update(dailyChallenges)
        .set({
          score: Math.max(prevScore, score || 0),
          isSolved: isSolved || existing[0].isSolved,
          solvedAt: new Date(),
        })
        .where(eq(dailyChallenges.id, existing[0].id));
    } else {
      await db.insert(dailyChallenges).values({
        userId,
        dateKey,
        gameId,
        score: score || 0,
        isSolved: isSolved || false,
        streakCount: 1,
        solvedAt: new Date(),
      });
    }

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("POST /api/daily error:", error);
    return NextResponse.json(
      { success: false, error: "Failed to save daily challenge" },
      { status: 500 }
    );
  }
}
