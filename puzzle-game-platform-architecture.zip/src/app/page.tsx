import { db } from "@/db";
import { sql } from "drizzle-orm";
import { StudioHub } from "@/components/studio/StudioHub";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  // Ensure database connection is healthy
  await db.execute(sql`select 1`);

  return <StudioHub />;
}
