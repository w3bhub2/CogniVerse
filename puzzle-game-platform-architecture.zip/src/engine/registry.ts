import { GameModule, GameCategory } from "./types";
import { game2048Module } from "@/games/2048";
import { sudokuModule } from "@/games/sudoku";
import { crosswordModule } from "@/games/crossword";
import { wordSearchModule } from "@/games/word-search";
import { jigsawModule } from "@/games/jigsaw";
import { slidingPuzzleModule } from "@/games/sliding-puzzle";

export interface GameRoadmapEntry {
  id: string;
  name: string;
  phase: 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9;
  category: GameCategory;
  packageId: string;
  description: string;
  isPlayable: boolean;
  module?: GameModule<any, any>;
}

export const PHASE_1_MODULES: Record<string, GameModule<any, any>> = {
  "2048": game2048Module,
  sudoku: sudokuModule,
  crossword: crosswordModule,
  "word-search": wordSearchModule,
  jigsaw: jigsawModule,
  "sliding-puzzle": slidingPuzzleModule,
};

export const FULL_STUDIO_ROADMAP: GameRoadmapEntry[] = [
  // Phase 1 - Fully Implemented
  {
    id: "2048",
    name: "2048",
    phase: 1,
    category: "Number Logic",
    packageId: "com.puzzleplatform.games.g2048",
    description: "Slide and merge matching number tiles to reach 2048.",
    isPlayable: true,
    module: game2048Module,
  },
  {
    id: "sudoku",
    name: "Sudoku",
    phase: 1,
    category: "Number Logic",
    packageId: "com.puzzleplatform.games.sudoku",
    description: "Fill the 9x9 grid so every row, col, and 3x3 block has digits 1-9.",
    isPlayable: true,
    module: sudokuModule,
  },
  {
    id: "crossword",
    name: "Crossword",
    phase: 1,
    category: "Word & Vocabulary",
    packageId: "com.puzzleplatform.games.crossword",
    description: "Solve daily and classic mini crossword puzzles with across and down clues.",
    isPlayable: true,
    module: crosswordModule,
  },
  {
    id: "word-search",
    name: "Word Search",
    phase: 1,
    category: "Word & Vocabulary",
    packageId: "com.puzzleplatform.games.wordsearch",
    description: "Discover hidden vocabulary words in horizontal, vertical, and diagonal lines.",
    isPlayable: true,
    module: wordSearchModule,
  },
  {
    id: "jigsaw",
    name: "Jigsaw Puzzle",
    phase: 1,
    category: "Tile & Grid",
    packageId: "com.puzzleplatform.games.jigsaw",
    description: "Snap gradient and illustration tiles into their correct coordinates.",
    isPlayable: true,
    module: jigsawModule,
  },
  {
    id: "sliding-puzzle",
    name: "Sliding Puzzle",
    phase: 1,
    category: "Tile & Grid",
    packageId: "com.puzzleplatform.games.slidingpuzzle",
    description: "Slide numbered tiles in order around the single empty square.",
    isPlayable: true,
    module: slidingPuzzleModule,
  },

  // Phase 2
  {
    id: "nonogram",
    name: "Nonogram",
    phase: 2,
    category: "Tile & Grid",
    packageId: "com.puzzleplatform.games.nonogram",
    description: "Use row and column numerical clues to reveal hidden pixel art images.",
    isPlayable: false,
  },
  {
    id: "kakuro",
    name: "Kakuro",
    phase: 2,
    category: "Number Logic",
    packageId: "com.puzzleplatform.games.kakuro",
    description: "The mathematical cross-sum puzzle combining Sudoku and Crosswords.",
    isPlayable: false,
  },
  {
    id: "minesweeper",
    name: "Minesweeper",
    phase: 2,
    category: "Tile & Grid",
    packageId: "com.puzzleplatform.games.minesweeper",
    description: "Clear the minefield using numerical neighbor clues without triggering explosives.",
    isPlayable: false,
  },
  {
    id: "solitaire",
    name: "Solitaire",
    phase: 2,
    category: "Board & Strategy",
    packageId: "com.puzzleplatform.games.solitaire",
    description: "Classic Klondike card patience puzzle with undo and deal-3 modes.",
    isPlayable: false,
  },
  {
    id: "mahjong-solitaire",
    name: "Mahjong Solitaire",
    phase: 2,
    category: "Tile & Grid",
    packageId: "com.puzzleplatform.games.mahjong",
    description: "Match identical free tiles to dismantle the multi-layered turtle tower.",
    isPlayable: false,
  },
  {
    id: "match-3",
    name: "Match-3",
    phase: 2,
    category: "Tile & Grid",
    packageId: "com.puzzleplatform.games.match3",
    description: "Swap adjacent gems to form combos of three or more and clear target colors.",
    isPlayable: false,
  },

  // Phase 3
  {
    id: "unblock-me",
    name: "Unblock Me",
    phase: 3,
    category: "Spatial & Maze",
    packageId: "com.puzzleplatform.games.unblockme",
    description: "Slide wooden blocks horizontally and vertically to clear an exit path.",
    isPlayable: false,
  },
  {
    id: "water-sort",
    name: "Water Sort",
    phase: 3,
    category: "Spatial & Maze",
    packageId: "com.puzzleplatform.games.watersort",
    description: "Pour colored liquids between test tubes until each tube holds one solid color.",
    isPlayable: false,
  },
  {
    id: "ball-sort",
    name: "Ball Sort",
    phase: 3,
    category: "Spatial & Maze",
    packageId: "com.puzzleplatform.games.ballsort",
    description: "Sort colored spheres across cylinders in the minimum number of moves.",
    isPlayable: false,
  },
  {
    id: "color-fill",
    name: "Color Fill",
    phase: 3,
    category: "Tile & Grid",
    packageId: "com.puzzleplatform.games.colorfill",
    description: "Flood fill the entire canvas with a single color within the turn limit.",
    isPlayable: false,
  },
  {
    id: "flow",
    name: "Flow",
    phase: 3,
    category: "Spatial & Maze",
    packageId: "com.puzzleplatform.games.flow",
    description: "Connect matching color dots with pipes without crossing lines.",
    isPlayable: false,
  },
  {
    id: "pipe-connect",
    name: "Pipe Connect",
    phase: 3,
    category: "Spatial & Maze",
    packageId: "com.puzzleplatform.games.pipeconnect",
    description: "Rotate pipe tiles to form a continuous loop from source to destination.",
    isPlayable: false,
  },

  // Phase 4
  {
    id: "number-merge",
    name: "Number Merge",
    phase: 4,
    category: "Number Logic",
    packageId: "com.puzzleplatform.games.numbermerge",
    description: "Drop and combine adjacent identical digits to climb to infinite numbers.",
    isPlayable: false,
  },
  {
    id: "hex-puzzle",
    name: "Hex Puzzle",
    phase: 4,
    category: "Tile & Grid",
    packageId: "com.puzzleplatform.games.hexpuzzle",
    description: "Fit hexagonal blocks onto the honeycomb board to clear full lines.",
    isPlayable: false,
  },
  {
    id: "block-puzzle",
    name: "Block Puzzle",
    phase: 4,
    category: "Tile & Grid",
    packageId: "com.puzzleplatform.games.blockpuzzle",
    description: "Classic wood-block placement grid challenge without gravity.",
    isPlayable: false,
  },
  {
    id: "tangram",
    name: "Tangram",
    phase: 4,
    category: "Spatial & Maze",
    packageId: "com.puzzleplatform.games.tangram",
    description: "Arrange geometric shapes to perfectly fill custom silhouettes.",
    isPlayable: false,
  },
  {
    id: "one-line",
    name: "One Line",
    phase: 4,
    category: "Spatial & Maze",
    packageId: "com.puzzleplatform.games.oneline",
    description: "Draw a continuous path through every node without lifting your finger.",
    isPlayable: false,
  },
  {
    id: "dot-connect",
    name: "Dot Connect",
    phase: 4,
    category: "Spatial & Maze",
    packageId: "com.puzzleplatform.games.dotconnect",
    description: "Link numbered dots in ascending sequence to reveal artwork.",
    isPlayable: false,
  },

  // Phase 5
  {
    id: "word-connect",
    name: "Word Connect",
    phase: 5,
    category: "Word & Vocabulary",
    packageId: "com.puzzleplatform.games.wordconnect",
    description: "Swipe across letter circles to form dictionary words.",
    isPlayable: false,
  },
  {
    id: "word-scramble",
    name: "Word Scramble",
    phase: 5,
    category: "Word & Vocabulary",
    packageId: "com.puzzleplatform.games.wordscramble",
    description: "Unscramble anagram letters into valid vocabulary words.",
    isPlayable: false,
  },
  {
    id: "anagram",
    name: "Anagram",
    phase: 5,
    category: "Word & Vocabulary",
    packageId: "com.puzzleplatform.games.anagram",
    description: "Rearrange letters of one phrase to produce a hidden target phrase.",
    isPlayable: false,
  },
  {
    id: "word-cross",
    name: "Word Cross",
    phase: 5,
    category: "Word & Vocabulary",
    packageId: "com.puzzleplatform.games.wordcross",
    description: "Crossword-style word builder using a circular letter tray.",
    isPlayable: false,
  },
  {
    id: "hangman",
    name: "Hangman",
    phase: 5,
    category: "Word & Vocabulary",
    packageId: "com.puzzleplatform.games.hangman",
    description: "Guess the hidden vocabulary phrase letter by letter before running out of attempts.",
    isPlayable: false,
  },
  {
    id: "spelling-bee",
    name: "Spelling Bee",
    phase: 5,
    category: "Word & Vocabulary",
    packageId: "com.puzzleplatform.games.spellingbee",
    description: "Construct words using a 7-letter honeycomb, always including the center letter.",
    isPlayable: false,
  },

  // Phase 6
  {
    id: "memory-match",
    name: "Memory Match",
    phase: 6,
    category: "Memory & Pattern",
    packageId: "com.puzzleplatform.games.memorymatch",
    description: "Flip face-down cards two at a time to discover matching symbol pairs.",
    isPlayable: false,
  },
  {
    id: "simon",
    name: "Simon",
    phase: 6,
    category: "Memory & Pattern",
    packageId: "com.puzzleplatform.games.simon",
    description: "Memorize and repeat ever-growing color and tone sequences.",
    isPlayable: false,
  },
  {
    id: "pattern-memory",
    name: "Pattern Memory",
    phase: 6,
    category: "Memory & Pattern",
    packageId: "com.puzzleplatform.games.patternmemory",
    description: "Recall which grid squares flashed blue after they turn face down.",
    isPlayable: false,
  },
  {
    id: "sequence-recall",
    name: "Sequence Recall",
    phase: 6,
    category: "Memory & Pattern",
    packageId: "com.puzzleplatform.games.sequencerecall",
    description: "Tap numbered tiles in the exact order they appeared.",
    isPlayable: false,
  },
  {
    id: "find-difference",
    name: "Find Difference",
    phase: 6,
    category: "Memory & Pattern",
    packageId: "com.puzzleplatform.games.finddifference",
    description: "Spot subtle visual discrepancies between two seemingly identical scenes.",
    isPlayable: false,
  },
  {
    id: "hidden-object",
    name: "Hidden Object",
    phase: 6,
    category: "Memory & Pattern",
    packageId: "com.puzzleplatform.games.hiddenobject",
    description: "Search dense artistic scenes for listed mystery objects.",
    isPlayable: false,
  },

  // Phase 7
  {
    id: "chess-puzzles",
    name: "Chess Puzzles",
    phase: 7,
    category: "Board & Strategy",
    packageId: "com.puzzleplatform.games.chesspuzzles",
    description: "Find the checkmate in 1, 2, or 3 moves from grandmaster positions.",
    isPlayable: false,
  },
  {
    id: "checkers",
    name: "Checkers",
    phase: 7,
    category: "Board & Strategy",
    packageId: "com.puzzleplatform.games.checkers",
    description: "Classic draughts strategy against adaptive AI difficulty.",
    isPlayable: false,
  },
  {
    id: "tic-tac-toe",
    name: "Tic Tac Toe",
    phase: 7,
    category: "Board & Strategy",
    packageId: "com.puzzleplatform.games.tictactoe",
    description: "3x3, 5x5, and ultimate Tic Tac Toe with smart AI opponents.",
    isPlayable: false,
  },
  {
    id: "reversi",
    name: "Reversi",
    phase: 7,
    category: "Board & Strategy",
    packageId: "com.puzzleplatform.games.reversi",
    description: "Outflank your opponent's discs to flip them to your color.",
    isPlayable: false,
  },
  {
    id: "connect-four",
    name: "Connect Four",
    phase: 7,
    category: "Board & Strategy",
    packageId: "com.puzzleplatform.games.connectfour",
    description: "Drop discs into a 7x6 grid to align four in a row before your rival.",
    isPlayable: false,
  },
  {
    id: "gomoku",
    name: "Gomoku",
    phase: 7,
    category: "Board & Strategy",
    packageId: "com.puzzleplatform.games.gomoku",
    description: "Traditional Five-in-a-Row tactical board game on a 15x15 grid.",
    isPlayable: false,
  },

  // Phase 8
  {
    id: "logic-grid",
    name: "Logic Grid",
    phase: 8,
    category: "Number Logic",
    packageId: "com.puzzleplatform.games.logicgrid",
    description: "Deduce relationships between suspects, times, and locations using clue matrices.",
    isPlayable: false,
  },
  {
    id: "akari",
    name: "Akari",
    phase: 8,
    category: "Number Logic",
    packageId: "com.puzzleplatform.games.akari",
    description: "Place light bulbs on a grid so every white square is illuminated without bulbs shining on each other.",
    isPlayable: false,
  },
  {
    id: "slitherlink",
    name: "Slitherlink",
    phase: 8,
    category: "Number Logic",
    packageId: "com.puzzleplatform.games.slitherlink",
    description: "Connect adjacent dots to form a single continuous loop surrounding numbered cells.",
    isPlayable: false,
  },
  {
    id: "nurikabe",
    name: "Nurikabe",
    phase: 8,
    category: "Number Logic",
    packageId: "com.puzzleplatform.games.nurikabe",
    description: "Create white islands of specified size separated by a continuous black stream.",
    isPlayable: false,
  },
  {
    id: "hashi",
    name: "Hashi",
    phase: 8,
    category: "Number Logic",
    packageId: "com.puzzleplatform.games.hashi",
    description: "Connect numbered island circles with single or double bridges into one unified graph.",
    isPlayable: false,
  },
  {
    id: "hitori",
    name: "Hitori",
    phase: 8,
    category: "Number Logic",
    packageId: "com.puzzleplatform.games.hitori",
    description: "Shade grid cells so no number appears twice in any row or column.",
    isPlayable: false,
  },

  // Phase 9
  {
    id: "maze-escape",
    name: "Maze Escape",
    phase: 9,
    category: "Spatial & Maze",
    packageId: "com.puzzleplatform.games.mazeescape",
    description: "Navigate complex multi-level procedural mazes with portal doors and keys.",
    isPlayable: false,
  },
  {
    id: "escape-logic-rooms",
    name: "Escape Logic Rooms",
    phase: 9,
    category: "Spatial & Maze",
    packageId: "com.puzzleplatform.games.escaperooms",
    description: "Solve layered environmental logic puzzles to unlock the exit door.",
    isPlayable: false,
  },
];

export function getPlayableGames(): GameModule<any, any>[] {
  return Object.values(PHASE_1_MODULES);
}

export function getGameModuleById(id: string): GameModule<any, any> | undefined {
  return PHASE_1_MODULES[id];
}

export function getRoadmapByPhase(phase: number): GameRoadmapEntry[] {
  return FULL_STUDIO_ROADMAP.filter((entry) => entry.phase === phase);
}

export function getRoadmapByCategory(category: GameCategory): GameRoadmapEntry[] {
  return FULL_STUDIO_ROADMAP.filter((entry) => entry.category === category);
}
