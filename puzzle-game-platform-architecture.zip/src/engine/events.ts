import { EngineEventName, EngineEventPayload } from "./types";

type EventCallback = (payload: EngineEventPayload) => void;

class StudioEventBus {
  private listeners: Map<EngineEventName, Set<EventCallback>> = new Map();
  private history: EngineEventPayload[] = [];
  private maxHistorySize = 100;

  public subscribe(
    event: EngineEventName | "*",
    callback: EventCallback
  ): () => void {
    const key = event as EngineEventName;
    if (!this.listeners.has(key)) {
      this.listeners.set(key, new Set());
    }
    this.listeners.get(key)!.add(callback);

    return () => {
      const set = this.listeners.get(key);
      if (set) {
        set.delete(callback);
      }
    };
  }

  public emit(
    eventName: EngineEventName,
    gameId: string,
    data?: Record<string, any>
  ): void {
    const payload: EngineEventPayload = {
      eventName,
      gameId,
      timestamp: Date.now(),
      data,
    };

    this.history.unshift(payload);
    if (this.history.length > this.maxHistorySize) {
      this.history.pop();
    }

    const callbacks = this.listeners.get(eventName);
    if (callbacks) {
      callbacks.forEach((cb) => {
        try {
          cb(payload);
        } catch (error) {
          console.error(`Error in event callback for ${eventName}:`, error);
        }
      });
    }

    const allCallbacks = this.listeners.get("*" as EngineEventName);
    if (allCallbacks) {
      allCallbacks.forEach((cb) => {
        try {
          cb(payload);
        } catch (error) {
          console.error(`Error in wildcard event callback:`, error);
        }
      });
    }
  }

  public getRecentEvents(limit: number = 20): EngineEventPayload[] {
    return this.history.slice(0, limit);
  }

  public clearHistory(): void {
    this.history = [];
  }
}

export const eventBus = new StudioEventBus();
