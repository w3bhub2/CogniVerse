import { GameDifficulty } from "./types";

export interface CampaignChapter {
  id: string; // e.g. 'chap-1'
  title: string;
  subtitle: string;
  gameId: string; // '2048', 'sudoku', 'crossword', 'jigsaw', 'sliding-puzzle'
  difficulty: GameDifficulty;
  storyIntro: string[];
  storyOutro: string[];
  bannerImagePath: string;
  relicName: string;
  relicDescription: string;
  relicIcon: string;
  starThresholds: {
    star1Score: number;
    star2Score: number;
    star3Score: number;
  };
  coinReward: number;
}

export const STUDIO_CAMPAIGN_CHAPTERS: CampaignChapter[] = [
  {
    id: "chap-1",
    title: "Chapter I: The Awakening of Numbers",
    subtitle: "The Sacred Golden Temple of 2048",
    gameId: "2048",
    difficulty: "medium",
    bannerImagePath: "/images/chapter-1.jpg",
    storyIntro: [
      "Welcome, Traveler. You stand at the threshold of the Golden Temple of Numbers.",
      "For centuries, the tiles have slumbered in chaotic disarray.",
      "Merge the matching harmonics until the legendary 2048 tile awakens the altar!",
    ],
    storyOutro: [
      "The temple resonates with golden light! The ancient number seal is broken.",
      "You have earned the Relic of the Primordial Cube.",
    ],
    relicName: "Primordial Golden Cube",
    relicDescription: "A glowing relic vibrating with infinite exponential energy.",
    relicIcon: "Grid3x3",
    starThresholds: {
      star1Score: 500,
      star2Score: 2000,
      star3Score: 5000,
    },
    coinReward: 250,
  },
  {
    id: "chap-2",
    title: "Chapter II: The Zen Garden of Logic",
    subtitle: "The 9x9 Sanctuary of Sudoku",
    gameId: "sudoku",
    difficulty: "medium",
    bannerImagePath: "/images/chapter-2.jpg",
    storyIntro: [
      "You enter a misty Japanese zen garden where glowing blue numbers ripple across the pond.",
      "The monk speaks: 'Order is born from non-repetition. Let every row, column, and garden stone hold each digit once.'",
      "Solve the sacred 9x9 grid to cleanse the garden pond.",
    ],
    storyOutro: [
      "Perfect harmony flows through the garden waters.",
      "The Lotus of Pure Deduction opens in your hands.",
    ],
    relicName: "Lotus of Pure Deduction",
    relicDescription: "A crystalline lotus flower that reveals hidden logical truths.",
    relicIcon: "Hash",
    starThresholds: {
      star1Score: 1000,
      star2Score: 2500,
      star3Score: 4000,
    },
    coinReward: 300,
  },
  {
    id: "chap-3",
    title: "Chapter III: The Library of Ancients",
    subtitle: "The Scribe's Mini Crossword",
    gameId: "crossword",
    difficulty: "medium",
    bannerImagePath: "/images/chapter-3.jpg",
    storyIntro: [
      "Deep underground lies the emerald Library of Ancients.",
      "The great scrolls have faded over time. Across and down, the words hold the key to the library's spellbook.",
      "Restore the Scribe's vocabulary grid!",
    ],
    storyOutro: [
      "The spellbook pages illuminate with emerald fire!",
      "You have been granted the Quill of the Grand Lexicon.",
    ],
    relicName: "Quill of the Grand Lexicon",
    relicDescription: "An enchanted emerald quill that never runs out of vocabulary words.",
    relicIcon: "BookOpen",
    starThresholds: {
      star1Score: 300,
      star2Score: 1200,
      star3Score: 2500,
    },
    coinReward: 350,
  },
  {
    id: "chap-4",
    title: "Chapter IV: The Shattered Cathedral",
    subtitle: "Stained-Glass Jigsaw Restoration",
    gameId: "jigsaw",
    difficulty: "medium",
    bannerImagePath: "/images/chapter-4.jpg",
    storyIntro: [
      "High in the mountains stands a cathedral whose stained-glass masterpiece was shattered by a solar storm.",
      "Each shard vibrates with sunset colors. Swap and lock the pieces back into their rightful coordinates.",
    ],
    storyOutro: [
      "Light streams through the restored mosaic, casting rainbow prisms across the altar.",
      "You claim the Prism of the Artisan.",
    ],
    relicName: "Prism of the Artisan",
    relicDescription: "A geometric prism that refracts light into perfect tile coordinates.",
    relicIcon: "Puzzle",
    starThresholds: {
      star1Score: 500,
      star2Score: 1800,
      star3Score: 3200,
    },
    coinReward: 400,
  },
  {
    id: "chap-5",
    title: "Chapter V: The Cyberpunk Vault",
    subtitle: "The 15-Puzzle Sliding Mechanism",
    gameId: "sliding-puzzle",
    difficulty: "hard",
    bannerImagePath: "/images/chapter-5.jpg",
    storyIntro: [
      "You reach the deepest chamber of the studio universe: a neon cyber-vault sealed by a mechanical sliding grid.",
      "Slide the numbered plates into numerical order around the single empty square to disarm the lock!",
    ],
    storyOutro: [
      "The heavy cyber-doors slide open with a hiss! The Studio Core energy is yours.",
      "You are recognized as the Supreme Puzzle Master.",
    ],
    relicName: "Core Key of the Studio",
    relicDescription: "The ultimate cybernetic key that unlocks all 50+ future games.",
    relicIcon: "LayoutGrid",
    starThresholds: {
      star1Score: 800,
      star2Score: 2200,
      star3Score: 3800,
    },
    coinReward: 500,
  },
];

export function computeChapterStars(chapterId: string, score: number): number {
  const chapter = STUDIO_CAMPAIGN_CHAPTERS.find((c) => c.id === chapterId);
  if (!chapter) return 0;

  if (score >= chapter.starThresholds.star3Score) return 3;
  if (score >= chapter.starThresholds.star2Score) return 2;
  if (score >= chapter.starThresholds.star1Score) return 1;
  return 0;
}
