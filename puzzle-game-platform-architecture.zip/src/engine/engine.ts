import { GameDifficulty, GameHint, GameModule, EngineSnapshot } from "./types";
import { eventBus } from "./events";

export class PuzzleEngine<TState = any> {
  private module: GameModule<TState>;
  private currentState!: TState;
  private undoStack: TState[] = [];
  private redoStack: TState[] = [];
  private difficulty: GameDifficulty;
  private score: number = 0;
  private movesCount: number = 0;
  private hintsUsedCount: number = 0;
  private elapsedSeconds: number = 0;
  private timerInterval: NodeJS.Timeout | null = null;
  private isPaused: boolean = false;
  private isCompleted: boolean = false;
  private isWon: boolean = false;
  private onStateChangeCallback?: (snapshot: EngineSnapshot<TState>) => void;

  constructor(
    module: GameModule<TState>,
    difficulty: GameDifficulty = "medium",
    onStateChange?: (snapshot: EngineSnapshot<TState>) => void
  ) {
    this.module = module;
    this.difficulty = difficulty;
    this.onStateChangeCallback = onStateChange;
    this.init();
  }

  public init(customSeed?: string): void {
    this.stopTimer();
    this.currentState = this.module.getInitialState(this.difficulty, customSeed);
    this.undoStack = [];
    this.redoStack = [];
    this.score = 0;
    this.movesCount = 0;
    this.hintsUsedCount = 0;
    this.elapsedSeconds = 0;
    this.isPaused = false;
    this.isCompleted = false;
    this.isWon = false;

    eventBus.emit("ENGINE_INIT", this.module.id, {
      difficulty: this.difficulty,
    });
    this.startTimer();
    this.notifyState();
  }

  public getSnapshot(): EngineSnapshot<TState> {
    return {
      gameId: this.module.id,
      state: this.currentState,
      difficulty: this.difficulty,
      score: this.score,
      movesCount: this.movesCount,
      elapsedSeconds: this.elapsedSeconds,
      hintsUsedCount: this.hintsUsedCount,
      isPaused: this.isPaused,
      isCompleted: this.isCompleted,
      isWon: this.isWon,
    };
  }

  public getState(): TState {
    return this.currentState;
  }

  public canUndo(): boolean {
    return this.undoStack.length > 0 && !this.isCompleted;
  }

  public canRedo(): boolean {
    return this.redoStack.length > 0 && !this.isCompleted;
  }

  public makeMove(nextState: TState, options?: { skipUndoSave?: boolean }): boolean {
    if (this.isPaused || this.isCompleted) {
      return false;
    }

    if (!options?.skipUndoSave) {
      // Save deep clone of current state to undo stack (max 50 steps)
      this.undoStack.push(JSON.parse(JSON.stringify(this.currentState)));
      if (this.undoStack.length > 50) {
        this.undoStack.shift();
      }
      this.redoStack = [];
    }

    this.currentState = nextState;
    this.movesCount += 1;

    // Check win / game over rules from the game module contract
    this.isWon = this.module.isGameWon(this.currentState);
    this.isCompleted = this.isWon || this.module.isGameOver(this.currentState);
    this.score = this.module.computeScore(
      this.currentState,
      this.elapsedSeconds,
      this.movesCount
    );

    eventBus.emit("MOVE_MADE", this.module.id, {
      moves: this.movesCount,
      score: this.score,
      isWon: this.isWon,
      isCompleted: this.isCompleted,
    });

    if (this.isWon) {
      eventBus.emit("GAME_WON", this.module.id, {
        score: this.score,
        time: this.elapsedSeconds,
        moves: this.movesCount,
      });
      eventBus.emit("SOUND_EFFECT", this.module.id, { sound: "victory" });
      eventBus.emit("HAPTIC_PULSE", this.module.id, { pattern: "success" });
      this.stopTimer();
    } else if (this.isCompleted) {
      eventBus.emit("GAME_OVER", this.module.id, {
        score: this.score,
        time: this.elapsedSeconds,
      });
      eventBus.emit("SOUND_EFFECT", this.module.id, { sound: "gameover" });
      this.stopTimer();
    } else {
      eventBus.emit("SOUND_EFFECT", this.module.id, { sound: "move" });
      eventBus.emit("HAPTIC_PULSE", this.module.id, { pattern: "light" });
    }

    this.notifyState();
    return true;
  }

  public undo(): boolean {
    if (!this.canUndo()) return false;
    const previous = this.undoStack.pop()!;
    this.redoStack.push(JSON.parse(JSON.stringify(this.currentState)));
    this.currentState = previous;
    this.movesCount = Math.max(0, this.movesCount - 1);
    this.isCompleted = false;
    this.isWon = false;
    this.score = this.module.computeScore(
      this.currentState,
      this.elapsedSeconds,
      this.movesCount
    );
    eventBus.emit("UNDO_TRIGGERED", this.module.id, {
      remainingUndos: this.undoStack.length,
    });
    eventBus.emit("SOUND_EFFECT", this.module.id, { sound: "undo" });
    this.notifyState();
    return true;
  }

  public redo(): boolean {
    if (!this.canRedo()) return false;
    const next = this.redoStack.pop()!;
    this.undoStack.push(JSON.parse(JSON.stringify(this.currentState)));
    this.currentState = next;
    this.movesCount += 1;
    this.score = this.module.computeScore(
      this.currentState,
      this.elapsedSeconds,
      this.movesCount
    );
    this.notifyState();
    return true;
  }

  public requestHint(): GameHint | null {
    if (this.isCompleted || this.isPaused) return null;
    const hint = this.module.getHint(this.currentState);
    if (hint) {
      this.hintsUsedCount += 1;
      this.elapsedSeconds += hint.penaltySeconds || 10; // Time penalty for hint
      eventBus.emit("HINT_USED", this.module.id, {
        message: hint.message,
        hintsUsedCount: this.hintsUsedCount,
      });
      eventBus.emit("SOUND_EFFECT", this.module.id, { sound: "hint" });
      this.notifyState();
    }
    return hint;
  }

  public setPaused(paused: boolean): void {
    this.isPaused = paused;
    if (this.isPaused) {
      this.stopTimer();
      eventBus.emit("GAME_PAUSED", this.module.id);
    } else {
      this.startTimer();
      eventBus.emit("GAME_RESUMED", this.module.id);
    }
    this.notifyState();
  }

  public resetGame(): void {
    this.init();
    eventBus.emit("GAME_RESET", this.module.id);
  }

  public changeDifficulty(newDifficulty: GameDifficulty): void {
    this.difficulty = newDifficulty;
    this.init();
  }

  public loadState(snapshot: Partial<EngineSnapshot<TState>>): void {
    if (snapshot.state) {
      this.currentState = snapshot.state;
    }
    if (snapshot.difficulty) {
      this.difficulty = snapshot.difficulty;
    }
    if (typeof snapshot.score === "number") {
      this.score = snapshot.score;
    }
    if (typeof snapshot.movesCount === "number") {
      this.movesCount = snapshot.movesCount;
    }
    if (typeof snapshot.elapsedSeconds === "number") {
      this.elapsedSeconds = snapshot.elapsedSeconds;
    }
    if (typeof snapshot.hintsUsedCount === "number") {
      this.hintsUsedCount = snapshot.hintsUsedCount;
    }
    this.isCompleted = Boolean(snapshot.isCompleted);
    this.isWon = Boolean(snapshot.isWon);
    this.notifyState();
  }

  public destroy(): void {
    this.stopTimer();
  }

  private startTimer(): void {
    this.stopTimer();
    this.timerInterval = setInterval(() => {
      if (!this.isPaused && !this.isCompleted) {
        this.elapsedSeconds += 1;
        this.score = this.module.computeScore(
          this.currentState,
          this.elapsedSeconds,
          this.movesCount
        );
        this.notifyState();
      }
    }, 1000);
  }

  private stopTimer(): void {
    if (this.timerInterval) {
      clearInterval(this.timerInterval);
      this.timerInterval = null;
    }
  }

  private notifyState(): void {
    if (this.onStateChangeCallback) {
      this.onStateChangeCallback(this.getSnapshot());
    }
  }
}
