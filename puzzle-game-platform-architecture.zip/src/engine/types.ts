export type GameDifficulty = "easy" | "medium" | "hard";

export type GameCategory =
  | "Number Logic"
  | "Word & Vocabulary"
  | "Tile & Grid"
  | "Memory & Pattern"
  | "Board & Strategy"
  | "Spatial & Maze";

export interface GameHint {
  message: string;
  highlightCells?: Array<{ row: number; col: number }>;
  suggestedAction?: string;
  penaltySeconds?: number;
}

export interface GameScoreSummary {
  score: number;
  timeMs: number;
  moves: number;
  hintsUsed: number;
  won: boolean;
  difficulty: GameDifficulty;
}

export interface GameModule<TState = any, TSave = any> {
  id: string;
  name: string;
  phase: 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9;
  category: GameCategory;
  description: string;
  version: string;
  author: string;
  packageId: string; // e.g., 'com.puzzleplatform.games.g2048'
  iconName: string;
  accentColor: string;
  minSdk: number;
  targetSdk: number;
  supportedDifficulties: GameDifficulty[];
  
  // Lifecycle & State Contracts
  defaultSaveData: () => TSave;
  getInitialState: (difficulty?: GameDifficulty, customSeed?: string) => TState;
  validateSaveData: (data: any) => boolean;
  
  // Game Logic Queries
  getHint: (state: TState) => GameHint | null;
  computeScore: (state: TState, timeSeconds: number, moves: number) => number;
  isGameOver: (state: TState) => boolean;
  isGameWon: (state: TState) => boolean;
  getBoardDimensions?: (state: TState) => { rows: number; cols: number };
}

export type EngineEventName =
  | "ENGINE_INIT"
  | "GAME_LOADED"
  | "GAME_STARTED"
  | "GAME_PAUSED"
  | "GAME_RESUMED"
  | "GAME_RESET"
  | "MOVE_MADE"
  | "HINT_USED"
  | "UNDO_TRIGGERED"
  | "GAME_WON"
  | "GAME_OVER"
  | "SAVE_REQUESTED"
  | "ACHIEVEMENT_UNLOCKED"
  | "HAPTIC_PULSE"
  | "SOUND_EFFECT";

export interface EngineEventPayload {
  eventName: EngineEventName;
  gameId: string;
  timestamp: number;
  data?: Record<string, any>;
}

export interface EngineSnapshot<TState = any> {
  gameId: string;
  state: TState;
  difficulty: GameDifficulty;
  score: number;
  movesCount: number;
  elapsedSeconds: number;
  hintsUsedCount: number;
  isPaused: boolean;
  isCompleted: boolean;
  isWon: boolean;
}
