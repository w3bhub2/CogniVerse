import { GameCategory } from "./types";

export interface DailyChallengeSpec {
  dateKey: string; // YYYY-MM-DD
  gameId: string; // e.g. '2048' or 'sudoku'
  gameName: string;
  category: GameCategory;
  difficulty: "easy" | "medium" | "hard";
  targetScore: number;
  coinBonus: number;
  description: string;
}

const DAILY_GAME_ROTATION = [
  { id: "2048", name: "2048", category: "Number Logic" as GameCategory, diff: "medium" as const, target: 2000, desc: "Reach a score of 2,000 in today's daily seed of 2048!" },
  { id: "sudoku", name: "Sudoku", category: "Number Logic" as GameCategory, diff: "hard" as const, target: 3000, desc: "Solve today's Sudoku grid with 2 or fewer mistakes!" },
  { id: "crossword", name: "Crossword", category: "Word & Vocabulary" as GameCategory, diff: "medium" as const, target: 1800, desc: "Complete today's Daily Scribe Crossword without hints!" },
  { id: "word-search", name: "Word Search", category: "Word & Vocabulary" as GameCategory, diff: "medium" as const, target: 2500, desc: "Find all 5 hidden vocabulary words in under 3 minutes!" },
  { id: "jigsaw", name: "Jigsaw Puzzle", category: "Tile & Grid" as GameCategory, diff: "medium" as const, target: 2200, desc: "Restore today's daily stained-glass artwork tile by tile!" },
  { id: "sliding-puzzle", name: "Sliding Puzzle", category: "Tile & Grid" as GameCategory, diff: "medium" as const, target: 2000, desc: "Slide the numbered tiles in sequence in under 60 moves!" },
];

export function getDailyChallengeSpec(dateKey?: string): DailyChallengeSpec {
  const dateStr = dateKey || new Date().toISOString().slice(0, 10);
  
  // Deterministic hash from date string
  let hash = 0;
  for (let i = 0; i < dateStr.length; i++) {
    hash = (hash << 5) - hash + dateStr.charCodeAt(i);
    hash |= 0;
  }
  const idx = Math.abs(hash) % DAILY_GAME_ROTATION.length;
  const picked = DAILY_GAME_ROTATION[idx];

  return {
    dateKey: dateStr,
    gameId: picked.id,
    gameName: picked.name,
    category: picked.category,
    difficulty: picked.diff,
    targetScore: picked.target,
    coinBonus: 150,
    description: picked.desc,
  };
}
