"use client";

import React, { useState } from "react";
import { BuildTargetConfig, BuildExportManifest } from "@/services/types";
import { buildPipelineService } from "@/services/build-pipeline.service";
import { getPlayableGames } from "@/engine/registry";
import {
  Package,
  X,
  FileCode2,
  CheckCircle2,
  Download,
  Terminal,
  Smartphone,
  Layers,
  Sparkles,
} from "lucide-react";

interface BuildExporterModalProps {
  onClose: () => void;
}

export function BuildExporterModal({ onClose }: BuildExporterModalProps) {
  const [targetType, setTargetType] = useState<"platform" | "standalone_game">("platform");
  const [selectedGameId, setSelectedGameId] = useState<string>("2048");
  const [versionName, setVersionName] = useState("1.0.0");
  const [versionCode, setVersionCode] = useState(1);
  const [minSdk, setMinSdk] = useState(26);
  const [targetSdk, setTargetSdk] = useState(35); // Android 15 API Level 35
  const [exportFormat, setExportFormat] = useState<"aab" | "apk">("aab");
  const [includeAds, setIncludeAds] = useState(true);
  const [includeCloudSync, setIncludeCloudSync] = useState(true);
  const [enableGoogleUmp, setEnableGoogleUmp] = useState(true);
  const [enablePlayAppSigning, setEnablePlayAppSigning] = useState(true);
  const [activeCodeTab, setActiveCodeTab] = useState<
    "manifest" | "gradle" | "capacitor" | "pwa" | "report"
  >("report");
  const [isSaved, setIsSaved] = useState(false);

  const playableGames = getPlayableGames();
  const targetModule =
    targetType === "standalone_game"
      ? playableGames.find((g) => g.id === selectedGameId)
      : undefined;

  const config: BuildTargetConfig = {
    targetType,
    gameId: targetType === "standalone_game" ? selectedGameId : undefined,
    versionName,
    versionCode,
    packageId:
      targetType === "platform"
        ? "com.puzzleplatform.app"
        : targetModule?.packageId || "com.puzzleplatform.games.puzzle",
    appName:
      targetType === "platform"
        ? "Puzzle Platform"
        : targetModule?.name || "Puzzle Game",
    minSdk,
    targetSdk,
    exportFormat,
    includeAds,
    includeCloudSync,
    enableGoogleUmp,
    enablePlayAppSigning,
  };

  const manifest: BuildExportManifest =
    buildPipelineService.generateManifest(config);

  const handleSaveAndExport = async () => {
    await buildPipelineService.logBuildManifestToDb(manifest);
    setIsSaved(true);

    // Create JSON blob download
    const dataStr =
      "data:text/json;charset=utf-8," +
      encodeURIComponent(JSON.stringify(manifest, null, 2));
    const downloadAnchor = document.createElement("a");
    downloadAnchor.setAttribute("href", dataStr);
    downloadAnchor.setAttribute(
      "download",
      `${config.packageId}-build-manifest.json`
    );
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/85 backdrop-blur-md p-4">
      <div className="w-full max-w-5xl h-[88vh] bg-slate-900 border border-slate-800 rounded-3xl flex flex-col shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-5 border-b border-slate-800 bg-slate-950/50">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-purple-500/20 text-purple-400 border border-purple-500/30">
              <Package className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-white tracking-wide">
                Play Store APK & Standalone App Build Exporter
              </h2>
              <p className="text-xs text-slate-400">
                Compile-Time Modular Target Generator (API Level 35 + AAB Support)
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-slate-800 text-slate-400 hover:text-white transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="flex-1 grid grid-cols-1 md:grid-cols-12 overflow-hidden">
          {/* Left Panel: Build Settings (5 Cols) */}
          <div className="md:col-span-5 p-6 border-r border-slate-800 bg-slate-950/30 overflow-y-auto space-y-6">
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
                1. Build Target Mode
              </label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => {
                    setTargetType("platform");
                    setIsSaved(false);
                  }}
                  className={`p-3 rounded-xl border text-left transition ${
                    targetType === "platform"
                      ? "bg-purple-600/20 border-purple-500 text-white font-bold"
                      : "bg-slate-900 border-slate-800 text-slate-300"
                  }`}
                >
                  <div className="flex items-center gap-2 mb-1">
                    <Layers className="w-4 h-4 text-purple-400" />
                    <span className="text-sm">Puzzle Platform</span>
                  </div>
                  <span className="text-[11px] text-slate-400 block">
                    All 50+ Games Bundle
                  </span>
                </button>
                <button
                  onClick={() => {
                    setTargetType("standalone_game");
                    setIsSaved(false);
                  }}
                  className={`p-3 rounded-xl border text-left transition ${
                    targetType === "standalone_game"
                      ? "bg-purple-600/20 border-purple-500 text-white font-bold"
                      : "bg-slate-900 border-slate-800 text-slate-300"
                  }`}
                >
                  <div className="flex items-center gap-2 mb-1">
                    <Smartphone className="w-4 h-4 text-purple-400" />
                    <span className="text-sm">Standalone APK</span>
                  </div>
                  <span className="text-[11px] text-slate-400 block">
                    Single Game App
                  </span>
                </button>
              </div>
            </div>

            {/* If Standalone Game selected, show Game Selector */}
            {targetType === "standalone_game" && (
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
                  2. Select Game Module to Package
                </label>
                <select
                  value={selectedGameId}
                  onChange={(e) => {
                    setSelectedGameId(e.target.value);
                    setIsSaved(false);
                  }}
                  className="w-full bg-slate-900 text-white text-sm rounded-xl px-4 py-2.5 border border-slate-700 focus:outline-none focus:border-purple-500"
                >
                  {playableGames.map((game) => (
                    <option key={game.id} value={game.id}>
                      {game.name} — {game.packageId}
                    </option>
                  ))}
                </select>
                <p className="mt-1 text-[11px] text-slate-500">
                  Other 49 games will be tree-shaked at compile-time.
                </p>
              </div>
            )}

            {/* Package Metadata */}
            <div className="space-y-4">
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-400">
                3. App & Package Configuration
              </label>
              <div>
                <span className="block text-xs text-slate-400 mb-1">
                  Android Package ID
                </span>
                <input
                  type="text"
                  readOnly
                  value={config.packageId}
                  className="w-full bg-slate-950 text-slate-300 font-mono text-xs rounded-xl px-3 py-2 border border-slate-800"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <span className="block text-xs text-slate-400 mb-1">
                    Export Format
                  </span>
                  <select
                    value={exportFormat}
                    onChange={(e) => setExportFormat(e.target.value as "aab" | "apk")}
                    className="w-full bg-slate-900 text-white text-xs rounded-xl px-3 py-2 border border-slate-700"
                  >
                    <option value="aab">AAB (App Bundle - Play Store)</option>
                    <option value="apk">APK (Universal Sideload)</option>
                  </select>
                </div>
                <div>
                  <span className="block text-xs text-slate-400 mb-1">
                    Target SDK (API Level)
                  </span>
                  <input
                    type="number"
                    value={targetSdk}
                    onChange={(e) => setTargetSdk(Number(e.target.value) || 35)}
                    className="w-full bg-slate-900 text-white text-xs rounded-xl px-3 py-2 border border-slate-700"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <span className="block text-xs text-slate-400 mb-1">
                    Version Name
                  </span>
                  <input
                    type="text"
                    value={versionName}
                    onChange={(e) => setVersionName(e.target.value)}
                    className="w-full bg-slate-900 text-white text-xs rounded-xl px-3 py-2 border border-slate-700"
                  />
                </div>
                <div>
                  <span className="block text-xs text-slate-400 mb-1">
                    Version Code
                  </span>
                  <input
                    type="number"
                    value={versionCode}
                    onChange={(e) => setVersionCode(Number(e.target.value) || 1)}
                    className="w-full bg-slate-900 text-white text-xs rounded-xl px-3 py-2 border border-slate-700"
                  />
                </div>
              </div>
            </div>

            {/* Summary Banner */}
            <div className="p-4 rounded-2xl bg-purple-950/30 border border-purple-500/30">
              <div className="flex items-center justify-between text-xs text-purple-200 mb-2">
                <span className="font-bold">Estimated {exportFormat.toUpperCase()} Bundle Size</span>
                <span className="font-black text-purple-300 text-sm">
                  ~{(manifest.bundleSizeEstimateKb / 1024).toFixed(2)} MB
                </span>
              </div>
              <p className="text-[11px] text-slate-400">
                {targetType === "platform"
                  ? "Includes Reusable Engine + All 50 Game Roadmaps."
                  : `Tree-shaked build containing only [${config.appName}] + Engine.`}
              </p>
            </div>
          </div>

          {/* Right Panel: Output File Inspection (7 Cols) */}
          <div className="md:col-span-7 flex flex-col h-full bg-slate-950/70">
            {/* File Switcher Tabs */}
            <div className="flex flex-wrap items-center gap-1.5 px-6 py-3 border-b border-slate-800 bg-slate-900/60 text-xs">
              <button
                onClick={() => setActiveCodeTab("report")}
                className={`px-3 py-1.5 rounded-lg font-medium transition ${
                  activeCodeTab === "report"
                    ? "bg-purple-600 text-white"
                    : "text-slate-400 hover:text-white"
                }`}
              >
                Tree-Shaking Report
              </button>
              <button
                onClick={() => setActiveCodeTab("manifest")}
                className={`px-3 py-1.5 rounded-lg font-medium transition ${
                  activeCodeTab === "manifest"
                    ? "bg-purple-600 text-white"
                    : "text-slate-400 hover:text-white"
                }`}
              >
                AndroidManifest.xml
              </button>
              <button
                onClick={() => setActiveCodeTab("gradle")}
                className={`px-3 py-1.5 rounded-lg font-medium transition ${
                  activeCodeTab === "gradle"
                    ? "bg-purple-600 text-white"
                    : "text-slate-400 hover:text-white"
                }`}
              >
                build.gradle.kts
              </button>
              <button
                onClick={() => setActiveCodeTab("capacitor")}
                className={`px-3 py-1.5 rounded-lg font-medium transition ${
                  activeCodeTab === "capacitor"
                    ? "bg-purple-600 text-white"
                    : "text-slate-400 hover:text-white"
                }`}
              >
                capacitor.config.ts
              </button>
              <button
                onClick={() => setActiveCodeTab("pwa")}
                className={`px-3 py-1.5 rounded-lg font-medium transition ${
                  activeCodeTab === "pwa"
                    ? "bg-purple-600 text-white"
                    : "text-slate-400 hover:text-white"
                }`}
              >
                manifest.webmanifest
              </button>
            </div>

            {/* Code Output Viewer */}
            <div className="flex-1 overflow-auto p-6 font-mono text-xs">
              {activeCodeTab === "report" && (
                <div className="space-y-4">
                  <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl">
                    <h4 className="text-sm font-bold text-white mb-2 flex items-center gap-2">
                      <Sparkles className="w-4 h-4 text-purple-400" />
                      <span>Compile-Time Tree-Shaking Summary</span>
                    </h4>
                    <p className="text-xs text-slate-400">
                      Target: <strong className="text-white">{config.appName}</strong> (
                      <code>{config.packageId}</code>) • API Level 35 • {exportFormat.toUpperCase()}
                    </p>
                  </div>

                  <div className="space-y-2">
                    {manifest.treeShakingReport.map((line, idx) => (
                      <div
                        key={idx}
                        className={`p-3 rounded-lg border text-xs ${
                          line.includes("EXCLUDED")
                            ? "bg-rose-950/20 border-rose-800/40 text-rose-300"
                            : "bg-emerald-950/20 border-emerald-800/40 text-emerald-300"
                        }`}
                      >
                        {line}
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {activeCodeTab === "manifest" && (
                <pre className="text-slate-300 whitespace-pre-wrap leading-relaxed">
                  {manifest.androidManifestXml}
                </pre>
              )}

              {activeCodeTab === "gradle" && (
                <pre className="text-slate-300 whitespace-pre-wrap leading-relaxed">
                  {manifest.buildGradleKts}
                </pre>
              )}

              {activeCodeTab === "capacitor" && (
                <pre className="text-slate-300 whitespace-pre-wrap leading-relaxed">
                  {manifest.capacitorConfigTs}
                </pre>
              )}

              {activeCodeTab === "pwa" && (
                <pre className="text-slate-300 whitespace-pre-wrap leading-relaxed">
                  {manifest.pwaManifestJson}
                </pre>
              )}
            </div>

            {/* Action Bar */}
            <div className="p-4 border-t border-slate-800 bg-slate-950 flex items-center justify-between">
              <div>
                {isSaved && (
                  <span className="flex items-center gap-1.5 text-xs text-emerald-400">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Saved to PostgreSQL Build Logs & Exported JSON</span>
                  </span>
                )}
              </div>

              <div className="flex gap-2">
                <button
                  onClick={onClose}
                  className="px-5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-medium text-sm transition"
                >
                  Close
                </button>
                <button
                  onClick={handleSaveAndExport}
                  className="flex items-center gap-2 px-6 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-semibold text-sm shadow-lg transition"
                >
                  <Download className="w-4 h-4" />
                  <span>Generate & Download Build Manifest</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
