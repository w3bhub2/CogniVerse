"use client";

import React, { useState, useEffect, useRef } from "react";
import { PuzzleEngine } from "@/engine/engine";
import { GameDifficulty, GameModule, EngineSnapshot, GameHint } from "@/engine/types";
import { audioService } from "@/services/audio.service";
import { hapticsService } from "@/services/haptics.service";
import { storageService } from "@/services/storage.service";
import { achievementsService } from "@/services/achievements.service";
import { monetizationService } from "@/services/monetization.service";
import {
  Trophy,
  RotateCcw,
  Undo2,
  Redo2,
  Sparkles,
  Play,
  Pause,
  Volume2,
  VolumeX,
  Vibrate,
  VibrateOff,
  CheckCircle2,
  HelpCircle,
  Award,
  ArrowLeft,
  Coins,
  ChevronRight,
} from "lucide-react";
import confetti from "canvas-confetti";

interface GameViewProps {
  module: GameModule<any, any>;
  difficulty: GameDifficulty;
  onDifficultyChange: (diff: GameDifficulty) => void;
  onBackToHub: () => void;
}

export function GameView({
  module,
  difficulty,
  onDifficultyChange,
  onBackToHub,
}: GameViewProps) {
  const [engine, setEngine] = useState<PuzzleEngine<any> | null>(null);
  const [snapshot, setSnapshot] = useState<EngineSnapshot<any> | null>(null);
  const [activeHint, setActiveHint] = useState<GameHint | null>(null);
  const [soundMuted, setSoundMuted] = useState(audioService.isMuted());
  const [hapticsEnabled, setHapticsEnabled] = useState(hapticsService.isEnabled());
  const [coins, setCoins] = useState(monetizationService.getCoins());
  
  // Game state controllers
  const [selectedCell, setSelectedCell] = useState<{ row: number; col: number } | null>({ row: 0, col: 0 });
  const [dragStart, setDragStart] = useState<{ row: number; col: number } | null>(null);
  const [dragCurrent, setDragEnd] = useState<{ row: number; col: number } | null>(null);
  const [jigsawSelectedId, setJigsawSelectedId] = useState<number | null>(null);
  const [isNotesMode, setIsNotesMode] = useState(false);
  const [showWinModal, setShowWinModal] = useState(false);

  // Initialize or re-initialize engine when module or difficulty changes
  useEffect(() => {
    const newEngine = new PuzzleEngine(module, difficulty, (snap) => {
      setSnapshot({ ...snap });
      if (snap.isWon) {
        // Explode beautiful gold & sapphire confetti
        confetti({
          particleCount: 120,
          spread: 80,
          colors: ["#F59E0B", "#3B82F6", "#10B981", "#EC4899"],
          origin: { y: 0.6 },
        });
        audioService.play("victory");
        hapticsService.vibrate("success");
        setShowWinModal(true);
        monetizationService.addCoins(100);
      }
    });

    const saved = storageService.loadGameSnapshot(module.id);
    if (saved && !saved.isCompleted && saved.difficulty === difficulty) {
      newEngine.loadState(saved);
    }

    setEngine(newEngine);
    setSnapshot(newEngine.getSnapshot());
    setActiveHint(null);
    setShowWinModal(false);

    const unsubCoins = monetizationService.subscribe(() => {
      setCoins(monetizationService.getCoins());
    });

    return () => {
      newEngine.destroy();
      unsubCoins();
    };
  }, [module, difficulty]);

  // Keyboard shortcut listener for grid control
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (!engine || !snapshot || snapshot.isPaused || snapshot.isCompleted) return;

      if (module.id === "2048") {
        let dir: "up" | "down" | "left" | "right" | null = null;
        if (e.key === "ArrowUp" || e.key === "w" || e.key === "W") dir = "up";
        if (e.key === "ArrowDown" || e.key === "s" || e.key === "S") dir = "down";
        if (e.key === "ArrowLeft" || e.key === "a" || e.key === "A") dir = "left";
        if (e.key === "ArrowRight" || e.key === "d" || e.key === "D") dir = "right";

        if (dir) {
          e.preventDefault();
          handle2048Move(dir);
        }
      } else if (module.id === "sudoku" && selectedCell) {
        const num = parseInt(e.key, 10);
        if (num >= 1 && num <= 9) {
          e.preventDefault();
          handleSudokuInput(num);
        } else if (e.key === "Backspace" || e.key === "Delete" || e.key === "0") {
          e.preventDefault();
          handleSudokuInput(0);
        }
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [engine, snapshot, module.id, selectedCell, isNotesMode]);

  // Game specific move handlers
  const handle2048Move = (direction: "up" | "down" | "left" | "right") => {
    if (!engine || !snapshot) return;
    const state = snapshot.state;
    
    // Import 2048 specific merge rules
    const { simulateMove, addRandomTile, hasValidMoves } = require("@/games/2048");
    const sim = simulateMove(state.grid, direction);

    if (sim.moved) {
      const newGrid = sim.grid.map((r: any) => [...r]);
      addRandomTile(newGrid, difficulty);

      let highest = state.bestTile;
      for (let r = 0; r < 4; r++) {
        for (let c = 0; c < 4; c++) {
          if (newGrid[r][c] > highest) highest = newGrid[r][c];
        }
      }

      const nextState = {
        grid: newGrid,
        score: state.score + sim.scoreGain,
        bestTile: highest,
        won: highest >= 2048 || state.won,
        gameOver: !hasValidMoves(newGrid) && highest < 2048,
      };

      engine.makeMove(nextState);
      audioService.play(sim.scoreGain > 0 ? "merge" : "move");
      setActiveHint(null);
    }
  };

  const handleSudokuInput = (value: number) => {
    if (!engine || !snapshot || !selectedCell) return;
    const state = snapshot.state;
    const cell = state.grid[selectedCell.row][selectedCell.col];

    if (cell.isGiven) {
      audioService.play("error");
      hapticsService.vibrate("error");
      return;
    }

    const newGrid = state.grid.map((row: any) =>
      row.map((c: any) => ({ ...c, notes: [...c.notes] }))
    );
    const target = newGrid[selectedCell.row][selectedCell.col];

    if (isNotesMode && value !== 0) {
      const idx = target.notes.indexOf(value);
      if (idx > -1) {
        target.notes.splice(idx, 1);
      } else {
        target.notes.push(value);
      }
    } else {
      target.value = value;
      target.notes = [];
      target.isError = value !== 0 && value !== target.solution;
    }

    let completed = 0;
    let mistakes = state.mistakes;
    if (target.isError) {
      mistakes += 1;
      audioService.play("error");
      hapticsService.vibrate("heavy");
    } else {
      audioService.play("click");
      hapticsService.vibrate("light");
    }

    for (let r = 0; r < 9; r++) {
      for (let c = 0; c < 9; c++) {
        if (newGrid[r][c].value !== 0 && !newGrid[r][c].isError) completed++;
      }
    }

    const nextState = {
      ...state,
      grid: newGrid,
      mistakes,
      completedCells: completed,
    };

    engine.makeMove(nextState);
    setActiveHint(null);
  };

  const handleCrosswordInput = (row: number, col: number, char: string) => {
    if (!engine || !snapshot) return;
    const state = snapshot.state;
    const cell = state.grid[row][col];
    if (cell.isBlock) return;

    const newGrid = state.grid.map((r: any) => r.map((c: any) => ({ ...c })));
    newGrid[row][col].userValue = char.toUpperCase();

    const nextState = {
      ...state,
      grid: newGrid,
    };
    engine.makeMove(nextState);
    audioService.play("click");
    setActiveHint(null);
  };

  // Drag selection logic for Word Search with clean SVG trail tracking
  const handleWordSearchMouseDown = (row: number, col: number) => {
    setDragStart({ row, col });
    setDragEnd({ row, col });
    audioService.play("click");
  };

  const handleWordSearchMouseEnter = (row: number, col: number) => {
    if (dragStart) {
      setDragEnd({ row, col });
    }
  };

  const handleWordSearchMouseUp = () => {
    if (!engine || !snapshot || !dragStart || !dragCurrent) {
      setDragStart(null);
      setDragEnd(null);
      return;
    }

    const state = snapshot.state;
    const s = dragStart;
    const e = dragCurrent;

    const foundWord = state.words.find(
      (w: any) =>
        !w.found &&
        ((w.startCell.row === s.row &&
          w.startCell.col === s.col &&
          w.endCell.row === e.row &&
          w.endCell.col === e.col) ||
          (w.startCell.row === e.row &&
            w.startCell.col === e.col &&
            w.endCell.row === s.row &&
            w.endCell.col === s.col))
    );

    if (foundWord) {
      const newWords = state.words.map((w: any) =>
        w.id === foundWord.id ? { ...w, found: true } : w
      );

      const newFoundCells = [...state.foundCells];
      const dRow = Math.sign(foundWord.endCell.row - foundWord.startCell.row);
      const dCol = Math.sign(foundWord.endCell.col - foundWord.startCell.col);
      for (let i = 0; i < foundWord.word.length; i++) {
        newFoundCells.push({
          row: foundWord.startCell.row + i * dRow,
          col: foundWord.startCell.col + i * dCol,
        });
      }

      const nextState = {
        ...state,
        words: newWords,
        foundCells: newFoundCells,
      };

      engine.makeMove(nextState);
      audioService.play("merge");
      hapticsService.vibrate("success");
    } else {
      audioService.play("error");
      hapticsService.vibrate("light");
    }

    setDragStart(null);
    setDragEnd(null);
    setActiveHint(null);
  };

  const handleJigsawPieceClick = (idx: number) => {
    if (!engine || !snapshot) return;
    const state = snapshot.state;
    const piece = state.pieces[idx];
    if (piece.isLocked) return;

    if (jigsawSelectedId === null) {
      setJigsawSelectedId(idx);
      audioService.play("click");
    } else {
      const first = state.pieces[jigsawSelectedId];
      const second = state.pieces[idx];

      const newPieces = state.pieces.map((p: any) => ({ ...p }));
      const tempR = first.currentRow;
      const tempC = first.currentCol;

      newPieces[jigsawSelectedId].currentRow = second.currentRow;
      newPieces[jigsawSelectedId].currentCol = second.currentCol;
      newPieces[idx].currentRow = tempR;
      newPieces[idx].currentCol = tempC;

      newPieces.forEach((p: any) => {
        p.isLocked = p.currentRow === p.correctRow && p.currentCol === p.correctCol;
      });

      const nextState = {
        ...state,
        pieces: newPieces,
      };

      engine.makeMove(nextState);
      setJigsawSelectedId(null);
      setActiveHint(null);
    }
  };

  const handleSlidingTileClick = (row: number, col: number) => {
    if (!engine || !snapshot) return;
    const state = snapshot.state;

    let emptyR = -1;
    let emptyC = -1;
    for (let r = 0; r < state.rows; r++) {
      for (let c = 0; c < state.cols; c++) {
        if (state.grid[r][c] === 0) {
          emptyR = r;
          emptyC = c;
        }
      }
    }

    const isAdjacent =
      (Math.abs(row - emptyR) === 1 && col === emptyC) ||
      (Math.abs(col - emptyC) === 1 && row === emptyR);

    if (isAdjacent) {
      const newGrid = state.grid.map((r: any) => [...r]);
      newGrid[emptyR][emptyC] = newGrid[row][col];
      newGrid[row][col] = 0;

      const nextState = {
        ...state,
        grid: newGrid,
      };

      engine.makeMove(nextState);
      audioService.play("move");
      hapticsService.vibrate("light");
      setActiveHint(null);
    } else {
      audioService.play("error");
      hapticsService.vibrate("light");
    }
  };

  const handleRequestHint = () => {
    if (!engine) return;
    const hint = engine.requestHint();
    if (hint) {
      setActiveHint(hint);
    }
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
  };

  if (!engine || !snapshot) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-950 text-slate-400">
        <div className="flex flex-col items-center gap-3">
          <div className="w-12 h-12 border-4 border-indigo-500 border-t-transparent rounded-full animate-spin" />
          <p className="text-sm font-semibold tracking-wide">Initializing Core Engine...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col items-center w-full max-w-5xl mx-auto px-4 py-8 select-none">
      {/* Premium HUD bar */}
      <header className="w-full flex flex-wrap items-center justify-between gap-4 mb-6 bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-2xl backdrop-blur-md">
        <div className="flex items-center gap-3.5">
          <button
            onClick={onBackToHub}
            className="p-2 rounded-xl bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700 transition"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <h2 className="text-xl sm:text-2xl font-black text-white tracking-wide">{module.name}</h2>
            <div className="flex items-center gap-2 mt-0.5">
              <span className="text-[10px] px-2 py-0.5 rounded bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 font-bold uppercase tracking-wider">
                Phase {module.phase}
              </span>
              <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-bold uppercase tracking-wider">
                {module.category}
              </span>
            </div>
          </div>
        </div>

        {/* Real-time stats panel */}
        <div className="flex items-center gap-5 bg-slate-950 p-3 rounded-xl border border-slate-800/80">
          <div className="text-center px-1">
            <span className="block text-[9px] text-slate-500 uppercase font-black tracking-wider">
              Score
            </span>
            <span className="text-base font-black text-emerald-400 font-mono">
              {snapshot.score}
            </span>
          </div>
          <div className="w-px h-8 bg-slate-800" />
          <div className="text-center px-1">
            <span className="block text-[9px] text-slate-500 uppercase font-black tracking-wider">
              Moves
            </span>
            <span className="text-base font-black text-white font-mono">
              {snapshot.movesCount}
            </span>
          </div>
          <div className="w-px h-8 bg-slate-800" />
          <div className="text-center px-1">
            <span className="block text-[9px] text-slate-500 uppercase font-black tracking-wider">
              Time
            </span>
            <span className="text-base font-black text-amber-400 font-mono">
              {formatTime(snapshot.elapsedSeconds)}
            </span>
          </div>
        </div>

        {/* Sensory Controls */}
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1 bg-slate-800/80 px-2 py-1.5 rounded-xl border border-slate-700/60">
            <Coins className="w-4 h-4 text-amber-400" />
            <span className="text-xs font-bold text-slate-200 font-mono">{coins}</span>
          </div>
          <button
            onClick={() => {
              const muted = !soundMuted;
              setSoundMuted(muted);
              audioService.setMuted(muted);
            }}
            className="p-2.5 rounded-xl bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700 transition"
            title={soundMuted ? "Unmute Audio" : "Mute Audio"}
          >
            {soundMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
          </button>
          <button
            onClick={() => {
              const enabled = !hapticsEnabled;
              setHapticsEnabled(enabled);
              hapticsService.setEnabled(enabled);
            }}
            className="p-2.5 rounded-xl bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700 transition"
            title={hapticsEnabled ? "Disable Haptics" : "Enable Haptics"}
          >
            {hapticsEnabled ? <Vibrate className="w-4 h-4" /> : <VibrateOff className="w-4 h-4" />}
          </button>
        </div>
      </header>

      {/* Active Hint Banner */}
      {activeHint && (
        <div className="w-full mb-4 px-4 py-3 bg-amber-500/10 border border-amber-500/30 rounded-xl flex items-center justify-between text-amber-200 text-xs sm:text-sm animate-pulse">
          <div className="flex items-center gap-2.5">
            <Sparkles className="w-5 h-5 text-amber-400 shrink-0" />
            <span>{activeHint.message}</span>
          </div>
          <button
            onClick={() => setActiveHint(null)}
            className="text-xs text-amber-400 font-bold hover:underline"
          >
            Got it
          </button>
        </div>
      )}

      {/* Main Board Area */}
      <div className="relative w-full flex flex-col items-center justify-center bg-slate-900/40 border border-slate-800/80 rounded-3xl p-6 shadow-2xl min-h-[460px] backdrop-blur-sm">
        {snapshot.isPaused && (
          <div className="absolute inset-0 z-20 bg-slate-950/90 backdrop-blur-md rounded-3xl flex flex-col items-center justify-center">
            <Pause className="w-12 h-12 text-slate-500 mb-3 animate-pulse" />
            <h3 className="text-2xl font-black text-white mb-1">Game Paused</h3>
            <p className="text-xs text-slate-400 mb-5">Your timer is suspended. Ready to jump back in?</p>
            <button
              onClick={() => engine.setPaused(false)}
              className="px-6 py-3 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-extrabold text-sm shadow-lg shadow-indigo-600/30 transition-transform active:scale-95"
            >
              Resume Challenge
            </button>
          </div>
        )}

        {/* ============ GAME 1: 2048 SYSTEM ============ */}
        {module.id === "2048" && (
          <div className="flex flex-col items-center">
            <div className="grid grid-cols-4 gap-3 bg-slate-950 p-4 rounded-2xl border-2 border-slate-800/60 shadow-2xl">
              {(snapshot.state as any).grid.map((row: any, r: number) =>
                row.map((val: number, c: number) => {
                  const getTileStyles = (num: number) => {
                    switch (num) {
                      case 2:
                        return "bg-slate-800 text-slate-100 border-slate-700/60 font-bold";
                      case 4:
                        return "bg-slate-700/80 text-slate-100 border-slate-600/60 font-bold";
                      case 8:
                        return "bg-amber-600 text-white border-amber-500/80 shadow-[0_0_12px_rgba(245,158,11,0.2)]";
                      case 16:
                        return "bg-amber-500 text-slate-950 font-black border-amber-400 shadow-[0_0_15px_rgba(245,158,11,0.3)]";
                      case 32:
                        return "bg-orange-500 text-white font-black border-orange-400";
                      case 64:
                        return "bg-orange-600 text-white font-black border-orange-500";
                      case 128:
                        return "bg-emerald-500 text-slate-950 font-black border-emerald-400 shadow-md";
                      case 256:
                        return "bg-emerald-600 text-white font-black border-emerald-500 shadow-lg";
                      case 512:
                        return "bg-indigo-600 text-white font-black border-indigo-500 shadow-lg";
                      case 1024:
                        return "bg-purple-600 text-white font-black border-purple-500 shadow-xl";
                      case 2048:
                        return "bg-pink-600 text-white font-black border-pink-400 shadow-[0_0_25px_rgba(236,72,153,0.5)] animate-bounce";
                      default:
                        return "bg-gradient-to-br from-rose-600 to-pink-600 text-white font-black";
                    }
                  };

                  return (
                    <div
                      key={`${r}-${c}`}
                      className={`w-16 h-16 sm:w-20 sm:h-20 flex items-center justify-center rounded-xl border text-xl sm:text-2xl transition-all duration-150 select-none ${
                        val === 0
                          ? "bg-slate-900/40 border-slate-900"
                          : `${getTileStyles(val)} transform active:scale-105`
                      }`}
                    >
                      {val > 0 ? val : ""}
                    </div>
                  );
                })
              )}
            </div>

            {/* Tap controls for accessibility & one-handed play */}
            <div className="mt-6 flex flex-col items-center gap-1.5">
              <span className="text-[10px] text-slate-500 uppercase tracking-widest font-black mb-1">D-PAD Swipe Fallback</span>
              <button
                onClick={() => handle2048Move("up")}
                className="px-5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs font-bold border border-slate-700 transition"
              >
                ▲ UP
              </button>
              <div className="flex gap-2">
                <button
                  onClick={() => handle2048Move("left")}
                  className="px-4 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs font-bold border border-slate-700 transition"
                >
                  ◀ LEFT
                </button>
                <button
                  onClick={() => handle2048Move("down")}
                  className="px-4 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs font-bold border border-slate-700 transition"
                >
                  ▼ DOWN
                </button>
                <button
                  onClick={() => handle2048Move("right")}
                  className="px-4 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs font-bold border border-slate-700 transition"
                >
                  ▶ RIGHT
                </button>
              </div>
            </div>
          </div>
        )}

        {/* ============ GAME 2: SUDOKU SYSTEM ============ */}
        {module.id === "sudoku" && (
          <div className="flex flex-col items-center">
            {/* Sudoku grid */}
            <div className="grid grid-cols-9 bg-slate-950 p-2.5 rounded-2xl border-2 border-slate-800 shadow-2xl">
              {(snapshot.state as any).grid.map((row: any, r: number) =>
                row.map((cell: any, c: number) => {
                  const isSelected = selectedCell?.row === r && selectedCell?.col === c;
                  const isHintHighlight = activeHint?.highlightCells?.some(
                    (h) => h.row === r && h.col === c
                  );
                  const isRightBlock = c === 2 || c === 5;
                  const isBottomBlock = r === 2 || r === 5;

                  return (
                    <button
                      key={`${r}-${c}`}
                      onClick={() => setSelectedCell({ row: r, col: c })}
                      className={`w-9 h-9 sm:w-11 sm:h-11 flex flex-col items-center justify-center text-sm sm:text-base font-bold transition relative ${
                        isRightBlock ? "border-r-2 border-r-slate-600" : "border-r border-r-slate-850"
                      } ${
                        isBottomBlock ? "border-b-2 border-b-slate-600" : "border-b border-b-slate-850"
                      } ${
                        isSelected
                          ? "bg-indigo-600 text-white ring-2 ring-indigo-400 z-10 scale-105"
                          : isHintHighlight
                            ? "bg-amber-500/20 text-amber-200"
                            : cell.isError
                              ? "bg-rose-500/20 text-rose-400 font-black"
                              : cell.isGiven
                                ? "bg-slate-800/60 text-slate-300"
                                : "bg-slate-900/40 text-indigo-300 hover:bg-slate-800/40"
                      }`}
                    >
                      {cell.value > 0 ? (
                        cell.value
                      ) : cell.notes.length > 0 ? (
                        <div className="grid grid-cols-3 gap-0.5 text-[8px] text-slate-400 scale-90 leading-none">
                          {[1, 2, 3, 4, 5, 6, 7, 8, 9].map((num) => (
                            <span key={num} className="h-2 w-2 flex items-center justify-center">
                              {cell.notes.includes(num) ? num : ""}
                            </span>
                          ))}
                        </div>
                      ) : null}
                    </button>
                  );
                })
              )}
            </div>

            {/* Input Pad */}
            <div className="mt-5 flex flex-wrap items-center justify-center gap-1.5 sm:gap-2">
              {[1, 2, 3, 4, 5, 6, 7, 8, 9].map((num) => (
                <button
                  key={num}
                  onClick={() => handleSudokuInput(num)}
                  className="w-10 h-10 sm:w-11 sm:h-11 rounded-xl bg-slate-800 hover:bg-indigo-650 text-white font-extrabold border border-slate-700 transition transform active:scale-95"
                >
                  {num}
                </button>
              ))}
              <button
                onClick={() => handleSudokuInput(0)}
                className="px-3.5 h-10 sm:h-11 rounded-xl bg-slate-850 hover:bg-rose-600 text-white text-xs font-bold border border-slate-700 transition"
              >
                Erase
              </button>
              <button
                onClick={() => setIsNotesMode(!isNotesMode)}
                className={`px-4 h-10 sm:h-11 rounded-xl font-bold text-xs border transition ${
                  isNotesMode
                    ? "bg-indigo-600 border-indigo-400 text-white"
                    : "bg-slate-850 border-slate-700 text-slate-400"
                }`}
              >
                Pencil: {isNotesMode ? "ON" : "OFF"}
              </button>
            </div>
            <div className="mt-3 text-xs text-slate-400">
              Mistakes registered: <strong className="text-rose-400 font-mono">{(snapshot.state as any).mistakes}</strong> / {(snapshot.state as any).maxMistakes}
            </div>
          </div>
        )}

        {/* ============ GAME 3: CROSSWORD SYSTEM ============ */}
        {module.id === "crossword" && (
          <div className="flex flex-col md:flex-row items-center md:items-start gap-8 w-full max-w-3xl">
            <div className="grid grid-cols-5 bg-slate-950 p-3 rounded-2xl border-2 border-slate-850 shadow-2xl">
              {(snapshot.state as any).grid.map((row: any, r: number) =>
                row.map((cell: any, c: number) => (
                  <div
                    key={`${r}-${c}`}
                    className={`w-12 h-12 sm:w-14 sm:h-14 relative flex items-center justify-center border border-slate-850 transition-all ${
                      cell.isBlock ? "bg-slate-950" : "bg-slate-900 hover:bg-slate-850 text-white font-bold"
                    }`}
                  >
                    {cell.numberLabel && (
                      <span className="absolute top-1 left-1.5 text-[9px] text-slate-500 font-black">
                        {cell.numberLabel}
                      </span>
                    )}
                    {!cell.isBlock && (
                      <input
                        type="text"
                        maxLength={1}
                        value={cell.userValue}
                        onChange={(e) => handleCrosswordInput(r, c, e.target.value)}
                        className="w-full h-full text-center bg-transparent text-white font-black text-lg focus:outline-none focus:bg-indigo-600/30 rounded"
                      />
                    )}
                  </div>
                ))
              )}
            </div>

            {/* Right side clues panel */}
            <div className="flex-1 space-y-4 max-h-72 overflow-y-auto pr-2 w-full">
              <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800">
                <h4 className="text-xs font-black uppercase tracking-wider text-indigo-400 mb-2.5">
                  Across Clues
                </h4>
                <ul className="space-y-1.5 text-xs text-slate-300">
                  {(snapshot.state as any).clues
                    .filter((c: any) => c.direction === "across")
                    .map((clue: any) => (
                      <li key={clue.id} className="flex gap-2 leading-relaxed">
                        <span className="font-extrabold text-indigo-400 font-mono">{clue.number}.</span>
                        <span>{clue.clue}</span>
                      </li>
                    ))}
                </ul>
              </div>
              <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800">
                <h4 className="text-xs font-black uppercase tracking-wider text-emerald-400 mb-2.5">
                  Down Clues
                </h4>
                <ul className="space-y-1.5 text-xs text-slate-300">
                  {(snapshot.state as any).clues
                    .filter((c: any) => c.direction === "down")
                    .map((clue: any) => (
                      <li key={clue.id} className="flex gap-2 leading-relaxed">
                        <span className="font-extrabold text-emerald-400 font-mono">{clue.number}.</span>
                        <span>{clue.clue}</span>
                      </li>
                    ))}
                </ul>
              </div>
            </div>
          </div>
        )}

        {/* ============ GAME 4: WORD SEARCH SYSTEM ============ */}
        {module.id === "word-search" && (
          <div className="flex flex-col md:flex-row items-center md:items-start gap-8 w-full max-w-3xl">
            {/* Word matrix with drag trails */}
            <div className="relative">
              <div className="grid grid-cols-8 bg-slate-950 p-4 rounded-3xl border-2 border-slate-850 shadow-2xl gap-1">
                {(snapshot.state as any).grid.map((row: any, r: number) =>
                  row.map((char: string, c: number) => {
                    const isFound = (snapshot.state as any).foundCells.some(
                      (fc: any) => fc.row === r && fc.col === c
                    );
                    const isSelected =
                      (dragStart?.row === r && dragStart?.col === c) ||
                      (dragCurrent?.row === r && dragCurrent?.col === c);

                    return (
                      <div
                        key={`${r}-${c}`}
                        onMouseDown={() => handleWordSearchMouseDown(r, c)}
                        onMouseEnter={() => handleWordSearchMouseEnter(r, c)}
                        onMouseUp={handleWordSearchMouseUp}
                        className={`w-9 h-9 sm:w-11 sm:h-11 flex items-center justify-center rounded-xl font-black text-sm sm:text-base transition-all cursor-crosshair ${
                          isSelected
                            ? "bg-amber-500 text-slate-950 scale-105"
                            : isFound
                              ? "bg-emerald-600/80 text-white shadow-md shadow-emerald-600/10"
                              : "bg-slate-900 text-slate-300 hover:bg-slate-800"
                        }`}
                      >
                        {char}
                      </div>
                    );
                  })
                )}
              </div>
            </div>

            {/* Checklist */}
            <div className="flex-1 w-full space-y-4">
              <h4 className="text-xs font-black uppercase tracking-wider text-purple-400">
                Thematic Words Matrix
              </h4>
              <ul className="grid grid-cols-2 gap-2">
                {(snapshot.state as any).words.map((w: any) => (
                  <li
                    key={w.id}
                    className={`flex items-center justify-between px-3.5 py-2.5 rounded-xl border text-xs font-bold transition ${
                      w.found
                        ? "bg-emerald-950/40 border-emerald-700/60 text-emerald-300 line-through"
                        : "bg-slate-950/60 border-slate-800 text-slate-200"
                    }`}
                  >
                    <span>{w.word}</span>
                    {w.found && <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />}
                  </li>
                ))}
              </ul>
              <p className="text-[10px] text-slate-500 leading-normal">
                Instruction: Drag your pointer from the start letter to the end letter of any word horizontally or vertically.
              </p>
            </div>
          </div>
        )}

        {/* ============ GAME 5: JIGSAW PUZZLE SYSTEM ============ */}
        {module.id === "jigsaw" && (
          <div className="flex flex-col items-center">
            <div className="grid grid-cols-3 gap-2.5 bg-slate-950 p-4 rounded-3xl border-2 border-slate-850 shadow-2xl">
              {(snapshot.state as any).pieces.map((piece: any, idx: number) => {
                const isSelected = jigsawSelectedId === idx;
                return (
                  <button
                    key={piece.id}
                    onClick={() => handleJigsawPieceClick(idx)}
                    style={{ backgroundColor: piece.colorHex }}
                    className={`w-20 h-20 sm:w-24 sm:h-24 rounded-2xl flex flex-col items-center justify-center text-slate-950 font-black text-lg transition-transform relative ${
                      isSelected
                        ? "ring-4 ring-white scale-105 z-10 shadow-2xl"
                        : piece.isLocked
                          ? "opacity-90 cursor-default"
                          : "hover:scale-102"
                    }`}
                  >
                    <span>{piece.label}</span>
                    {piece.isLocked && (
                      <CheckCircle2 className="w-5 h-5 text-slate-950 absolute top-2 right-2" />
                    )}
                  </button>
                );
              })}
            </div>
            <p className="mt-4 text-xs text-slate-400">
              Click any two unlocked tiles to swap and fit the visual gradient mosaic.
            </p>
          </div>
        )}

        {/* ============ GAME 6: SLIDING PUZZLE SYSTEM ============ */}
        {module.id === "sliding-puzzle" && (
          <div className="flex flex-col items-center">
            <div
              className={`grid gap-2.5 bg-slate-950 p-4 rounded-3xl border-2 border-slate-850 shadow-2xl ${
                (snapshot.state as any).cols === 3
                  ? "grid-cols-3"
                  : "grid-cols-4"
              }`}
            >
              {(snapshot.state as any).grid.map((row: any, r: number) =>
                row.map((val: number, c: number) => (
                  <button
                    key={`${r}-${c}`}
                    onClick={() => handleSlidingTileClick(r, c)}
                    disabled={val === 0}
                    className={`w-16 h-16 sm:w-20 sm:h-20 flex items-center justify-center rounded-xl font-black text-xl sm:text-2xl transition-transform transform active:scale-105 ${
                      val === 0
                        ? "bg-slate-950/20 border-2 border-dashed border-slate-850 cursor-default"
                        : "bg-gradient-to-br from-cyan-600 to-blue-700 text-white hover:scale-102 shadow-lg shadow-cyan-600/10"
                    }`}
                  >
                    {val > 0 ? val : ""}
                  </button>
                ))
              )}
            </div>
            <p className="mt-4 text-xs text-slate-400">
              Slide numbered tiles into numerical order around the single empty square.
            </p>
          </div>
        )}
      </div>

      {/* Action Toolbar */}
      <footer className="w-full flex flex-wrap items-center justify-between gap-4 mt-6">
        <div className="flex items-center gap-2">
          <button
            onClick={() => engine.undo()}
            disabled={!engine.canUndo()}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 disabled:opacity-40 text-slate-200 font-bold text-xs border border-slate-700 transition"
          >
            <Undo2 className="w-4 h-4" />
            <span>Undo</span>
          </button>
          <button
            onClick={() => engine.redo()}
            disabled={!engine.canRedo()}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 disabled:opacity-40 text-slate-200 font-bold text-xs border border-slate-700 transition"
          >
            <Redo2 className="w-4 h-4" />
            <span>Redo</span>
          </button>
          <button
            onClick={handleRequestHint}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-indigo-600/20 hover:bg-indigo-600/30 text-indigo-300 font-bold text-xs border border-indigo-500/30 transition"
          >
            <HelpCircle className="w-4 h-4" />
            <span>Request Hint</span>
          </button>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => engine.resetGame()}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs border border-slate-700 transition"
          >
            <RotateCcw className="w-4 h-4" />
            <span>Reset</span>
          </button>
          <button
            onClick={onBackToHub}
            className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-black text-xs shadow-lg transition"
          >
            Back to Hub
          </button>
        </div>
      </footer>

      {/* Victory Celebration Modal */}
      {showWinModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-md p-4 animate-fade-in">
          <div className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-3xl p-8 text-center shadow-2xl scale-up">
            <div className="w-16 h-16 mx-auto mb-4 rounded-2xl bg-gradient-to-br from-amber-500 to-indigo-600 flex items-center justify-center text-white shadow-lg shadow-amber-500/25">
              <Award className="w-10 h-10" />
            </div>
            <h3 className="text-2xl font-black text-white mb-2">Puzzle Solved!</h3>
            <p className="text-sm text-slate-400 mb-6">
              You cleared the {module.name} puzzle under {difficulty.toUpperCase()} constraint!
            </p>

            <div className="grid grid-cols-3 gap-2.5 bg-slate-950 p-4 rounded-2xl border border-slate-800 mb-6 text-xs font-mono">
              <div>
                <span className="block text-[9px] text-slate-500 uppercase font-bold tracking-wider">Score</span>
                <span className="font-bold text-emerald-400 text-sm">{snapshot.score}</span>
              </div>
              <div>
                <span className="block text-[9px] text-slate-500 uppercase font-bold tracking-wider">Moves</span>
                <span className="font-bold text-white text-sm">{snapshot.movesCount}</span>
              </div>
              <div>
                <span className="block text-[9px] text-slate-500 uppercase font-bold tracking-wider">Time</span>
                <span className="font-bold text-amber-400 text-sm">
                  {formatTime(snapshot.elapsedSeconds)}
                </span>
              </div>
            </div>

            <div className="flex gap-3">
              <button
                onClick={() => {
                  setShowWinModal(false);
                  engine.resetGame();
                }}
                className="flex-1 py-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs transition"
              >
                Play Again
              </button>
              <button
                onClick={onBackToHub}
                className="flex-1 py-3 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-black text-xs shadow-lg transition"
              >
                Return to Hub
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
