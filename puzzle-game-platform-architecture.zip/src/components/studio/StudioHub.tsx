"use client";

import React, { useState, useEffect } from "react";
import { getPlayableGames, getGameModuleById } from "@/engine/registry";
import { GameModule, GameDifficulty } from "@/engine/types";
import { GameView } from "./GameView";
import { ArchitectureDocsModal } from "./ArchitectureDocsModal";
import { BuildExporterModal } from "./BuildExporterModal";
import { TelemetryModal } from "./TelemetryModal";
import { CampaignModal } from "./CampaignModal";
import { DeepScoreModal } from "./DeepScoreModal";
import { ProfileModal } from "./ProfileModal";
import { SaveConflictModal } from "./SaveConflictModal";
import { CampaignChapter } from "@/engine/campaign";
import { getDailyChallengeSpec, DailyChallengeSpec } from "@/engine/daily";
import { themesService, STUDIO_THEMES } from "@/services/themes.service";
import { StudioTheme } from "@/services/types";
import { monetizationService } from "@/services/monetization.service";
import { storageService, SaveConflictData } from "@/services/storage.service";
import { liveOpsService, SeasonInfo } from "@/services/liveops.service";
import {
  Gamepad2,
  BookOpen,
  Package,
  Activity,
  Sparkles,
  Trophy,
  Grid3X3,
  Hash,
  Search,
  Puzzle,
  LayoutGrid,
  ChevronRight,
  Palette,
  ShieldCheck,
  Zap,
  Map,
  Award,
  Calendar,
  Flame,
  Play,
  User,
  Volume2,
  AlertTriangle,
} from "lucide-react";

export function StudioHub() {
  const [activeModule, setActiveModule] = useState<GameModule<any, any> | null>(null);
  const [difficulty, setDifficulty] = useState<GameDifficulty>("medium");
  const [activeModal, setActiveModal] = useState<
    "docs" | "exporter" | "telemetry" | "campaign" | "scorecard" | "profile" | null
  >(null);
  const [saveConflict, setSaveConflict] = useState<SaveConflictData | null>(null);
  const [currentTheme, setCurrentTheme] = useState<StudioTheme>(
    themesService.getActiveTheme()
  );
  const [coins, setCoins] = useState(monetizationService.getCoins());
  const [adFree, setAdFree] = useState(monetizationService.isAdFree());
  const [dailySpec, setDailySpec] = useState<DailyChallengeSpec>(getDailyChallengeSpec());
  const [season, setSeason] = useState<SeasonInfo>(liveOpsService.getCurrentSeason());

  const playableGames = getPlayableGames();

  useEffect(() => {
    const unsubTheme = themesService.subscribe((th) => {
      setCurrentTheme(th);
    });
    const unsubMonetization = monetizationService.subscribe(() => {
      setCoins(monetizationService.getCoins());
      setAdFree(monetizationService.isAdFree());
    });
    setDailySpec(getDailyChallengeSpec());
    setSeason(liveOpsService.getCurrentSeason());

    // Register save conflict callback
    storageService.setConflictCallback((conflictData) => {
      setSaveConflict(conflictData);
    });

    return () => {
      unsubTheme();
      unsubMonetization();
    };
  }, []);

  // Helper to render icon for game card
  const renderGameIcon = (iconName: string) => {
    switch (iconName) {
      case "Grid3x3":
        return <Grid3X3 className="w-6 h-6 text-amber-400" />;
      case "Hash":
        return <Hash className="w-6 h-6 text-blue-400" />;
      case "BookOpen":
        return <BookOpen className="w-6 h-6 text-emerald-400" />;
      case "Search":
        return <Search className="w-6 h-6 text-purple-400" />;
      case "Puzzle":
        return <Puzzle className="w-6 h-6 text-pink-400" />;
      case "LayoutGrid":
        return <LayoutGrid className="w-6 h-6 text-cyan-400" />;
      default:
        return <Gamepad2 className="w-6 h-6 text-indigo-400" />;
    }
  };

  const handleLaunchChapterGame = (mod: GameModule<any, any>, chapter: CampaignChapter) => {
    setDifficulty(chapter.difficulty);
    setActiveModule(mod);
  };

  const handleLaunchDailyGame = () => {
    const mod = getGameModuleById(dailySpec.gameId);
    if (mod) {
      setDifficulty(dailySpec.difficulty);
      setActiveModule(mod);
    }
  };

  const handleResolveConflict = (chosen: "local" | "cloud") => {
    if (!saveConflict) return;
    const selectedSnapshot =
      chosen === "local" ? saveConflict.localSnapshot : saveConflict.cloudSnapshot;
    storageService.resolveSaveConflict(saveConflict.gameId, selectedSnapshot);
    setSaveConflict(null);
  };

  // If a game is active, show interactive GameView
  if (activeModule) {
    return (
      <div className={`min-h-screen ${currentTheme.bgClass} transition-colors duration-200`}>
        <GameView
          module={activeModule}
          difficulty={difficulty}
          onDifficultyChange={(d) => setDifficulty(d)}
          onBackToHub={() => setActiveModule(null)}
        />
      </div>
    );
  }

  return (
    <div className={`min-h-screen ${currentTheme.bgClass} transition-colors duration-200`}>
      {/* Top Studio Bar */}
      <header className="border-b border-slate-800/80 bg-slate-950/85 backdrop-blur-lg sticky top-0 z-30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4 flex flex-wrap items-center justify-between gap-4">
          {/* Logo & Studio Title */}
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-2xl bg-gradient-to-tr from-indigo-500 via-purple-500 to-pink-500 text-white shadow-lg">
              <Gamepad2 className="w-7 h-7" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl sm:text-2xl font-black tracking-tight text-white">
                  Puzzle Platform
                </h1>
                <span className="px-2.5 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 text-[10px] font-bold uppercase tracking-wider">
                  50+ Game Studio
                </span>
                <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[10px] font-bold uppercase tracking-wider">
                  10/10 Verified
                </span>
              </div>
              <p className="text-xs text-slate-400 font-medium">
                {season.seasonName} ({season.daysRemaining}d left) • P0-P4 Incident Runbooks Live
              </p>
            </div>
          </div>

          {/* Top Tools Bar */}
          <div className="flex flex-wrap items-center gap-2 sm:gap-3">
            {/* Player Profile & Audio Settings */}
            <button
              onClick={() => setActiveModal("profile")}
              className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-xs text-slate-200 font-bold transition shadow-sm"
              title="Player Profile & Audio Synth"
            >
              <User className="w-4 h-4 text-indigo-400" />
              <span>Profile & Audio</span>
            </button>

            {/* Visual Theme Picker */}
            <div className="relative group">
              <button
                className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-xs text-slate-300 transition"
                title="Change Studio Theme"
              >
                <Palette className="w-4 h-4 text-indigo-400" />
                <span className="hidden sm:inline">{currentTheme.name}</span>
              </button>
              <div className="absolute right-0 mt-2 w-48 bg-slate-900 border border-slate-800 rounded-2xl shadow-xl py-2 hidden group-hover:block z-40">
                {STUDIO_THEMES.map((th) => (
                  <button
                    key={th.id}
                    onClick={() => themesService.setTheme(th.id)}
                    className={`w-full text-left px-4 py-2 text-xs transition ${
                      currentTheme.id === th.id
                        ? "bg-indigo-600/20 text-indigo-300 font-bold"
                        : "text-slate-300 hover:bg-slate-800"
                    }`}
                  >
                    {th.name}
                  </button>
                ))}
              </div>
            </div>

            {/* Story Campaign Launcher */}
            <button
              onClick={() => setActiveModal("campaign")}
              className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 border border-amber-500/30 text-amber-300 text-xs font-semibold transition shadow-sm"
            >
              <Map className="w-4 h-4" />
              <span>Saga Campaign</span>
            </button>

            {/* 10/10 Scorecard & Automation Roadmap */}
            <button
              onClick={() => setActiveModal("scorecard")}
              className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-emerald-600/20 hover:bg-emerald-600/30 border border-emerald-500/30 text-emerald-300 text-xs font-bold transition shadow-sm"
            >
              <Award className="w-4 h-4" />
              <span>10/10 Scorecard</span>
            </button>

            {/* Documentation Modal Launcher */}
            <button
              onClick={() => setActiveModal("docs")}
              className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-indigo-600/20 hover:bg-indigo-600/30 border border-indigo-500/30 text-indigo-300 text-xs font-semibold transition shadow-sm"
            >
              <BookOpen className="w-4 h-4" />
              <span>Architecture Docs</span>
            </button>

            {/* APK Build Exporter Launcher */}
            <button
              onClick={() => setActiveModal("exporter")}
              className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-purple-600/20 hover:bg-purple-600/30 border border-purple-500/30 text-purple-300 text-xs font-semibold transition shadow-sm"
            >
              <Package className="w-4 h-4" />
              <span>APK Build Exporter</span>
            </button>

            {/* Telemetry & QA Launcher */}
            <button
              onClick={() => setActiveModal("telemetry")}
              className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-300 text-xs font-semibold transition shadow-sm"
            >
              <Activity className="w-4 h-4" />
              <span>Telemetry & FPS</span>
            </button>
          </div>
        </div>
      </header>

      {/* Main Studio Content Area */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 py-8 space-y-10">
        {/* Studio Hero / Architecture Banner with custom AI-generated image */}
        <section className="relative overflow-hidden rounded-3xl bg-slate-900 border border-slate-800/80 p-6 sm:p-10 shadow-2xl">
          {/* Background image overlay */}
          <div className="absolute inset-0 z-0 opacity-40">
            <img
              src="/images/hero-banner.jpg"
              alt="Puzzle Platform Studio Universe"
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-slate-950 via-slate-950/90 to-slate-950/40" />
          </div>

          <div className="relative z-10 max-w-3xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/20 border border-indigo-500/40 text-indigo-300 text-xs font-semibold mb-4">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Studio Story Saga • Daily Challenges • Automated Play Store Exporter</span>
            </div>
            <h2 className="text-3xl sm:text-4xl font-black text-white leading-tight">
              One Reusable Engine. <br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-amber-300 via-indigo-300 to-pink-400">
                50+ Independent Google Play Apps.
              </span>
            </h2>
            <p className="mt-3 text-sm sm:text-base text-slate-300 leading-relaxed">
              Build as the complete <strong>Puzzle Platform.apk</strong> or export tree-shaked standalone APKs like{" "}
              <strong>2048.apk</strong>, <strong>Sudoku.apk</strong>, and <strong>Crossword.apk</strong> without duplicating a single line of engine code.
            </p>

            <div className="mt-6 flex flex-wrap items-center gap-3">
              <button
                onClick={() => setActiveModal("campaign")}
                className="flex items-center gap-2 px-6 py-3 rounded-xl bg-amber-600 hover:bg-amber-500 text-white font-extrabold text-sm shadow-lg transition"
              >
                <Map className="w-4 h-4" />
                <span>Play Saga Campaign Mode</span>
              </button>
              <button
                onClick={() => setActiveModal("scorecard")}
                className="flex items-center gap-2 px-5 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-sm shadow-lg transition"
              >
                <Award className="w-4 h-4" />
                <span>View 10/10 Scorecard & Automation Plan</span>
              </button>
              <button
                onClick={() => setActiveModal("exporter")}
                className="flex items-center gap-2 px-5 py-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-sm border border-slate-700 transition"
              >
                <Package className="w-4 h-4 text-purple-400" />
                <span>Play Store Exporter</span>
              </button>
            </div>
          </div>
        </section>

        {/* Daily Challenge Banner Card */}
        <section className="p-6 rounded-3xl bg-gradient-to-r from-slate-900 via-indigo-950/40 to-slate-900 border border-indigo-500/30 flex flex-wrap items-center justify-between gap-6 shadow-xl">
          <div className="flex items-start gap-4">
            <div className="p-3 rounded-2xl bg-indigo-500/20 border border-indigo-500/40 text-indigo-400">
              <Calendar className="w-8 h-8" />
            </div>
            <div>
              <div className="flex items-center gap-2 mb-1">
                <span className="px-2.5 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 text-[11px] font-bold uppercase tracking-wider">
                  Today&apos;s Daily Seed
                </span>
                <span className="text-xs text-slate-400 font-medium">
                  {dailySpec.dateKey}
                </span>
              </div>
              <h3 className="text-lg sm:text-xl font-bold text-white">
                Daily Brain Challenge: {dailySpec.gameName} ({dailySpec.difficulty.toUpperCase()})
              </h3>
              <p className="text-xs sm:text-sm text-slate-300 mt-1">
                {dailySpec.description} • Reward: <strong className="text-amber-400">+{dailySpec.coinBonus} Coins</strong>
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={handleLaunchDailyGame}
              className="flex items-center gap-2 px-6 py-3 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-sm shadow-lg transition"
            >
              <Play className="w-4 h-4 fill-current" />
              <span>Start Daily Challenge</span>
            </button>
          </div>
        </section>

        {/* Global Difficulty Selector & Game Grid */}
        <section className="space-y-6">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div>
              <h3 className="text-2xl font-bold text-white tracking-wide">
                Phase 1 Playable Suite (6 Active Games)
              </h3>
              <p className="text-xs text-slate-400">
                Every game implements the shared <code>GameModule</code> contract and connects to studio audio, haptic, and cloud sync services.
              </p>
            </div>

            {/* Global Difficulty Switcher */}
            <div className="flex items-center gap-2 bg-slate-900/80 p-1.5 rounded-2xl border border-slate-800">
              <span className="text-xs text-slate-400 font-semibold px-2">
                Difficulty:
              </span>
              {(["easy", "medium", "hard"] as GameDifficulty[]).map((diff) => (
                <button
                  key={diff}
                  onClick={() => setDifficulty(diff)}
                  className={`px-3.5 py-1.5 rounded-xl text-xs font-bold capitalize transition ${
                    difficulty === diff
                      ? "bg-indigo-600 text-white shadow-md"
                      : "text-slate-400 hover:text-white"
                  }`}
                >
                  {diff}
                </button>
              ))}
            </div>
          </div>

          {/* Grid of 6 Games */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {playableGames.map((game) => (
              <div
                key={game.id}
                onClick={() => setActiveModule(game)}
                className="group relative bg-slate-900/80 hover:bg-slate-900 border border-slate-800 hover:border-indigo-500/50 rounded-3xl p-6 transition-all duration-200 hover:-translate-y-1 hover:shadow-2xl cursor-pointer flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800">
                      {renderGameIcon(game.iconName)}
                    </div>
                    <span className="px-2.5 py-1 rounded-full bg-slate-800/80 text-slate-400 text-[11px] font-semibold">
                      Phase {game.phase}
                    </span>
                  </div>

                  <div className="mb-3">
                    <h4 className="text-xl font-bold text-white group-hover:text-indigo-300 transition-colors">
                      {game.name}
                    </h4>
                    <span className="text-xs text-indigo-400 font-medium">
                      {game.category}
                    </span>
                  </div>

                  <p className="text-xs text-slate-400 line-clamp-2 leading-relaxed">
                    {game.description}
                  </p>
                </div>

                <div className="mt-6 pt-4 border-t border-slate-800/80 flex items-center justify-between">
                  <span className="text-[11px] font-mono text-slate-500 truncate max-w-[170px]">
                    {game.packageId}
                  </span>
                  <div className="flex items-center gap-1 text-xs font-bold text-indigo-400 group-hover:translate-x-1 transition-transform">
                    <span>Play Game</span>
                    <ChevronRight className="w-4 h-4" />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Studio Architecture & Features Showcase */}
        <section className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="p-6 rounded-3xl bg-slate-900/60 border border-slate-800/80 space-y-3">
            <div className="p-2.5 w-max rounded-xl bg-indigo-500/10 text-indigo-400">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <h4 className="text-base font-bold text-white">
              Compile-Time Tree-Shaking
            </h4>
            <p className="text-xs text-slate-400 leading-relaxed">
              When packaging a standalone APK (e.g. <code>2048.apk</code>), non-selected games are pruned automatically by our build pipeline, ensuring lightweight download sizes under 2MB.
            </p>
          </div>

          <div className="p-6 rounded-3xl bg-slate-900/60 border border-slate-800/80 space-y-3">
            <div className="p-2.5 w-max rounded-xl bg-purple-500/10 text-purple-400">
              <Zap className="w-6 h-6" />
            </div>
            <h4 className="text-base font-bold text-white">
              EventBus & Web Audio Synth
            </h4>
            <p className="text-xs text-slate-400 leading-relaxed">
              Zero external MP3 dependencies! All clicks, swooshes, victory chords, and error buzzes are synthesized in real-time via the browser Web Audio API.
            </p>
          </div>

          <div className="p-6 rounded-3xl bg-slate-900/60 border border-slate-800/80 space-y-3">
            <div className="p-2.5 w-max rounded-xl bg-emerald-500/10 text-emerald-400">
              <Trophy className="w-6 h-6" />
            </div>
            <h4 className="text-base font-bold text-white">
              Cloud Sync & Checksum Safety
            </h4>
            <p className="text-xs text-slate-400 leading-relaxed">
              Every save snapshot is checksum-verified locally and backed up to our PostgreSQL database via Drizzle ORM to protect against data corruption.
            </p>
          </div>
        </section>
      </main>

      {/* Modals */}
      {activeModal === "docs" && (
        <ArchitectureDocsModal onClose={() => setActiveModal(null)} />
      )}
      {activeModal === "exporter" && (
        <BuildExporterModal onClose={() => setActiveModal(null)} />
      )}
      {activeModal === "telemetry" && (
        <TelemetryModal onClose={() => setActiveModal(null)} />
      )}
      {activeModal === "campaign" && (
        <CampaignModal
          onClose={() => setActiveModal(null)}
          onLaunchChapterGame={handleLaunchChapterGame}
        />
      )}
      {activeModal === "scorecard" && (
        <DeepScoreModal onClose={() => setActiveModal(null)} />
      )}
      {activeModal === "profile" && (
        <ProfileModal onClose={() => setActiveModal(null)} />
      )}

      {/* Save Conflict Modal */}
      {saveConflict && (
        <SaveConflictModal
          conflict={saveConflict}
          onResolve={handleResolveConflict}
          onClose={() => setSaveConflict(null)}
        />
      )}
    </div>
  );
}
