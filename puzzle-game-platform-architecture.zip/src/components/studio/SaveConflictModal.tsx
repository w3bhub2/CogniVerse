"use client";

import React from "react";
import { SaveConflictData } from "@/services/storage.service";
import {
  AlertTriangle,
  Cloud,
  HardDrive,
  CheckCircle2,
  X,
  Clock,
  Trophy,
  ArrowRight,
} from "lucide-react";

interface SaveConflictModalProps {
  conflict: SaveConflictData;
  onResolve: (chosen: "local" | "cloud") => void;
  onClose: () => void;
}

export function SaveConflictModal({
  conflict,
  onResolve,
  onClose,
}: SaveConflictModalProps) {
  const localDate = new Date(conflict.localTimestamp || Date.now()).toLocaleString();
  const cloudDate = new Date(conflict.cloudTimestamp || Date.now()).toLocaleString();

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/85 backdrop-blur-md p-4">
      <div className="w-full max-w-2xl bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl flex flex-col space-y-6">
        <div className="flex items-center justify-between border-b border-slate-800 pb-4">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/30">
              <AlertTriangle className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-xl font-bold text-white">
                Save Conflict Resolution Required
              </h3>
              <p className="text-xs text-slate-400">
                Game: <strong className="text-amber-400">{conflict.gameId.toUpperCase()}</strong> • Cloud and Local Save States Diverged
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-slate-800 text-slate-400 hover:text-white transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
          We detected that your <strong>Local Device Save</strong> and your <strong>PostgreSQL Cloud Save</strong> have different progress timestamps or scores. Choose which save state you would like to keep as canonical:
        </p>

        {/* Comparison Side-by-Side Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {/* Local Save Card */}
          <div className="p-5 rounded-2xl bg-slate-950 border border-slate-800 hover:border-indigo-500/50 transition flex flex-col justify-between space-y-4">
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="flex items-center gap-1.5 text-xs font-bold text-indigo-400 uppercase tracking-wider">
                  <HardDrive className="w-4 h-4" />
                  <span>Local Device Save</span>
                </span>
                <span className="text-[10px] px-2 py-0.5 rounded bg-indigo-500/20 text-indigo-300">
                  On-Device
                </span>
              </div>
              <div className="space-y-1 text-xs text-slate-300">
                <div className="flex justify-between">
                  <span>Score:</span>
                  <strong className="text-white font-mono text-sm">
                    {conflict.localSnapshot.score}
                  </strong>
                </div>
                <div className="flex justify-between">
                  <span>Moves:</span>
                  <strong className="text-white font-mono text-sm">
                    {conflict.localSnapshot.movesCount}
                  </strong>
                </div>
                <div className="flex justify-between text-slate-400 text-[11px] pt-1 border-t border-slate-800">
                  <span>Saved:</span>
                  <span>{localDate}</span>
                </div>
              </div>
            </div>

            <button
              onClick={() => onResolve("local")}
              className="w-full py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs shadow-md transition"
            >
              Keep Local Save
            </button>
          </div>

          {/* Cloud Save Card */}
          <div className="p-5 rounded-2xl bg-slate-950 border border-slate-800 hover:border-emerald-500/50 transition flex flex-col justify-between space-y-4">
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="flex items-center gap-1.5 text-xs font-bold text-emerald-400 uppercase tracking-wider">
                  <Cloud className="w-4 h-4" />
                  <span>PostgreSQL Cloud Save</span>
                </span>
                <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300">
                  Cloud DB
                </span>
              </div>
              <div className="space-y-1 text-xs text-slate-300">
                <div className="flex justify-between">
                  <span>Score:</span>
                  <strong className="text-white font-mono text-sm">
                    {conflict.cloudSnapshot.score}
                  </strong>
                </div>
                <div className="flex justify-between">
                  <span>Moves:</span>
                  <strong className="text-white font-mono text-sm">
                    {conflict.cloudSnapshot.movesCount}
                  </strong>
                </div>
                <div className="flex justify-between text-slate-400 text-[11px] pt-1 border-t border-slate-800">
                  <span>Saved:</span>
                  <span>{cloudDate}</span>
                </div>
              </div>
            </div>

            <button
              onClick={() => onResolve("cloud")}
              className="w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-md transition"
            >
              Keep Cloud Save
            </button>
          </div>
        </div>

        <div className="pt-2 border-t border-slate-800 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold transition"
          >
            Cancel
          </button>
        </div>
      </div>
    </div>
  );
}
