"use client";

import React, { useState, useEffect } from "react";
import { achievementsService } from "@/services/achievements.service";
import { monetizationService } from "@/services/monetization.service";
import { audioService } from "@/services/audio.service";
import { STUDIO_CAMPAIGN_CHAPTERS } from "@/engine/campaign";
import {
  User,
  X,
  Award,
  Trophy,
  Flame,
  Volume2,
  VolumeX,
  Star,
  Sparkles,
  CheckCircle2,
  Gift,
} from "lucide-react";

interface ProfileModalProps {
  onClose: () => void;
}

export function ProfileModal({ onClose }: ProfileModalProps) {
  const [coins, setCoins] = useState(monetizationService.getCoins());
  const [adFree, setAdFree] = useState(monetizationService.isAdFree());
  const [volume, setVolume] = useState(audioService.getVolume());
  const [isMuted, setIsMuted] = useState(audioService.isMuted());
  const [dailyClaimed, setDailyClaimed] = useState(false);
  const [userStars, setUserStars] = useState<Record<string, number>>({});

  useEffect(() => {
    try {
      const stored = localStorage.getItem("studio_campaign_stars");
      if (stored) {
        setUserStars(JSON.parse(stored));
      }
      const claimed = localStorage.getItem("studio_daily_gift_claimed_today");
      if (claimed === new Date().toISOString().slice(0, 10)) {
        setDailyClaimed(true);
      }
    } catch (e) {
      // Ignore
    }
  }, []);

  const totalStarsEarned = Object.values(userStars).reduce((a, b) => a + b, 0);
  const achievements = achievementsService.getAchievements();
  const unlockedAchievements = achievements.filter((a) => a.isUnlocked);
  const totalXp = unlockedAchievements.reduce((acc, c) => acc + c.xpValue, 0);

  // Compute player Studio Level based on XP + Stars
  const totalScorePoints = totalXp + totalStarsEarned * 100;
  const playerLevel = Math.max(1, Math.floor(totalScorePoints / 300) + 1);

  const handleClaimDailyGift = () => {
    if (dailyClaimed) return;
    monetizationService.addCoins(100);
    setCoins(monetizationService.getCoins());
    setDailyClaimed(true);
    localStorage.setItem(
      "studio_daily_gift_claimed_today",
      new Date().toISOString().slice(0, 10)
    );
    audioService.play("victory");
  };

  const handleVolumeChange = (newVal: number) => {
    setVolume(newVal);
    audioService.setVolume(newVal);
    if (newVal > 0 && isMuted) {
      setIsMuted(false);
      audioService.setMuted(false);
    }
  };

  const handleToggleMute = () => {
    const nextMuted = !isMuted;
    setIsMuted(nextMuted);
    audioService.setMuted(nextMuted);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/85 backdrop-blur-md p-4">
      <div className="w-full max-w-3xl h-[85vh] bg-slate-900 border border-slate-800 rounded-3xl flex flex-col shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-5 border-b border-slate-800 bg-slate-950/60">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-indigo-500/20 text-indigo-400 border border-indigo-500/30">
              <User className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-white tracking-wide">
                Studio Player Profile & Audio Settings
              </h2>
              <p className="text-xs text-slate-400">
                Studio Level • Relic Collection • Soundboard & Music Calibration
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-slate-800 text-slate-400 hover:text-white transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6 text-slate-200">
          {/* Top Player Card */}
          <div className="p-6 rounded-2xl bg-gradient-to-r from-slate-950 via-indigo-950/60 to-slate-950 border border-indigo-500/30 flex flex-wrap items-center justify-between gap-6">
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-amber-500 to-indigo-600 flex items-center justify-center text-white font-black text-2xl shadow-lg">
                L{playerLevel}
              </div>
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <h3 className="text-xl font-black text-white">
                    Supreme Studio Master
                  </h3>
                  {adFree && (
                    <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[10px] font-bold uppercase">
                      Studio Pass VIP
                    </span>
                  )}
                </div>
                <p className="text-xs text-slate-400">
                  Total Studio XP: <strong className="text-emerald-400">{totalXp} XP</strong> • Saga Stars: <strong className="text-amber-400">{totalStarsEarned} Stars</strong>
                </p>
              </div>
            </div>

            {/* Daily Gift Claim Button */}
            <div className="flex items-center gap-3">
              <button
                onClick={handleClaimDailyGift}
                disabled={dailyClaimed}
                className={`flex items-center gap-2 px-5 py-3 rounded-xl font-bold text-sm shadow-md transition ${
                  dailyClaimed
                    ? "bg-slate-800 text-slate-500 cursor-default"
                    : "bg-amber-600 hover:bg-amber-500 text-white animate-pulse"
                }`}
              >
                <Gift className="w-4 h-4" />
                <span>
                  {dailyClaimed ? "Daily Gift Claimed ✓" : "Claim +100 Coins"}
                </span>
              </button>
            </div>
          </div>

          {/* Sound & Haptics Control Card */}
          <div className="p-6 rounded-2xl bg-slate-950 border border-slate-800 space-y-4">
            <div className="flex items-center justify-between">
              <h4 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
                <Volume2 className="w-4 h-4 text-indigo-400" />
                <span>Web Audio Synth Calibration & Soundboard</span>
              </h4>
              <button
                onClick={handleToggleMute}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold border transition ${
                  isMuted
                    ? "bg-rose-500/20 border-rose-500 text-rose-300"
                    : "bg-slate-800 border-slate-700 text-slate-300"
                }`}
              >
                {isMuted ? "Muted: UNMUTE" : "Sound: ON"}
              </button>
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs text-slate-400">
                <span>Master Synth Volume</span>
                <span className="font-bold text-white">
                  {Math.round(volume * 100)}%
                </span>
              </div>
              <input
                type="range"
                min="0"
                max="1"
                step="0.05"
                value={volume}
                onChange={(e) => handleVolumeChange(parseFloat(e.target.value))}
                className="w-full accent-indigo-500 bg-slate-800 rounded-lg cursor-pointer"
              />
            </div>

            {/* Test Audio Button */}
            <div className="flex items-center gap-2 pt-2">
              <button
                onClick={() => audioService.play("victory")}
                className="px-3.5 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-xs text-indigo-300 border border-slate-800 font-medium transition"
              >
                Test Victory Arpeggio ♫
              </button>
              <button
                onClick={() => audioService.play("merge")}
                className="px-3.5 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-xs text-emerald-300 border border-slate-800 font-medium transition"
              >
                Test Merge Chime ♫
              </button>
              <button
                onClick={() => audioService.play("click")}
                className="px-3.5 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-xs text-amber-300 border border-slate-800 font-medium transition"
              >
                Test Tile Click ♫
              </button>
            </div>
          </div>

          {/* Relics Collection */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider">
              Unlocked Story Saga Relics
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {STUDIO_CAMPAIGN_CHAPTERS.map((chap) => {
                const earned = userStars[chap.id] || 0;
                const isUnlocked = earned >= 2;
                return (
                  <div
                    key={chap.id}
                    className={`p-4 rounded-2xl border flex items-center gap-3 transition ${
                      isUnlocked
                        ? "bg-slate-950 border-amber-500/40"
                        : "bg-slate-950/40 border-slate-800/60 opacity-60"
                    }`}
                  >
                    <div
                      className={`p-3 rounded-xl ${
                        isUnlocked
                          ? "bg-amber-500/20 text-amber-400"
                          : "bg-slate-800 text-slate-600"
                      }`}
                    >
                      <Trophy className="w-6 h-6" />
                    </div>
                    <div>
                      <h5 className="text-sm font-bold text-white">
                        {chap.relicName}
                      </h5>
                      <p className="text-[11px] text-slate-400">
                        {isUnlocked
                          ? chap.relicDescription
                          : `Earn 2+ Stars in ${chap.title} to unlock`}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-slate-800 bg-slate-950/60 flex justify-end">
          <button
            onClick={onClose}
            className="px-6 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-medium text-sm transition"
          >
            Close Profile
          </button>
        </div>
      </div>
    </div>
  );
}
