"use client";

import React, { useState, useEffect } from "react";
import {
  STUDIO_CAMPAIGN_CHAPTERS,
  CampaignChapter,
} from "@/engine/campaign";
import { getGameModuleById } from "@/engine/registry";
import { GameModule } from "@/engine/types";
import { monetizationService } from "@/services/monetization.service";
import {
  Map,
  X,
  Star,
  Trophy,
  Lock,
  CheckCircle2,
  Play,
  Sparkles,
  ChevronRight,
  BookOpen,
  Award,
} from "lucide-react";

interface CampaignModalProps {
  onClose: () => void;
  onLaunchChapterGame: (module: GameModule<any, any>, chapter: CampaignChapter) => void;
}

export function CampaignModal({
  onClose,
  onLaunchChapterGame,
}: CampaignModalProps) {
  const [selectedChapter, setSelectedChapter] = useState<CampaignChapter>(
    STUDIO_CAMPAIGN_CHAPTERS[0]
  );
  const [showDialogue, setShowDialogue] = useState<boolean>(false);
  const [unlockedRelics, setUnlockedRelics] = useState<string[]>([]);
  const [userStars, setUserStars] = useState<Record<string, number>>({});

  useEffect(() => {
    // Load stored campaign progress from local/cloud
    try {
      const stored = localStorage.getItem("studio_campaign_stars");
      if (stored) {
        setUserStars(JSON.parse(stored));
      } else {
        // Default seed demo: 3 stars on Chapter 1, 2 stars on Chapter 2
        const seed = {
          "chap-1": 3,
          "chap-2": 2,
        };
        setUserStars(seed);
        localStorage.setItem("studio_campaign_stars", JSON.stringify(seed));
      }
    } catch (e) {
      // Ignore
    }
  }, []);

  const totalStarsEarned = Object.values(userStars).reduce((a, b) => a + b, 0);
  const maxPossibleStars = STUDIO_CAMPAIGN_CHAPTERS.length * 3;

  const handleStartMission = (chapter: CampaignChapter) => {
    const mod = getGameModuleById(chapter.gameId);
    if (mod) {
      onLaunchChapterGame(mod, chapter);
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/85 backdrop-blur-md p-4">
      <div className="w-full max-w-5xl h-[88vh] bg-slate-900 border border-slate-800 rounded-3xl flex flex-col shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-5 border-b border-slate-800 bg-slate-950/60">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/30">
              <Map className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-white tracking-wide">
                Studio Saga Campaign & Story Relics
              </h2>
              <p className="text-xs text-slate-400">
                Chapter Storylines • Relic Trophies • 3-Star Target Thresholds
              </p>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-400 text-xs font-bold">
              <Star className="w-4 h-4 fill-amber-400" />
              <span>
                {totalStarsEarned} / {maxPossibleStars} Stars
              </span>
            </div>
            <button
              onClick={onClose}
              className="p-2 rounded-xl bg-slate-800 text-slate-400 hover:text-white transition"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Body */}
        <div className="flex-1 grid grid-cols-1 md:grid-cols-12 overflow-hidden">
          {/* Left Sidebar: Chapter List (5 Cols) */}
          <div className="md:col-span-5 p-6 border-r border-slate-800 bg-slate-950/40 overflow-y-auto space-y-3">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
              Saga Chapter Progression
            </h3>

            {STUDIO_CAMPAIGN_CHAPTERS.map((chap, idx) => {
              const isSelected = selectedChapter.id === chap.id;
              const earned = userStars[chap.id] || 0;
              const isUnlocked = idx === 0 || (userStars[STUDIO_CAMPAIGN_CHAPTERS[idx - 1].id] || 0) > 0;

              return (
                <button
                  key={chap.id}
                  onClick={() => {
                    setSelectedChapter(chap);
                    setShowDialogue(false);
                  }}
                  className={`w-full p-4 rounded-2xl border text-left transition flex items-center justify-between ${
                    isSelected
                      ? "bg-amber-600/20 border-amber-500 text-white shadow-lg"
                      : isUnlocked
                        ? "bg-slate-900 border-slate-800 text-slate-300 hover:bg-slate-800"
                        : "bg-slate-950/60 border-slate-800/40 text-slate-500 opacity-70"
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div
                      className={`p-2.5 rounded-xl ${
                        earned === 3
                          ? "bg-amber-500/20 text-amber-400"
                          : "bg-slate-800 text-slate-400"
                      }`}
                    >
                      {earned === 3 ? (
                        <Trophy className="w-5 h-5" />
                      ) : isUnlocked ? (
                        <Star className="w-5 h-5" />
                      ) : (
                        <Lock className="w-5 h-5" />
                      )}
                    </div>
                    <div>
                      <h4 className="text-sm font-bold text-white">
                        {chap.title}
                      </h4>
                      <span className="text-xs text-slate-400 block">
                        {chap.subtitle}
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center gap-1">
                    {[1, 2, 3].map((starIdx) => (
                      <Star
                        key={starIdx}
                        className={`w-3.5 h-3.5 ${
                          starIdx <= earned
                            ? "text-amber-400 fill-amber-400"
                            : "text-slate-700"
                        }`}
                      />
                    ))}
                  </div>
                </button>
              );
            })}
          </div>

          {/* Right Main Content: Selected Chapter Hero Banner & Dialogue (7 Cols) */}
          <div className="md:col-span-7 flex flex-col h-full bg-slate-950/70 overflow-y-auto p-6 space-y-6">
            {/* Hero Artwork Banner */}
            <div className="relative h-48 sm:h-56 rounded-3xl overflow-hidden border border-slate-800 shadow-xl group">
              <img
                src={selectedChapter.bannerImagePath}
                alt={selectedChapter.title}
                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/60 to-transparent flex flex-col justify-end p-6">
                <span className="inline-block px-3 py-1 rounded-full bg-amber-500/20 border border-amber-500/40 text-amber-300 text-xs font-semibold w-max mb-2">
                  Chapter Mission • Game: {selectedChapter.gameId.toUpperCase()}
                </span>
                <h3 className="text-2xl font-black text-white">
                  {selectedChapter.title}
                </h3>
                <p className="text-xs text-slate-300">
                  {selectedChapter.subtitle}
                </p>
              </div>
            </div>

            {/* Story Dialogue Section */}
            <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-amber-400 font-bold text-xs uppercase tracking-wider">
                  <BookOpen className="w-4 h-4" />
                  <span>Story Lore & Mission Briefing</span>
                </div>
                <button
                  onClick={() => setShowDialogue(!showDialogue)}
                  className="text-xs text-indigo-400 hover:underline"
                >
                  {showDialogue ? "Hide Dialogue" : "Read Full Story Intro"}
                </button>
              </div>

              <div className="space-y-2 text-xs text-slate-300 leading-relaxed">
                {selectedChapter.storyIntro.map((line, idx) => (
                  <p key={idx} className="flex gap-2">
                    <span className="text-amber-400 font-bold">▶</span>
                    <span>{line}</span>
                  </p>
                ))}
              </div>
            </div>

            {/* Star Target Thresholds & Relic Trophy */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-2">
                <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider">
                  Star Targets & Score Goals
                </h4>
                <div className="space-y-1.5 text-xs">
                  <div className="flex items-center justify-between text-amber-300 font-semibold">
                    <span>★ 1 Star Target</span>
                    <span>{selectedChapter.starThresholds.star1Score} pts</span>
                  </div>
                  <div className="flex items-center justify-between text-amber-300 font-semibold">
                    <span>★★ 2 Star Target</span>
                    <span>{selectedChapter.starThresholds.star2Score} pts</span>
                  </div>
                  <div className="flex items-center justify-between text-amber-400 font-extrabold">
                    <span>★★★ 3 Star Mastery</span>
                    <span>{selectedChapter.starThresholds.star3Score} pts</span>
                  </div>
                </div>
              </div>

              <div className="p-4 rounded-2xl bg-gradient-to-br from-amber-950/40 to-slate-900 border border-amber-500/30 flex items-center gap-3">
                <div className="p-3 rounded-xl bg-amber-500/20 text-amber-400">
                  <Award className="w-7 h-7" />
                </div>
                <div>
                  <span className="text-[10px] text-amber-400 font-bold uppercase tracking-wider block">
                    Chapter Relic Trophy
                  </span>
                  <h4 className="text-sm font-bold text-white">
                    {selectedChapter.relicName}
                  </h4>
                  <p className="text-[11px] text-slate-400">
                    {selectedChapter.relicDescription}
                  </p>
                </div>
              </div>
            </div>

            {/* Action Bar */}
            <div className="pt-2 flex justify-end gap-3">
              <button
                onClick={onClose}
                className="px-5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold text-sm transition"
              >
                Close Saga
              </button>
              <button
                onClick={() => handleStartMission(selectedChapter)}
                className="flex items-center gap-2 px-6 py-2.5 rounded-xl bg-amber-600 hover:bg-amber-500 text-white font-extrabold text-sm shadow-lg transition"
              >
                <Play className="w-4 h-4 fill-current" />
                <span>Launch Story Mission</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
