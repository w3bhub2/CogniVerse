import { GameModule, GameHint, GameDifficulty } from "@/engine/types";

export interface CrosswordCell {
  row: number;
  col: number;
  isBlock: boolean;
  solution: string;
  userValue: string;
  numberLabel?: number;
}

export interface CrosswordClue {
  id: string;
  number: number;
  direction: "across" | "down";
  clue: string;
  answer: string;
  startRow: number;
  startCol: number;
  length: number;
}

export interface CrosswordState {
  grid: CrosswordCell[][];
  clues: CrosswordClue[];
  selectedClueId: string;
  won: boolean;
  gameOver: boolean;
}

const MINI_CROSSWORD_EASY: {
  grid: Array<Array<{ block?: boolean; char: string; num?: number }>>;
  clues: CrosswordClue[];
} = {
  grid: [
    [
      { char: "S", num: 1 },
      { char: "T", num: 2 },
      { char: "A", num: 3 },
      { char: "R", num: 4 },
      { char: "T", num: 5 },
    ],
    [
      { char: "C" },
      { char: "R" },
      { char: "E" },
      { char: "E" },
      { char: "D" },
    ],
    [
      { char: "O" },
      { char: "I" },
      { char: "L" },
      { char: "A" },
      { char: "R", block: false },
    ],
    [
      { char: "R" },
      { char: "E" },
      { char: "I" },
      { char: "D" },
      { char: "Y" },
    ],
    [
      { char: "E" },
      { char: "D" },
      { char: "S" },
      { char: "S" },
      { char: "E" },
    ],
  ],
  clues: [
    {
      id: "a1",
      number: 1,
      direction: "across",
      clue: "Begin a journey or game",
      answer: "START",
      startRow: 0,
      startCol: 0,
      length: 5,
    },
    {
      id: "a6",
      number: 6,
      direction: "across",
      clue: "System of beliefs",
      answer: "CREED",
      startRow: 1,
      startCol: 0,
      length: 5,
    },
    {
      id: "a7",
      number: 7,
      direction: "across",
      clue: "Cooking fat or fuel liquid",
      answer: "OILAR",
      startRow: 2,
      startCol: 0,
      length: 5,
    },
    {
      id: "a8",
      number: 8,
      direction: "across",
      clue: "Ready or prepared",
      answer: "REIDY",
      startRow: 3,
      startCol: 0,
      length: 5,
    },
    {
      id: "a9",
      number: 9,
      direction: "across",
      clue: "Plural ends or finishes",
      answer: "EDSSE",
      startRow: 4,
      startCol: 0,
      length: 5,
    },
    {
      id: "d1",
      number: 1,
      direction: "down",
      clue: "Music or movie score",
      answer: "SCORE",
      startRow: 0,
      startCol: 0,
      length: 5,
    },
    {
      id: "d2",
      number: 2,
      direction: "down",
      clue: "Fame or attempt",
      answer: "TRIED",
      startRow: 0,
      startCol: 1,
      length: 5,
    },
    {
      id: "d3",
      number: 3,
      direction: "down",
      clue: "Elysian fields",
      answer: "AELIS",
      startRow: 0,
      startCol: 2,
      length: 5,
    },
    {
      id: "d4",
      number: 4,
      direction: "down",
      clue: "To read again",
      answer: "READS",
      startRow: 0,
      startCol: 3,
      length: 5,
    },
    {
      id: "d5",
      number: 5,
      direction: "down",
      clue: "Old English suffix",
      answer: "TDRYE",
      startRow: 0,
      startCol: 4,
      length: 5,
    },
  ],
};

export const crosswordModule: GameModule<CrosswordState> = {
  id: "crossword",
  name: "Crossword",
  phase: 1,
  category: "Word & Vocabulary",
  description: "Test your vocabulary and trivia knowledge with daily and timeless mini crossword grids.",
  version: "1.0.0",
  author: "Studio Core Team",
  packageId: "com.puzzleplatform.games.crossword",
  iconName: "BookOpen",
  accentColor: "#10B981", // Emerald
  minSdk: 26,
  targetSdk: 34,
  supportedDifficulties: ["easy", "medium", "hard"],

  defaultSaveData: () => ({
    completedPuzzles: 0,
  }),

  getInitialState: (): CrosswordState => {
    const template = MINI_CROSSWORD_EASY;
    const grid: CrosswordCell[][] = template.grid.map((row, r) =>
      row.map((item, c) => ({
        row: r,
        col: c,
        isBlock: Boolean(item.block),
        solution: item.char,
        userValue: "",
        numberLabel: item.num,
      }))
    );

    return {
      grid,
      clues: template.clues,
      selectedClueId: "a1",
      won: false,
      gameOver: false,
    };
  },

  validateSaveData: (data: any) => Boolean(data),

  getHint: (state: CrosswordState): GameHint | null => {
    for (let r = 0; r < 5; r++) {
      for (let c = 0; c < 5; c++) {
        const cell = state.grid[r][c];
        if (!cell.isBlock && cell.userValue !== cell.solution) {
          return {
            message: `The letter at row ${r + 1}, col ${c + 1} is '${cell.solution}'.`,
            highlightCells: [{ row: r, col: c }],
            suggestedAction: cell.solution,
            penaltySeconds: 15,
          };
        }
      }
    }
    return null;
  },

  computeScore: (state: CrosswordState, timeSeconds: number): number => {
    let correct = 0;
    for (let r = 0; r < 5; r++) {
      for (let c = 0; c < 5; c++) {
        const cell = state.grid[r][c];
        if (!cell.isBlock && cell.userValue === cell.solution) {
          correct++;
        }
      }
    }
    const base = correct * 100;
    return base + (state.won ? 2000 + Math.max(0, 1000 - timeSeconds) : 0);
  },

  isGameOver: () => false,

  isGameWon: (state: CrosswordState): boolean => {
    for (let r = 0; r < 5; r++) {
      for (let c = 0; c < 5; c++) {
        const cell = state.grid[r][c];
        if (!cell.isBlock && cell.userValue !== cell.solution) {
          return false;
        }
      }
    }
    return true;
  },

  getBoardDimensions: () => ({ rows: 5, cols: 5 }),
};
