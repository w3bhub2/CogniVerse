import { GameModule, GameHint, GameDifficulty } from "@/engine/types";

export interface Game2048State {
  grid: number[][];
  score: number;
  bestTile: number;
  won: boolean;
  gameOver: boolean;
}

export const game2048Module: GameModule<Game2048State> = {
  id: "2048",
  name: "2048",
  phase: 1,
  category: "Number Logic",
  description: "Slide and merge matching number tiles to reach the legendary 2048 tile!",
  version: "1.2.0",
  author: "Studio Core Team",
  packageId: "com.puzzleplatform.games.g2048",
  iconName: "Grid3x3",
  accentColor: "#F59E0B", // Amber
  minSdk: 26,
  targetSdk: 34,
  supportedDifficulties: ["easy", "medium", "hard"],

  defaultSaveData: () => ({
    highScore: 0,
    bestTileReached: 2,
    totalGamesPlayed: 0,
  }),

  getInitialState: (difficulty: GameDifficulty = "medium") => {
    const grid = [
      [0, 0, 0, 0],
      [0, 0, 0, 0],
      [0, 0, 0, 0],
      [0, 0, 0, 0],
    ];
    // Easy starts with three 2s, medium with two tiles, hard with higher probability of 4s
    const startTiles = difficulty === "easy" ? 3 : 2;
    for (let i = 0; i < startTiles; i++) {
      addRandomTile(grid, difficulty);
    }
    return {
      grid,
      score: 0,
      bestTile: 2,
      won: false,
      gameOver: false,
    };
  },

  validateSaveData: (data: any) => {
    return Boolean(data && typeof data.highScore === "number");
  },

  getHint: (state: Game2048State): GameHint | null => {
    // Determine which direction yields the highest score or tile merge
    const directions: Array<"up" | "down" | "left" | "right"> = [
      "up",
      "down",
      "left",
      "right",
    ];
    let bestDir = "up";
    let maxFree = -1;

    for (const dir of directions) {
      const sim = simulateMove(state.grid, dir);
      if (sim.moved) {
        const freeCount = countEmpty(sim.grid);
        if (freeCount > maxFree) {
          maxFree = freeCount;
          bestDir = dir;
        }
      }
    }

    if (maxFree === -1) {
      return null;
    }

    return {
      message: `Try sliding ${bestDir.toUpperCase()} to combine tiles and open up board space.`,
      suggestedAction: bestDir,
      penaltySeconds: 5,
    };
  },

  computeScore: (state: Game2048State, timeSeconds: number, moves: number): number => {
    const baseScore = state.score;
    const timeBonus = Math.max(0, 1000 - timeSeconds * 2);
    return baseScore + (state.won ? 5000 + timeBonus : 0);
  },

  isGameOver: (state: Game2048State): boolean => {
    return !hasValidMoves(state.grid);
  },

  isGameWon: (state: Game2048State): boolean => {
    return state.won || state.bestTile >= 2048;
  },

  getBoardDimensions: () => ({ rows: 4, cols: 4 }),
};

// Helper functions for 2048 logic
export function addRandomTile(
  grid: number[][],
  difficulty: GameDifficulty = "medium"
): boolean {
  const empty: Array<{ r: number; c: number }> = [];
  for (let r = 0; r < 4; r++) {
    for (let c = 0; c < 4; c++) {
      if (grid[r][c] === 0) empty.push({ r, c });
    }
  }
  if (empty.length === 0) return false;
  const pos = empty[Math.floor(Math.random() * empty.length)];
  const value =
    difficulty === "hard"
      ? Math.random() < 0.3
        ? 4
        : 2
      : Math.random() < 0.15
        ? 4
        : 2;
  grid[pos.r][pos.c] = value;
  return true;
}

export function countEmpty(grid: number[][]): number {
  let count = 0;
  for (let r = 0; r < 4; r++) {
    for (let c = 0; c < 4; c++) {
      if (grid[r][c] === 0) count++;
    }
  }
  return count;
}

export function hasValidMoves(grid: number[][]): boolean {
  for (let r = 0; r < 4; r++) {
    for (let c = 0; c < 4; c++) {
      if (grid[r][c] === 0) return true;
      if (r < 3 && grid[r][c] === grid[r + 1][c]) return true;
      if (c < 3 && grid[r][c] === grid[r][c + 1]) return true;
    }
  }
  return false;
}

export function simulateMove(
  grid: number[][],
  direction: "up" | "down" | "left" | "right"
): { grid: number[][]; moved: boolean; scoreGain: number } {
  const newGrid = grid.map((row) => [...row]);
  let moved = false;
  let scoreGain = 0;

  const slideRow = (row: number[]) => {
    const nonZero = row.filter((v) => v !== 0);
    const result: number[] = [];
    let i = 0;
    while (i < nonZero.length) {
      if (i + 1 < nonZero.length && nonZero[i] === nonZero[i + 1]) {
        const merged = nonZero[i] * 2;
        result.push(merged);
        scoreGain += merged;
        i += 2;
      } else {
        result.push(nonZero[i]);
        i += 1;
      }
    }
    while (result.length < 4) result.push(0);
    return result;
  };

  if (direction === "left") {
    for (let r = 0; r < 4; r++) {
      const oldRow = newGrid[r].join(",");
      newGrid[r] = slideRow(newGrid[r]);
      if (newGrid[r].join(",") !== oldRow) moved = true;
    }
  } else if (direction === "right") {
    for (let r = 0; r < 4; r++) {
      const oldRow = newGrid[r].join(",");
      newGrid[r] = slideRow(newGrid[r].reverse()).reverse();
      if (newGrid[r].join(",") !== oldRow) moved = true;
    }
  } else if (direction === "up") {
    for (let c = 0; c < 4; c++) {
      const col = [newGrid[0][c], newGrid[1][c], newGrid[2][c], newGrid[3][c]];
      const oldCol = col.join(",");
      const res = slideRow(col);
      if (res.join(",") !== oldCol) moved = true;
      for (let r = 0; r < 4; r++) newGrid[r][c] = res[r];
    }
  } else if (direction === "down") {
    for (let c = 0; c < 4; c++) {
      const col = [
        newGrid[3][c],
        newGrid[2][c],
        newGrid[1][c],
        newGrid[0][c],
      ];
      const oldCol = col.join(",");
      const res = slideRow(col);
      if (res.join(",") !== oldCol) moved = true;
      for (let r = 0; r < 4; r++) newGrid[3 - r][c] = res[r];
    }
  }

  return { grid: newGrid, moved, scoreGain };
}
