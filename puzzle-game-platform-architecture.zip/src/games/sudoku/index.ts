import { GameModule, GameHint, GameDifficulty } from "@/engine/types";

export interface SudokuCell {
  row: number;
  col: number;
  value: number; // 0 = empty, 1-9
  solution: number;
  isGiven: boolean;
  notes: number[];
  isError: boolean;
}

export interface SudokuState {
  grid: SudokuCell[][];
  mistakes: number;
  maxMistakes: number;
  completedCells: number;
  won: boolean;
  gameOver: boolean;
  notesMode: boolean;
}

const TEMPLATE_SUDOKU_EASY = {
  puzzle: [
    [5, 3, 0, 0, 7, 0, 0, 0, 0],
    [6, 0, 0, 1, 9, 5, 0, 0, 0],
    [0, 9, 8, 0, 0, 0, 0, 6, 0],
    [8, 0, 0, 0, 6, 0, 0, 0, 3],
    [4, 0, 0, 8, 0, 3, 0, 0, 1],
    [7, 0, 0, 0, 2, 0, 0, 0, 6],
    [0, 6, 0, 0, 0, 0, 2, 8, 0],
    [0, 0, 0, 4, 1, 9, 0, 0, 5],
    [0, 0, 0, 0, 8, 0, 0, 7, 9],
  ],
  solution: [
    [5, 3, 4, 6, 7, 8, 9, 1, 2],
    [6, 7, 2, 1, 9, 5, 3, 4, 8],
    [1, 9, 8, 3, 4, 2, 5, 6, 7],
    [8, 5, 9, 7, 6, 1, 4, 2, 3],
    [4, 2, 6, 8, 5, 3, 7, 9, 1],
    [7, 1, 3, 9, 2, 4, 8, 5, 6],
    [9, 6, 1, 5, 3, 7, 2, 8, 4],
    [2, 8, 7, 4, 1, 9, 6, 3, 5],
    [3, 4, 5, 2, 8, 6, 1, 7, 9],
  ],
};

const TEMPLATE_SUDOKU_MEDIUM = {
  puzzle: [
    [0, 2, 0, 6, 0, 8, 0, 0, 0],
    [5, 8, 0, 0, 0, 9, 7, 0, 0],
    [0, 0, 0, 0, 4, 0, 0, 0, 0],
    [3, 7, 0, 0, 0, 0, 5, 0, 0],
    [6, 0, 0, 0, 0, 0, 0, 0, 4],
    [0, 0, 8, 0, 0, 0, 0, 1, 3],
    [0, 0, 0, 0, 2, 0, 0, 0, 0],
    [0, 0, 9, 8, 0, 0, 0, 3, 6],
    [0, 0, 0, 3, 0, 6, 0, 9, 0],
  ],
  solution: [
    [1, 2, 3, 6, 7, 8, 9, 4, 5],
    [5, 8, 4, 2, 3, 9, 7, 6, 1],
    [9, 6, 7, 1, 4, 5, 3, 2, 8],
    [3, 7, 2, 4, 6, 1, 5, 8, 9],
    [6, 9, 1, 5, 8, 3, 2, 7, 4],
    [4, 5, 8, 7, 9, 2, 6, 1, 3],
    [8, 3, 6, 9, 2, 4, 1, 5, 7],
    [2, 1, 9, 8, 5, 7, 4, 3, 6],
    [7, 4, 5, 3, 1, 6, 8, 9, 2],
  ],
};

export const sudokuModule: GameModule<SudokuState> = {
  id: "sudoku",
  name: "Sudoku",
  phase: 1,
  category: "Number Logic",
  description: "Fill the 9x9 grid with numbers 1 to 9 so every row, column, and 3x3 block contains each digit once.",
  version: "1.1.0",
  author: "Studio Core Team",
  packageId: "com.puzzleplatform.games.sudoku",
  iconName: "Hash",
  accentColor: "#3B82F6", // Blue
  minSdk: 26,
  targetSdk: 34,
  supportedDifficulties: ["easy", "medium", "hard"],

  defaultSaveData: () => ({
    bestTimeMs: null,
    totalGamesPlayed: 0,
    totalGamesWon: 0,
  }),

  getInitialState: (difficulty: GameDifficulty = "medium"): SudokuState => {
    const template = difficulty === "easy" ? TEMPLATE_SUDOKU_EASY : TEMPLATE_SUDOKU_MEDIUM;
    let completedCount = 0;

    const grid: SudokuCell[][] = template.puzzle.map((row, r) =>
      row.map((val, c) => {
        if (val !== 0) completedCount++;
        return {
          row: r,
          col: c,
          value: val,
          solution: template.solution[r][c],
          isGiven: val !== 0,
          notes: [],
          isError: false,
        };
      })
    );

    return {
      grid,
      mistakes: 0,
      maxMistakes: difficulty === "hard" ? 3 : 5,
      completedCells: completedCount,
      won: false,
      gameOver: false,
      notesMode: false,
    };
  },

  validateSaveData: (data: any) => Boolean(data),

  getHint: (state: SudokuState): GameHint | null => {
    // Find first empty cell and reveal its correct number
    for (let r = 0; r < 9; r++) {
      for (let c = 0; c < 9; c++) {
        const cell = state.grid[r][c];
        if (cell.value === 0 || cell.isError) {
          return {
            message: `Cell at row ${r + 1}, col ${c + 1} should be ${cell.solution}.`,
            highlightCells: [{ row: r, col: c }],
            suggestedAction: `${cell.solution}`,
            penaltySeconds: 15,
          };
        }
      }
    }
    return null;
  },

  computeScore: (state: SudokuState, timeSeconds: number, moves: number): number => {
    const base = state.completedCells * 50;
    const timeBonus = Math.max(0, 2000 - timeSeconds);
    const mistakePenalty = state.mistakes * 100;
    return Math.max(0, base + (state.won ? 3000 + timeBonus : 0) - mistakePenalty);
  },

  isGameOver: (state: SudokuState): boolean => {
    return state.mistakes >= state.maxMistakes;
  },

  isGameWon: (state: SudokuState): boolean => {
    for (let r = 0; r < 9; r++) {
      for (let c = 0; c < 9; c++) {
        const cell = state.grid[r][c];
        if (cell.value !== cell.solution) return false;
      }
    }
    return true;
  },

  getBoardDimensions: () => ({ rows: 9, cols: 9 }),
};
