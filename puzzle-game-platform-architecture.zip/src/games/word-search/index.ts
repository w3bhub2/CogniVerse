import { GameModule, GameHint, GameDifficulty } from "@/engine/types";

export interface WordSearchWord {
  id: string;
  word: string;
  found: boolean;
  startCell: { row: number; col: number };
  endCell: { row: number; col: number };
}

export interface WordSearchState {
  grid: string[][];
  words: WordSearchWord[];
  foundCells: Array<{ row: number; col: number }>;
  won: boolean;
  gameOver: boolean;
}

const TEMPLATE_WORDS_EASY = [
  { word: "STUDIO", start: { row: 0, col: 0 }, end: { row: 0, col: 5 } },
  { word: "PUZZLE", start: { row: 2, col: 1 }, end: { row: 2, col: 6 } },
  { word: "LOGIC", start: { row: 4, col: 2 }, end: { row: 4, col: 6 } },
  { word: "ENGINE", start: { row: 6, col: 0 }, end: { row: 6, col: 5 } },
  { word: "GAME", start: { row: 0, col: 7 }, end: { row: 3, col: 7 } },
];

export const wordSearchModule: GameModule<WordSearchState> = {
  id: "word-search",
  name: "Word Search",
  phase: 1,
  category: "Word & Vocabulary",
  description: "Find all the hidden vocabulary words horizontally, vertically, and diagonally across the letter grid.",
  version: "1.0.0",
  author: "Studio Core Team",
  packageId: "com.puzzleplatform.games.wordsearch",
  iconName: "Search",
  accentColor: "#8B5CF6", // Purple
  minSdk: 26,
  targetSdk: 34,
  supportedDifficulties: ["easy", "medium", "hard"],

  defaultSaveData: () => ({
    totalPuzzlesSolved: 0,
  }),

  getInitialState: (): WordSearchState => {
    const letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    const grid: string[][] = Array.from({ length: 8 }, () =>
      Array.from({ length: 8 }, () =>
        letters.charAt(Math.floor(Math.random() * letters.length))
      )
    );

    // Place template words into grid
    TEMPLATE_WORDS_EASY.forEach(({ word, start, end }) => {
      const dRow = Math.sign(end.row - start.row);
      const dCol = Math.sign(end.col - start.col);
      for (let i = 0; i < word.length; i++) {
        grid[start.row + i * dRow][start.col + i * dCol] = word.charAt(i);
      }
    });

    const words: WordSearchWord[] = TEMPLATE_WORDS_EASY.map((item, index) => ({
      id: `w-${index}`,
      word: item.word,
      found: false,
      startCell: item.start,
      endCell: item.end,
    }));

    return {
      grid,
      words,
      foundCells: [],
      won: false,
      gameOver: false,
    };
  },

  validateSaveData: (data: any) => Boolean(data),

  getHint: (state: WordSearchState): GameHint | null => {
    const missing = state.words.find((w) => !w.found);
    if (!missing) return null;
    return {
      message: `Look around row ${missing.startCell.row + 1}, col ${missing.startCell.col + 1} for the word '${missing.word}'.`,
      highlightCells: [missing.startCell],
      penaltySeconds: 10,
    };
  },

  computeScore: (state: WordSearchState, timeSeconds: number): number => {
    const foundCount = state.words.filter((w) => w.found).length;
    const base = foundCount * 200;
    return base + (state.won ? 3000 + Math.max(0, 1000 - timeSeconds) : 0);
  },

  isGameOver: () => false,

  isGameWon: (state: WordSearchState): boolean => {
    return state.words.every((w) => w.found);
  },

  getBoardDimensions: () => ({ rows: 8, cols: 8 }),
};
