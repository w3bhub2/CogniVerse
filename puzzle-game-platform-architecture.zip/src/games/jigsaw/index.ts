import { GameModule, GameHint, GameDifficulty } from "@/engine/types";

export interface JigsawPiece {
  id: number;
  correctRow: number;
  correctCol: number;
  currentRow: number;
  currentCol: number;
  colorHex: string;
  label: string;
  isLocked: boolean;
}

export interface JigsawState {
  pieces: JigsawPiece[];
  rows: number;
  cols: number;
  won: boolean;
  gameOver: boolean;
}

const PIECE_COLORS_3X3 = [
  "#3B82F6", "#60A5FA", "#93C5FD",
  "#10B981", "#34D399", "#6EE7B7",
  "#F59E0B", "#FBBF24", "#FDE047",
];

export const jigsawModule: GameModule<JigsawState> = {
  id: "jigsaw",
  name: "Jigsaw Puzzle",
  phase: 1,
  category: "Tile & Grid",
  description: "Assemble the shattered gradient artwork by dragging and swapping pieces into their correct grid locations.",
  version: "1.1.0",
  author: "Studio Core Team",
  packageId: "com.puzzleplatform.games.jigsaw",
  iconName: "Puzzle",
  accentColor: "#EC4899", // Pink
  minSdk: 26,
  targetSdk: 34,
  supportedDifficulties: ["easy", "medium", "hard"],

  defaultSaveData: () => ({
    completedPuzzles: 0,
  }),

  getInitialState: (difficulty: GameDifficulty = "medium"): JigsawState => {
    const rows = difficulty === "easy" ? 3 : 3;
    const cols = difficulty === "easy" ? 3 : 3;
    const count = rows * cols;

    const correctPieces: JigsawPiece[] = [];
    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        const id = r * cols + c;
        correctPieces.push({
          id,
          correctRow: r,
          correctCol: c,
          currentRow: r,
          currentCol: c,
          colorHex: PIECE_COLORS_3X3[id % PIECE_COLORS_3X3.length],
          label: `${String.fromCharCode(65 + r)}${c + 1}`,
          isLocked: false,
        });
      }
    }

    // Shuffle current positions ensuring solvable derangement
    const positions = correctPieces.map((p) => ({ r: p.correctRow, c: p.correctCol }));
    for (let i = positions.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      const temp = positions[i];
      positions[i] = positions[j];
      positions[j] = temp;
    }

    correctPieces.forEach((p, idx) => {
      p.currentRow = positions[idx].r;
      p.currentCol = positions[idx].c;
      p.isLocked = p.currentRow === p.correctRow && p.currentCol === p.correctCol;
    });

    return {
      pieces: correctPieces,
      rows,
      cols,
      won: false,
      gameOver: false,
    };
  },

  validateSaveData: (data: any) => Boolean(data),

  getHint: (state: JigsawState): GameHint | null => {
    const unlocked = state.pieces.find((p) => !p.isLocked);
    if (!unlocked) return null;
    return {
      message: `Piece '${unlocked.label}' belongs at row ${unlocked.correctRow + 1}, col ${unlocked.correctCol + 1}.`,
      highlightCells: [{ row: unlocked.currentRow, col: unlocked.currentCol }],
      penaltySeconds: 10,
    };
  },

  computeScore: (state: JigsawState, timeSeconds: number, moves: number): number => {
    const lockedCount = state.pieces.filter((p) => p.isLocked).length;
    const base = lockedCount * 150;
    return base + (state.won ? 3000 + Math.max(0, 1000 - timeSeconds) : 0);
  },

  isGameOver: () => false,

  isGameWon: (state: JigsawState): boolean => {
    return state.pieces.every(
      (p) => p.currentRow === p.correctRow && p.currentCol === p.correctCol
    );
  },

  getBoardDimensions: (state: JigsawState) => ({ rows: state.rows, cols: state.cols }),
};
