import { GameModule, GameHint, GameDifficulty } from "@/engine/types";

export interface SlidingTile {
  number: number; // 0 = empty
  row: number;
  col: number;
}

export interface SlidingPuzzleState {
  grid: number[][]; // 0 is empty tile
  rows: number;
  cols: number;
  won: boolean;
  gameOver: boolean;
}

export const slidingPuzzleModule: GameModule<SlidingPuzzleState> = {
  id: "sliding-puzzle",
  name: "Sliding Puzzle",
  phase: 1,
  category: "Tile & Grid",
  description: "Slide numbered tiles into numerical order using the single empty square.",
  version: "1.0.0",
  author: "Studio Core Team",
  packageId: "com.puzzleplatform.games.slidingpuzzle",
  iconName: "LayoutGrid",
  accentColor: "#06B6D4", // Cyan
  minSdk: 26,
  targetSdk: 34,
  supportedDifficulties: ["easy", "medium", "hard"],

  defaultSaveData: () => ({
    bestMoves: null,
    totalGamesPlayed: 0,
  }),

  getInitialState: (difficulty: GameDifficulty = "medium"): SlidingPuzzleState => {
    const size = difficulty === "easy" ? 3 : 4;
    const grid: number[][] = [];

    // Create solved grid first
    let num = 1;
    for (let r = 0; r < size; r++) {
      grid[r] = [];
      for (let c = 0; c < size; c++) {
        grid[r][c] = r === size - 1 && c === size - 1 ? 0 : num++;
      }
    }

    // Perform solvable random slides from the solved state
    let emptyR = size - 1;
    let emptyC = size - 1;
    const steps = difficulty === "easy" ? 30 : 80;

    for (let i = 0; i < steps; i++) {
      const neighbors: Array<{ r: number; c: number }> = [];
      if (emptyR > 0) neighbors.push({ r: emptyR - 1, c: emptyC });
      if (emptyR < size - 1) neighbors.push({ r: emptyR + 1, c: emptyC });
      if (emptyC > 0) neighbors.push({ r: emptyR, c: emptyC - 1 });
      if (emptyC < size - 1) neighbors.push({ r: emptyR, c: emptyC + 1 });

      const pick = neighbors[Math.floor(Math.random() * neighbors.length)];
      grid[emptyR][emptyC] = grid[pick.r][pick.c];
      grid[pick.r][pick.c] = 0;
      emptyR = pick.r;
      emptyC = pick.c;
    }

    return {
      grid,
      rows: size,
      cols: size,
      won: false,
      gameOver: false,
    };
  },

  validateSaveData: (data: any) => Boolean(data),

  getHint: (state: SlidingPuzzleState): GameHint | null => {
    // Locate empty tile (0) and suggest moving an adjacent tile that is out of order
    let emptyR = 0;
    let emptyC = 0;
    for (let r = 0; r < state.rows; r++) {
      for (let c = 0; c < state.cols; c++) {
        if (state.grid[r][c] === 0) {
          emptyR = r;
          emptyC = c;
        }
      }
    }

    const neighbors = [
      { r: emptyR - 1, c: emptyC, dir: "DOWN" },
      { r: emptyR + 1, c: emptyC, dir: "UP" },
      { r: emptyR, c: emptyC - 1, dir: "RIGHT" },
      { r: emptyR, c: emptyC + 1, dir: "LEFT" },
    ].filter(
      (pos) =>
        pos.r >= 0 && pos.r < state.rows && pos.c >= 0 && pos.c < state.cols
    );

    if (neighbors.length === 0) return null;
    const target = neighbors[0];
    return {
      message: `Slide tile ${state.grid[target.r][target.c]} ${target.dir} into the empty spot.`,
      highlightCells: [{ row: target.r, col: target.c }],
      penaltySeconds: 8,
    };
  },

  computeScore: (state: SlidingPuzzleState, timeSeconds: number, moves: number): number => {
    let correct = 0;
    let expected = 1;
    for (let r = 0; r < state.rows; r++) {
      for (let c = 0; c < state.cols; c++) {
        if (state.grid[r][c] === expected) {
          correct++;
        }
        expected++;
      }
    }
    const base = correct * 100;
    return base + (state.won ? 3000 + Math.max(0, 1000 - timeSeconds) : 0);
  },

  isGameOver: () => false,

  isGameWon: (state: SlidingPuzzleState): boolean => {
    let expected = 1;
    const lastNum = state.rows * state.cols;
    for (let r = 0; r < state.rows; r++) {
      for (let c = 0; c < state.cols; c++) {
        if (r === state.rows - 1 && c === state.cols - 1) {
          return state.grid[r][c] === 0;
        }
        if (state.grid[r][c] !== expected) {
          return false;
        }
        expected++;
      }
    }
    return true;
  },

  getBoardDimensions: (state: SlidingPuzzleState) => ({
    rows: state.rows,
    cols: state.cols,
  }),
};
