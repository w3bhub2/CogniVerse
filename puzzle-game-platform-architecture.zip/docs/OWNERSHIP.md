---
id: ROOT-004
title: Role-to-Document Ownership Mapping
version: 1.3.0
status: LOCKED
---

# Ownership Mapping (ROOT-004)

* **Lead Software Architect:** `ROOT-001`, `ARC-001`, `ARC-002`, `GOV-001`, `GOV-004`
* **Technical Director & DevOps Lead:** `ENG-001`, `ENG-002`, `ENG-003`, `ENG-004`, `LOP-001`, `GOV-005`
* **Security Architect:** `ARC-003`, `GAME-001`
* **Principal Game Engineer:** `SPEC-001`, `SPEC-002`, `SPEC-003`
