---
id: SPEC-003
title: Game Specification — Mini Crossword
version: 1.0.0
status: LOCKED
---

# Game Specification: Crossword (SPEC-003)
* **Package ID:** `com.puzzleplatform.games.crossword`
* **Grid Size:** 5x5 Mini Crossword
* **Win Condition:** Solving all across and down clue answers.
* **Hint Solver:** Reveals the correct letter of an erroneous or empty cell with a 15-second timer penalty.
