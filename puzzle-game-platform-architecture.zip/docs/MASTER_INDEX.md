---
id: ROOT-003
title: Document Registry & Dependency Map
version: 1.3.0
status: LOCKED
---

# Master Document Registry (ROOT-003)

| ID | Title | File Path | Dependent Documents |
| :--- | :--- | :--- | :--- |
| **ROOT-001** | Master Blueprint Entry Point | `docs/README.md` | All |
| **ROOT-002** | Canonical Glossary | `docs/GLOSSARY.md` | ARC-001, ENG-001 |
| **GOV-001** | Studio Constitution | `docs/FOUNDATION/CONSTITUTION.md` | ARC-001, ENG-003 |
| **GOV-004** | 15-Minute Onboarding Manual | `docs/CONTRIBUTOR/CONTRIBUTING.md` | All |
| **GOV-005** | Studio Review & Gap Analysis | `docs/STUDIO_REVIEW_GAP_ANALYSIS.md` | All |
| **ARC-001** | Platform Architecture | `docs/ARCHITECTURE/PLATFORM_ARCHITECTURE.md` | ARC-002, ENG-001 |
| **ARC-002** | Platform Contract | `docs/ARCHITECTURE/PLATFORM_CONTRACT.md` | SPEC-001, SPEC-002, SPEC-003 |
| **ENG-002** | API Versioning Policy | `docs/ENGINEERING/API_VERSIONING.md` | ARC-001 |
| **ENG-003** | Feature Flags & Kill Switch | `docs/ENGINEERING/FEATURE_FLAGS.md` | LOP-001 |
| **ENG-004** | Firebase, UMP & API Level 35 Architecture | `docs/ENGINEERING/REMOTE_CONFIG_AND_UMP.md` | ARC-003, LOP-001 |
| **GAME-001**| Save System & Conflict Resolution | `docs/GAME/SAVE_SYSTEM.md` | ARC-003 |
| **LOP-001** | LiveOps & P0-P4 Incident Runbooks | `docs/LIVEOPS/LIVEOPS.md` | ENG-003 |
