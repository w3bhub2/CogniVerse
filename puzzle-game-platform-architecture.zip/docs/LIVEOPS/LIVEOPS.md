---
id: LOP-001
title: LiveOps Strategy, P0-P4 Incidents & Season End Runbook
version: 1.0.0
status: LOCKED
---

# LiveOps & Runbooks (LOP-001)

## 1. P0-P4 Incident Classification
* **P0 (Critical / Outage):** Complete inability to launch games or save cloud data. Action: Engage Kill Switch within 15 mins.
* **P1 (High / Revenue):** IAP checkout failures or leaderboard corruption. Action: Fix within 2 hours.
* **P2 (Medium / Gameplay):** Single level hint solver glitch. Action: Fix in next hotfix build.
* **P3/P4 (Low / Cosmetic):** UI typo or minor visual theme spacing. Action: Fix in next regular monthly release.

## 2. SEASON_END Runbook
At midnight UTC on the final day of each 30-day season:
1. Freeze active monthly leaderboard scores in PostgreSQL.
2. Award the "Monthly Master" achievement badge to top 5% players.
3. Distribute the 500-coin seasonal reward pool.
4. Reset streak counter and publish the new Monthly Season seed.
