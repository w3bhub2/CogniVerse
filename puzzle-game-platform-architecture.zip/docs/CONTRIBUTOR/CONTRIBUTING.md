---
id: GOV-004
title: 15-Minute Developer & AI Agent Onboarding Manual
version: 1.0.0
status: LOCKED
---

# Developer Onboarding Manual (GOV-004)

Welcome to **Puzzle Platform Studio**. This document is designed to get any experienced human developer or AI coding agent productive within 15 minutes.

---

## 1. Quick Start Commands

```bash
# 1. Install dependencies
npm install

# 2. Push Drizzle database schema to your local PostgreSQL instance
npx drizzle-kit push

# 3. Compile route types
npx next typegen

# 4. Execute TypeScript compiler check
npm exec tsc -- --noEmit

# 5. Build optimized production bundles
npm run build
```

---

## 2. Core Code Standards

* **Strict TypeScript Type Safety:** Implicit `any` is strictly prohibited. Every state object, event payload, and configuration option must be explicitly typed.
* **Separation of Concerns (The Sandbox Principle):** 
  * Game code (`src/games/[game_id]/*`) must remain sandboxed.
  * Games are prohibited from importing platform services directly.
  * Communication with platform services must occur strictly through the `GameModule` interface and by emitting events via the shared `eventBus` (e.g., `eventBus.emit("MOVE_MADE", ...)`).
* **Deterministic Level Seeding:** Puzzles must be generated from a consistent seed value. This ensures that level generation remains reproducible and easy to debug.

---

## 3. How to Add a New Game Module in 3 Steps

### Step 1: Create the Game Directory
Create a new folder in `src/games/` (e.g., `src/games/my-puzzle/`) and add an `index.ts` file.

### Step 2: Implement the `GameModule` Interface
Export a canonical game module configuration object implementing our shared contract:
```typescript
import { GameModule } from "@/engine/types";

export interface MyState {
  grid: number[][];
  score: number;
}

export const myGameModule: GameModule<MyState> = {
  id: "my-puzzle",
  name: "My Puzzle",
  phase: 2,
  category: "Tile & Grid",
  description: "A premium puzzle game spec.",
  version: "1.0.0",
  author: "Studio Team",
  packageId: "com.puzzleplatform.games.mypuzzle",
  iconName: "Puzzle",
  accentColor: "#EC4899",
  minSdk: 26,
  targetSdk: 35,
  supportedDifficulties: ["easy", "medium", "hard"],
  defaultSaveData: () => ({ highScore: 0 }),
  getInitialState: () => ({ grid: [], score: 0 }),
  validateSaveData: (data) => Boolean(data),
  getHint: () => null,
  computeScore: (state) => state.score,
  isGameOver: () => false,
  isGameWon: () => false,
};
```

### Step 3: Register Your Game Module
Add your game module to our static compile-time registry in `src/engine/registry.ts`:
```typescript
import { myGameModule } from "@/games/my-puzzle";

export const PHASE_1_MODULES: Record<string, GameModule<any, any>> = {
  // Existing launch games...
  "my-puzzle": myGameModule,
};
```
That's it! Your game immediately inherits real-time Web Audio API synthesis, haptic feedback, local/cloud save synchronization, daily challenges, and our compile-time APK/AAB build exporter.
