---
id: GOV-003
title: Rules for AI Coding Agents
version: 1.0.0
status: LOCKED
---

# AI Governance (GOV-003)

1. **Never Break the Contract:** AI agents adding new games must strictly implement `GameModule<TState, TSave>` without altering `src/engine/engine.ts`.
2. **Mandatory Checksums & Solvability:** AI agents must never create levels with unsolvable random states.
3. **No External Media Dependencies:** All audio must use Web Audio API synthesis; all icons must use Lucide vector symbols or local public assets.
