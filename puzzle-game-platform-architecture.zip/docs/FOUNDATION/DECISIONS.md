---
id: GOV-002
title: Architecture Decision Records (ADR)
version: 1.0.0
status: LOCKED
---

# Architecture Decision Records (GOV-002)

* **ADR-001 (Compile-Time Modularity):** Selected compile-time tree-shaking over dynamic web bundles to allow native Google Play standalone APK packaging under 2MB.
* **ADR-002 (Web Audio API Synthesis):** Selected programmatic Web Audio API synthesis over external MP3 files to eliminate audio asset download size and licensing risks.
* **ADR-003 (PostgreSQL + Drizzle ORM):** Selected PostgreSQL with Drizzle ORM for server-side cloud save sync, achievements, and Daily Challenge records.
