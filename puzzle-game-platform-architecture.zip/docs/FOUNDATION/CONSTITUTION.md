---
id: GOV-001
title: Studio Constitution & Non-Negotiable Engineering Rules
version: 1.0.0
status: LOCKED
---

# Studio Constitution (GOV-001)

1. **Separation of Concerns:** Games (`src/games/*`) must NEVER import or directly mutate Platform internal services. Communication occurs strictly via `GameModule` method contracts and `eventBus.emit()`.
2. **Offline-First Resilience:** No gameplay feature may fail due to an offline state. All saves and telemetry logs buffer locally and sync to PostgreSQL when reconnected.
3. **Zero Unfair Randomness:** Every generated puzzle level must be mathematically solvable. Hints must explain exact logical steps.
4. **Performance Budget:** 60 FPS gameplay target; initial APK bundle size under **100 MB** (our tree-shaked standalone APKs are under **2.0 MB**).
5. **No Pay-to-Win:** No item, hint, or level progression may require mandatory cash purchases.
