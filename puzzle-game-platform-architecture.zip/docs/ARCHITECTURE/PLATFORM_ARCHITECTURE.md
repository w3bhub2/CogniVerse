---
id: ARC-001
title: Layered Platform Architecture
version: 1.0.0
status: LOCKED
---

# Platform Architecture (ARC-001)

The system is partitioned into 3 isolated layers:
1. **Platform Layer (`src/services/*`):** Storage, Audio Synth, Haptics, Security, LiveOps, Feature Flags, and APK Build Exporter.
2. **Engine Layer (`src/engine/*`):** `PuzzleEngine` lifecycle, undo/redo stacks, timer, hint solver dispatch, and Story Saga/Daily Challenge engines.
3. **Game Plugin Layer (`src/games/*`):** Game-specific rules, grid generation, and scoring logic (2048, Sudoku, Crossword, Word Search, Jigsaw, Sliding Puzzle).
