---
id: ARC-002
title: The Bridge — GameModule Universal Contract
version: 1.0.0
status: LOCKED
---

# The Bridge (ARC-002)

Every game module must implement the TypeScript contract defined in `src/engine/types.ts`:
* `id`, `name`, `phase`, `category`, `packageId`, `supportedDifficulties`
* `getInitialState(difficulty, customSeed): TState`
* `getHint(state): GameHint | null`
* `computeScore(state, timeSeconds, movesCount): number`
* `isGameOver(state): boolean`
* `isGameWon(state): boolean`
