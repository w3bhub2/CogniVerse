---
id: ARC-003
title: Threat Model & Security Boundaries
version: 1.0.0
status: LOCKED
---

# Security Model (ARC-003)

* **HMAC Signature Verification:** All score submissions include a salted HMAC hash (`src/services/security.service.ts`) to prevent client-side memory injection.
* **Speedrun & Bound Audits:** Scores submitted with physically impossible move speeds or exceeding mathematical bounds are rejected automatically.
* **GDPR / CCPA Data Residency:** Users have an immediate in-app right to export JSON data or trigger 1-click permanent deletion (`src/components/studio/ProfileModal.tsx`).
