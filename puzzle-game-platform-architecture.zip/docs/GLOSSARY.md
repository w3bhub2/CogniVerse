---
id: ROOT-002
title: Canonical Glossary of Studio Terminology
version: 1.0.0
status: LOCKED
---

# Studio Glossary (ROOT-002)

* **GameModule:** A self-contained TypeScript plugin object implementing the canonical `GameModule<TState, TSave>` contract.
* **Compile-Time Tree-Shaking:** The build-time process in `BuildPipelineService` that prunes 49 non-selected game modules when packaging an independent APK (e.g. `2048.apk`).
* **Saga Campaign Chapter:** A story-driven progression tier with 3-star score thresholds and unlockable relics (`src/engine/campaign.ts`).
* **Daily Challenge Seed:** A deterministic date-keyed (`YYYY-MM-DD`) puzzle challenge generated for day-over-day Google Play retention (`src/engine/daily.ts`).
* **Web Audio Synth:** Our zero-external-dependency sound engine that generates organic wooden clicks, merge chimes, and pentatonic victory arpeggios in real time via the browser Web Audio API (`src/services/audio.service.ts`).
* **Save Checksum:** An HMAC / FNV-1a hash appended to local and cloud saves to detect corruption or unauthorized tampering (`src/services/security.service.ts`).
