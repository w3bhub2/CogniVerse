---
id: ENG-001
title: Universal Runtime Capabilities
version: 1.0.0
status: LOCKED
---

# Engine Runtime (ENG-001)

The runtime `PuzzleEngine` (`src/engine/engine.ts`) provides:
* **Deep-Clone Undo/Redo Stacks:** Maximum 50 states buffered per session.
* **Precision Timer:** 1-second interval tracking with automatic pause/resume on blur.
* **EventBus Publication:** Standardized event topics (`MOVE_MADE`, `HINT_USED`, `GAME_WON`, etc.) for UI and services.
