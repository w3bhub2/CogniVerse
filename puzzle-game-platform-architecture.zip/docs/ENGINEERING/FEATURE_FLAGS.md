---
id: ENG-003
title: Feature Flags & Emergency Kill Switch Protocol
version: 1.0.0
status: LOCKED
---

# Feature Flags & Kill Switch (ENG-003)

* **Kill Switch Protocol:** If a critical P0 bug or security vulnerability is discovered in an individual game, IAP, or LiveOps event, the DevOps team can toggle the target feature flag in `src/services/feature-flags.service.ts` to disable the feature instantly across all clients without requiring an app store update.
* **Flag Categories:**
  * `KILL_SWITCH_ALL_IAP`: Disables in-app purchase checkout buttons.
  * `KILL_SWITCH_GAME_[ID]`: Temporarily disables launch of a broken game module.
  * `KILL_SWITCH_LIVEOPS`: Disables daily challenges or seasonal events during maintenance.
