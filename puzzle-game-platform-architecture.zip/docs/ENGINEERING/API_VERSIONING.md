---
id: ENG-002
title: API Versioning & Deprecation Policy
version: 1.0.0
status: LOCKED
---

# API Versioning Policy (ENG-002)

* **Current Canonical Version:** `1.0.0` (all HTTP responses return `X-Studio-API-Version: 1.0.0`).
* **Deprecation Window:** When a new major API version (`v2`) is introduced, `v1` endpoints remain operational for a minimum of **180 days** (6 months) to ensure existing standalone APKs on older Android devices continue to sync cloud saves without disruption.
* **Header Compatibility:** Clients include `X-Studio-Client-Version` header in REST calls.
