---
id: ENG-004
title: Firebase Analytics, Remote Config, Google UMP & API Level 35 Architecture
version: 1.0.0
status: LOCKED
---

# Firebase, Google UMP & API Level 35 Architecture (ENG-004)

## 1. Engineering Decisions & Defaults

### A. Android API Level 35 Target & Android App Bundle (AAB)
* **Why Chosen:** Google Play mandates modern API targets (Android 15 / API Level 35) and dynamic Android App Bundle (`.aab`) delivery to optimize APK splits by ABI, screen density, and language.
* **Alternatives & Rejections:** Rejected legacy API 33/34 and monolithic APK distribution for Play Store release because they incur higher download sizes and fail modern Play Store security target requirements.
* **Impact on Scalability & Play Store Deployment:** `src/services/build-pipeline.service.ts` outputs Gradle build scripts configured with `compileSdk = 35`, `targetSdk = 35`, and `bundleRelease` enabled by default.

### B. Google UMP (User Messaging Platform) for GDPR / CCPA Consent
* **Why Chosen:** Google AdMob and Play Store require verified IAB TCF v2.2 consent strings for users in the European Economic Area (EEA), UK, and California before personalized ads or analytics can be served.
* **Alternatives & Rejections:** Rejected custom-built cookie banners because they do not integrate directly with Google AdMob or Google Play verification.
* **Impact on Scalability:** `src/services/firebase-ump.service.ts` provides a unified `requestUmpConsentDialog()` bridge that works offline-first and communicates consent status (`OBTAINED`, `DENIED`, `NOT_REQUIRED`) to our telemetry and ad services.

### C. Firebase Analytics, Crashlytics & Remote Config (Offline-First)
* **Why Chosen:** Provides real-time crash reporting, gameplay difficulty balancing without app updates, and standardized event telemetry.
* **Offline-First Fallback:** All Remote Config parameters (`enable_rewarded_hint_bonus`, `daily_challenge_coin_reward`, `season_duration_days`, `ad_free_iap_price_usd`) include deterministic local offline defaults in `DEFAULT_REMOTE_CONFIG` so the game never freezes if network access is unavailable.

### D. Google Play App Signing Release Block
* **Why Chosen:** Google Play App Signing manages the app signing key in Google's secure hardware infrastructure while developers use an upload key (`studio-upload-keystore.jks`).
* **Implementation:** `build.gradle.kts` includes a dedicated `signingConfigs.create("release")` block reading from CI/CD environment variables (`KEYSTORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD`).
