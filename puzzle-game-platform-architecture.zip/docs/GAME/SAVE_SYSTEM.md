---
id: GAME-001
title: Save Persistence & Cloud Conflict Resolution Protocol
version: 1.0.0
status: LOCKED
---

# Save System & Conflict Resolution (GAME-001)

* **Hybrid Persistence:** Local saves buffer instantly to `localStorage` with an FNV-1a checksum. Cloud saves persist to PostgreSQL (`game_saves` table) via `/api/saves`.
* **Conflict Resolution UI Protocol:** If a local save timestamp and cloud save timestamp diverge by more than **60 seconds**, the platform triggers the **Cloud Save Conflict Resolution Modal (`SaveConflictModal.tsx`)**, displaying a side-by-side comparison of local vs cloud score, moves, and timestamp so the player can explicitly choose which state to keep.
