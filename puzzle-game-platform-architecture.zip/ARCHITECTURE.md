# Studio Technical Architecture & Specification Manual

## 1. Engine Architecture & Decoupled Responsibilities

```
+-----------------------------------------------------------------------------+
|                      STUDIO UNIVERSAL ENGINE LAYER                          |
|  - Lifecycle (`engine.init()`, `engine.resetGame()`, `engine.setPaused()`)  |
|  - Undo/Redo Deep-Clone Stack (`engine.undo()`, `engine.redo()`)            |
|  - Precision Timer & Elapsed Seconds Accounting                             |
|  - EventBus Publish-Subscribe (`eventBus.emit("MOVE_MADE", ...)`)           |
+-----------------------------------------------------------------------------+
                                      │
                                      ▼ (Implements Contract)
+-----------------------------------------------------------------------------+
|                     GAME MODULE CONTRACT (`GameModule`)                     |
|  - `id`, `name`, `phase`, `category`, `packageId`, `supportedDifficulties`  |
|  - `getInitialState(difficulty, seed): TState`                              |
|  - `getHint(state): GameHint | null`                                        |
|  - `computeScore(state, timeSeconds, movesCount): number`                   |
|  - `isGameOver(state): boolean`  |  `isGameWon(state): boolean`             |
+-----------------------------------------------------------------------------+
```

---

## 2. PostgreSQL & Drizzle ORM Database Schema

Our PostgreSQL database (`src/db/schema.ts`) uses connection pooling and Drizzle ORM models:
* `profiles`: Player display name, level, total stars, coins, ad-free VIP status, and active visual theme.
* `game_saves`: Checksum-verified cloud saves and high scores keyed by `(user_id, game_id)`.
* `user_achievements`: Tracked achievement badges with automatic XP rewards.
* `campaign_progress`: Star counts (0-3), completion times, and unlocked relics per Story Chapter.
* `daily_challenges`: Date-keyed challenge scores and daily streaks.
* `analytics_events`: Real-time gameplay telemetry and QA event logs.
* `build_manifest_logs`: History of generated compile-time APK manifests and bundle size estimates.

---

## 3. How to Implement Game #51 in 15 Minutes

To add a new game (e.g. **Game #51: Sudoku X**) without modifying any engine code:

1. **Create the Game Directory:**
   Create `src/games/sudoku-x/index.ts`.
2. **Implement `GameModule<TSudokuXState>`:**
   ```typescript
   import { GameModule, GameHint, GameDifficulty } from "@/engine/types";

   export interface SudokuXState {
     grid: number[][];
     won: boolean;
     gameOver: boolean;
   }

   export const sudokuXModule: GameModule<SudokuXState> = {
     id: "sudoku-x",
     name: "Sudoku X",
     phase: 2,
     category: "Number Logic",
     packageId: "com.puzzleplatform.games.sudokux",
     description: "Diagonal Sudoku challenge with main X-axis constraints.",
     supportedDifficulties: ["easy", "medium", "hard"],
     defaultSaveData: () => ({ highScore: 0 }),
     getInitialState: () => ({ grid: [], won: false, gameOver: false }),
     validateSaveData: (data) => Boolean(data),
     getHint: (state) => null,
     computeScore: (state, time) => 1000 - time,
     isGameOver: () => false,
     isGameWon: (state) => state.won,
   };
   ```
3. **Register in `src/engine/registry.ts`:**
   Add `sudokuXModule` to `PHASE_1_MODULES` (or future phase suites).
4. **Done!**
   Your game immediately inherits Web Audio synth sounds, haptic vibration, cloud sync, Story Saga compatibility, and automated Google Play APK export!
