# Puzzle Platform Studio • 50+ Casual Puzzle Games Ecosystem
### Commercial Studio Architecture, Engine Foundation & Build Pipeline

```
  ┌────────────────────────────────────────────────────────────────────────┐
  │                         PUZZLE PLATFORM STUDIO                         │
  │                  One Reusable Engine • 50+ Game Roadmap                │
  └───────────────────────────────────┬────────────────────────────────────┘
                                      │
          ┌───────────────────────────┼───────────────────────────┐
          ▼                           ▼                           ▼
  ┌───────────────┐           ┌───────────────┐           ┌───────────────┐
  │  CORE ENGINE  │           │   SERVICES    │           │ GAME MODULES  │
  │  Lifecycle    │           │   Web Audio   │           │   2048        │
  │  Undo/Redo    │           │   Haptics     │           │   Sudoku      │
  │  Hint Solver  │           │   Cloud Sync  │           │   Crossword   │
  │  EventBus     │           │   APK Export  │           │   Word Search │
  └───────────────┘           └───────────────┘           └───────────────┘
                                      │
          ┌───────────────────────────┴───────────────────────────┐
          ▼                                                       ▼
  ┌────────────────────────────────┐            ┌───────────────────────────────────┐
  │  TARGET A: Puzzle Platform.apk │            │  TARGET B: Standalone App APKs    │
  │  com.puzzleplatform.app        │            │  com.puzzleplatform.games.g2048   │
  │  (All 50+ Games Unified)       │            │  (Tree-Shaked Single Game < 2.0MB)│
  └────────────────────────────────┘            └───────────────────────────────────┘
```

---

## 1. Executive Summary & First Principles

This repository is **not** a prototype or hobby template. It is a **commercial, revenue-generating casual puzzle game studio ecosystem** designed to scale across **50+ independent Google Play applications** as well as a unified **Puzzle Platform** application without duplicating a single line of engine or service code.

### Core Tenets:
1. **Compile-Time Modularity:** Unlike browser plugins or web extensions, our build pipeline uses static import registries (`src/engine/registry.ts`) and compile-time tree-shaking (`src/services/build-pipeline.service.ts`). Packaging an independent app (e.g. `Sudoku.apk`) automatically excludes all 49 non-selected games, producing lightweight APKs under **2.0 MB**.
2. **Zero Unfair Randomness:** All puzzle generation (Sudoku, 15-Puzzle Sliding Tiles) guarantees mathematical solvability. The AI-driven Hint Solver pathfinds and explains exact logical moves instead of guessing.
3. **Studio Sensory Polish (Anti-AI Aesthetic):** Zero robotic beeps or generic AI UI. All audio feedback (pentatonic victory arpeggios, organic wooden tile clicks, harmonic merge chimes) is synthesized in real time via the browser **Web Audio API** without requiring heavy external audio files.
4. **Story Saga & Daily Retention Engine:** Includes a 5-Chapter Campaign Saga Map (`src/engine/campaign.ts`) with custom artwork banners and relic trophies, plus a deterministic date-keyed Daily Challenge Engine (`src/engine/daily.ts`).

---

## 2. Repository Structure

```
├── public/
│   ├── icons/                  # 192px and 512px PWA maskable icons
│   ├── images/                 # AI-generated Studio Hero and Story Chapter artwork banners
│   └── manifest.json           # Web App Manifest for Android PWA / Capacitor
├── src/
│   ├── app/                    # Next.js App Router & REST APIs (/api/saves, /api/campaign, etc.)
│   ├── components/studio/      # StudioHub, GameView, CampaignModal, ProfileModal, BuildExporterModal
│   ├── db/                     # PostgreSQL connection pool & Drizzle ORM schema
│   ├── engine/                 # Reusable Studio Engine (engine.ts, events.ts, campaign.ts, daily.ts)
│   ├── games/                  # Phase 1 Game Modules (2048, Sudoku, Crossword, WordSearch, Jigsaw, Sliding)
│   └── services/               # Platform Services (Audio, Haptics, Storage, Security, PlayStore Automation)
└── ARCHITECTURE.md             # Complete technical architecture & Game #51 extension manual
```

---

## 3. Phase 1 Playable Suite (6 Active Games)

| Game ID | Name | Category | Package ID | Key Mechanics |
| :--- | :--- | :--- | :--- | :--- |
| `2048` | **2048** | Number Logic | `com.puzzleplatform.games.g2048` | Swipe/arrow tile merge, combo scoring, smart hint suggestion |
| `sudoku` | **Sudoku** | Number Logic | `com.puzzleplatform.games.sudoku` | 9x9 grid, notes mode, mistake counter, logical cell highlights |
| `crossword` | **Crossword** | Word & Vocabulary | `com.puzzleplatform.games.crossword` | Mini across/down clues, instant validation, letter hints |
| `word-search` | **Word Search** | Word & Vocabulary | `com.puzzleplatform.games.wordsearch` | 8x8 letter matrix, line selection, vocabulary checklist |
| `jigsaw` | **Jigsaw Puzzle** | Tile & Grid | `com.puzzleplatform.games.jigsaw` | Stained-glass mosaic swap, coordinate lock, visual art |
| `sliding-puzzle`| **Sliding Puzzle** | Tile & Grid | `com.puzzleplatform.games.slidingpuzzle`| Solvable 15-puzzle sliding mechanics, adjacent pathfinding |

---

## 4. How to Eliminate Manual Work Smartly (CI/CD Pipeline)

To publish 50+ standalone apps to Google Play without a 50x maintenance burden, manual release work is eliminated across 3 stages:

1. **Stage 1 (Shared Code Contract — 0% Duplication):** All games implement the `GameModule<TState, TSave>` contract. Fixing a bug in the undo stack or hint solver updates all 50+ games simultaneously.
2. **Stage 2 (Compile-Time APK Manifest Generator):** Run the in-app **APK Build Exporter** (`BuildExporterModal.tsx`) to generate ready-to-use `AndroidManifest.xml`, `build.gradle.kts`, `capacitor.config.ts`, and PWA manifests for either the platform bundle or any single game.
3. **Stage 3 (Automated Google Play Store Ingestion):** Our `PlayStoreAutomationService` outputs ready-to-upload Play Store short/long descriptions, Content Rating questionnaires, GDPR Data Safety JSON manifests, and Proguard/R8 optimization rules.

---

## 5. Development & Verification Commands

```bash
# 1. Install dependencies
npm install

# 2. Push Drizzle PostgreSQL database schema
npx drizzle-kit push

# 3. Generate Next.js route types
npx next typegen

# 4. Type-check entire project with TypeScript
npm exec tsc -- --noEmit

# 5. Build optimized production bundle
npm run build
```

For full architecture details, refer to `ARCHITECTURE.md` and `PLAYSTORE_RELEASE_GUIDE.md`.
